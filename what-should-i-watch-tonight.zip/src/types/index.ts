/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type BranchId =
  | 'romance'
  | 'mystery_crime'
  | 'scifi_fantasy'
  | 'arthouse_drama'
  | 'comedy_light'
  | 'adventure_action'
  | 'horror_thriller'
  | 'general_exploration';

export interface EmotionalWeights {
  comfort?: number;
  catharsis?: number;
  romantic_longing?: number;
  intellectual_stimulation?: number;
  thrill?: number;
  escapism?: number;
  poetic_wonder?: number;
  existential_reflection?: number;
  joy_laughter?: number;
  melancholy?: number;
}

export interface DimensionWeights {
  emotions?: EmotionalWeights;
  branches?: Partial<Record<BranchId, number>>;
  storytellingPacing?: 'slow' | 'balanced' | 'fast';
  storytellingStyle?: 'character_driven' | 'plot_driven' | 'poetic_atmosphere' | 'puzzle_investigation' | 'philosophical' | 'surreal';
  visualAesthetics?: 'warm_golden' | 'noir_nocturnal' | 'minimalist_clean' | 'vivid_painterly' | 'gritty_realistic' | 'retro_vintage';
  endingType?: 'warm_uplifting' | 'bitter_sweet' | 'tragic_heartbreak' | 'open_thought_provoking' | 'mind_twist';
  eraType?: 'classic' | 'retro_90s_00s' | 'modern_recent';
  popularityType?: 'crowd_pleaser' | 'masterpiece' | 'hidden_gem' | 'cult_arthouse';
  regions?: string[];
  durationPreference?: 'short' | 'medium' | 'long' | 'any';
}

export interface QuizOption {
  id: string;
  label: string;
  sublabel?: string;
  imageUrl?: string;
  weights: DimensionWeights;
}

export interface QuizQuestion {
  id: number; // 1 to 15
  stage: 1 | 2 | 3;
  branch?: BranchId;
  title: string;
  subtitle?: string;
  isMultiSelect?: boolean;
  options: QuizOption[];
}

export interface Movie {
  id: string;
  chineseTitle: string;
  originalTitle: string;
  releaseYear: number;
  country: string;
  director: string;
  genre: string[];
  runtime: number; // in minutes
  synopsis: string;
  
  // Categorical tags
  moodTags: string[];
  storytellingTags: string[];
  visualTags: string[];
  pacingTag: 'slow' | 'balanced' | 'fast';
  endingTag: 'warm_uplifting' | 'bitter_sweet' | 'tragic_heartbreak' | 'open_thought_provoking' | 'mind_twist';
  romanceTag?: 'sweet' | 'slow_burn' | 'heartbreak' | 'realistic' | 'complex_intense' | 'friendship_platonic' | 'none';
  contentWarnings: string[];
  
  // Scoring vectors (0 to 10)
  attributes: {
    emotionalNeeds: EmotionalWeights;
    primaryBranch: BranchId;
    secondaryBranch?: BranchId;
    storytellingPacing: 'slow' | 'balanced' | 'fast';
    storytellingStyle: 'character_driven' | 'plot_driven' | 'poetic_atmosphere' | 'puzzle_investigation' | 'philosophical' | 'surreal';
    visualAesthetics: 'warm_golden' | 'noir_nocturnal' | 'minimalist_clean' | 'vivid_painterly' | 'gritty_realistic' | 'retro_vintage';
    endingType: 'warm_uplifting' | 'bitter_sweet' | 'tragic_heartbreak' | 'open_thought_provoking' | 'mind_twist';
    eraType: 'classic' | 'retro_90s_00s' | 'modern_recent';
    popularityType: 'crowd_pleaser' | 'masterpiece' | 'hidden_gem' | 'cult_arthouse';
  };
  
  // Official Theatrical Poster & Provenance
  officialPosterUrl?: string;
  posterSource?: string;
  licenseStatus?: 'official_theatrical' | 'authorized_promotional' | 'pending';
  hasOfficialPoster?: boolean;
  posterVerificationStatus?: 'licensed_verified' | 'found_license_unverified' | 'unavailable' | 'broken';
  posterAspectRatio?: string;

  // Cover art & presentation
  coverUrl: string;
  coverSource: string;
  coverLicense: string;
  editorialPalette: {
    bg: string;
    text: string;
    accent: string;
  };
  
  // Editorial blurbs
  whyRecommendedDefault: string;
  bestViewingAtmosphere: string;
}

export interface RecommendationResult {
  movie: Movie;
  score: number; // 0 - 100 compatibility percentage
  category: 'primary_match' | 'hidden_gem' | 'out_of_comfort' | 'light_choice' | 'deep_resonance';
  categoryLabel: string;
  categoryReason: string;
  matchHighlights: string[];
}

export interface UserProfile {
  profileTitle: string;
  profileSubtitle: string;
  profileDescription: string;
  topEmotions: string[];
  preferredVisualAtmosphere: string;
  storytellingPreference: string;
  cinemaPhilosophy: string;
  recommendedTonight: RecommendationResult[];
}

export interface ActivationRecord {
  code: string;
  createdAt: string;
  activatedAt?: string;
  devicesUsed: string[]; // device fingerprints / hashes
  maxDevices: number;
  isActive: boolean;
  notes?: string;
}
