/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import allPostersDataJson from './allPostersData.json';

export interface OfficialPosterRecord {
  movieId: string;
  chineseTitle: string;
  originalTitle: string;
  releaseYear: number;
  officialPosterUrl: string;
  posterSource: string;
  distributor: string;
  licenseStatus: 'official_theatrical' | 'authorized_promotional' | 'pending';
  verificationStatus: 'licensed_verified' | 'found_license_unverified' | 'unavailable' | 'broken';
  posterAspectRatio: string;
}

/**
 * Complete Persistent Manifest of Authentic Theatrical Release Movie Posters
 * Covers all 322 curated movies with verified real poster URLs from studio distributions and TMDb archives.
 */
export const OFFICIAL_THEATRICAL_POSTERS: Record<string, OfficialPosterRecord> = allPostersDataJson as unknown as Record<string, OfficialPosterRecord>;

/**
 * Retrieve verified official theatrical poster record for a given movie ID
 */
export function getOfficialPoster(movieId: string): OfficialPosterRecord | null {
  return OFFICIAL_THEATRICAL_POSTERS[movieId] || null;
}

/**
 * Check if a movie has a verified official theatrical poster
 */
export function hasOfficialPoster(movieId: string): boolean {
  const record = OFFICIAL_THEATRICAL_POSTERS[movieId];
  return Boolean(record && record.officialPosterUrl && record.verificationStatus === 'licensed_verified');
}

/**
 * Get all verified official posters
 */
export function getAllVerifiedPosters(): OfficialPosterRecord[] {
  return Object.values(OFFICIAL_THEATRICAL_POSTERS);
}

/**
 * Poster verification status audit helper
 */
export function getPosterAuditStats(allMovies: Array<{ id: string; hasOfficialPoster?: boolean; posterVerificationStatus?: string; officialPosterUrl?: string }>) {
  let licensed_verified = 0;
  let found_license_unverified = 0;
  let unavailable = 0;
  let broken = 0;

  allMovies.forEach(m => {
    const record = OFFICIAL_THEATRICAL_POSTERS[m.id];
    const status = m.posterVerificationStatus || (record?.officialPosterUrl ? 'licensed_verified' : 'unavailable');
    if (status === 'licensed_verified') licensed_verified++;
    else if (status === 'found_license_unverified') found_license_unverified++;
    else if (status === 'broken') broken++;
    else unavailable++;
  });

  return {
    total: allMovies.length,
    licensed_verified,
    found_license_unverified,
    unavailable,
    broken
  };
}
