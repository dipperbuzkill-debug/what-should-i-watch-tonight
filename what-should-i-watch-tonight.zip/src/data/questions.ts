/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BranchId, QuizQuestion } from '../types';

// Image mood cards generated in assets
export const MOOD_IMAGES = {
  hero: '/src/assets/images/hero_cinema_editorial_1794015813086.jpg',
  magazineCover: '/src/assets/images/cinema_magazine_cover_1794015814577.jpg',
  warmRomance: '/src/assets/images/visual_mood_warm_romance_1794015814884.jpg',
  nocturneMystery: '/src/assets/images/visual_mood_nocturne_mystery_1794015815285.jpg',
};

// ==========================================
// STAGE 1: UNIVERSAL EXPLORATION (Q1 - Q5)
// ==========================================
export const STAGE_1_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    stage: 1,
    title: '此刻，你最想通过今晚的电影获得什么情绪体验？',
    subtitle: '请倾听你当下内心最真实的渴望',
    options: [
      {
        id: 'q1_a',
        label: '温柔治愈，卸下一整天的疲惫与紧绷',
        sublabel: '想要一个温暖的怀抱与安心的陪伴',
        weights: {
          emotions: { comfort: 10, joy_laughter: 5 },
          branches: { comedy_light: 6, arthouse_drama: 5, romance: 4 },
          endingType: 'warm_uplifting'
        }
      },
      {
        id: 'q1_b',
        label: '智性挑战，渴望高智商推演与反转震撼',
        sublabel: '让沉睡的思维细胞彻底活跃起来',
        weights: {
          emotions: { intellectual_stimulation: 10, thrill: 6 },
          branches: { mystery_crime: 8, scifi_fantasy: 6 },
          storytellingStyle: 'puzzle_investigation'
        }
      },
      {
        id: 'q1_c',
        label: '浪漫心动，想要重温两颗心靠近的悸动',
        sublabel: '感受暧昧拉扯与深情凝视的温度',
        weights: {
          emotions: { romantic_longing: 10, poetic_wonder: 6 },
          branches: { romance: 10 },
          visualAesthetics: 'warm_golden'
        }
      },
      {
        id: 'q1_d',
        label: '情绪释放，痛快淋漓地哭一场或深深叹息',
        sublabel: '给心底积压的情感一个安全的宣泄出口',
        weights: {
          emotions: { catharsis: 10, melancholy: 7 },
          branches: { arthouse_drama: 8, romance: 6 },
          endingType: 'bitter_sweet'
        }
      },
      {
        id: 'q1_e',
        label: '肾上腺素飙升，紧张刺激打破平淡日常',
        sublabel: '想要心跳加速、屏住呼吸的高能体验',
        weights: {
          emotions: { thrill: 10, escapism: 7 },
          branches: { adventure_action: 7, horror_thriller: 8, mystery_crime: 5 },
          storytellingPacing: 'fast'
        }
      },
      {
        id: 'q1_f',
        label: '辽阔神游，跨越现实重力沉入另一个世界',
        sublabel: '寻找宏大、奇幻或充满诗意的超越感',
        weights: {
          emotions: { poetic_wonder: 10, existential_reflection: 8, escapism: 8 },
          branches: { scifi_fantasy: 8, arthouse_drama: 6, adventure_action: 5 },
          storytellingStyle: 'philosophical'
        }
      }
    ]
  },
  {
    id: 2,
    stage: 1,
    title: '闭上双眼，你最希望步入哪种光影视觉氛围？',
    subtitle: '画面的质感与色调将决定你今晚的梦境底色',
    options: [
      {
        id: 'q2_a',
        label: '暖黄胶片与夕阳金光',
        sublabel: '35mm胶片颗粒、泛黄咖啡馆、慵懒黄昏光线',
        imageUrl: MOOD_IMAGES.warmRomance,
        weights: {
          visualAesthetics: 'warm_golden',
          emotions: { romantic_longing: 6, comfort: 6 },
          branches: { romance: 6, arthouse_drama: 5 }
        }
      },
      {
        id: 'q2_b',
        label: '雨夜霓虹与黑夜潮湿倒影',
        sublabel: '冷峻都市、黑色风衣、沥青路面的反光与阴影',
        imageUrl: MOOD_IMAGES.nocturneMystery,
        weights: {
          visualAesthetics: 'noir_nocturnal',
          emotions: { thrill: 6, intellectual_stimulation: 5 },
          branches: { mystery_crime: 7, horror_thriller: 6 }
        }
      },
      {
        id: 'q2_c',
        label: '极简冷调与留白诗意',
        sublabel: '干净克制的建筑线条、素净光影、深沉宁静的呼吸感',
        weights: {
          visualAesthetics: 'minimalist_clean',
          emotions: { existential_reflection: 7, poetic_wonder: 6 },
          branches: { arthouse_drama: 7, scifi_fantasy: 5 }
        }
      },
      {
        id: 'q2_d',
        label: '浓郁饱和的油画童话感',
        sublabel: '高饱和度调色盘、复古对称美学、色彩斑斓的梦幻构图',
        imageUrl: MOOD_IMAGES.hero,
        weights: {
          visualAesthetics: 'vivid_painterly',
          emotions: { joy_laughter: 6, poetic_wonder: 8, escapism: 7 },
          branches: { comedy_light: 6, scifi_fantasy: 6, adventure_action: 5 }
        }
      },
      {
        id: 'q2_e',
        label: '质朴纪实与自然微风',
        sublabel: '日光穿过树梢的光斑、泥土与雨水气味、毫无修饰的真实生命力',
        weights: {
          visualAesthetics: 'gritty_realistic',
          emotions: { comfort: 6, existential_reflection: 6 },
          branches: { arthouse_drama: 7, general_exploration: 5 }
        }
      },
      {
        id: 'q2_f',
        label: '古典庄重与大画幅胶片',
        sublabel: '厚重深邃的历史质感、古典剧场光影、考究的黄金比例',
        imageUrl: MOOD_IMAGES.magazineCover,
        weights: {
          visualAesthetics: 'retro_vintage',
          emotions: { poetic_wonder: 6, intellectual_stimulation: 6 },
          branches: { general_exploration: 6, mystery_crime: 5 }
        }
      }
    ]
  },
  {
    id: 3,
    stage: 1,
    title: '以下哪种叙事切入点最能激起你的好奇心？',
    subtitle: '一个好故事的开端往往决定了航行的航道',
    options: [
      {
        id: 'q3_a',
        label: '两个灵魂在某个偶然夜晚的深谈与相知',
        sublabel: '眼神的交汇、没有伪装的坦白，关于自我的对话',
        weights: {
          storytellingStyle: 'character_driven',
          branches: { romance: 8, arthouse_drama: 6 },
          emotions: { romantic_longing: 8 }
        }
      },
      {
        id: 'q3_b',
        label: '一件看似完美的罪案，以及隐藏在体面背后的谎言',
        sublabel: '蛛丝马迹的搜寻，层层剥开每个人心中的阴暗秘密',
        weights: {
          storytellingStyle: 'puzzle_investigation',
          branches: { mystery_crime: 9 },
          emotions: { intellectual_stimulation: 8, thrill: 6 }
        }
      },
      {
        id: 'q3_c',
        label: '一个颠覆物理法则或时间维度的宏大假设',
        sublabel: '如果记忆可以清除？如果时间非线性流动？如果星际存在彼岸？',
        weights: {
          storytellingStyle: 'philosophical',
          branches: { scifi_fantasy: 9 },
          emotions: { intellectual_stimulation: 8, poetic_wonder: 8 }
        }
      },
      {
        id: 'q3_d',
        label: '普通人生活裂缝中的微光与隐秘尊严',
        sublabel: '柴米油盐中的诗意，不声不响却直击心房的真实生活',
        weights: {
          storytellingStyle: 'character_driven',
          branches: { arthouse_drama: 9 },
          emotions: { existential_reflection: 8, comfort: 7 }
        }
      },
      {
        id: 'q3_e',
        label: '荒诞离奇的巧合与一连串啼笑皆非的误会',
        sublabel: '多股势力阴差阳错撞在一起，充满机智讽刺与幽默',
        weights: {
          storytellingStyle: 'plot_driven',
          branches: { comedy_light: 9 },
          emotions: { joy_laughter: 9 }
        }
      },
      {
        id: 'q3_f',
        label: '背起行囊踏入无人荒原或未知领域的冒险',
        sublabel: '面对大自然的雄奇与生命的未知，唤醒沉睡的野性与热血',
        weights: {
          storytellingStyle: 'plot_driven',
          branches: { adventure_action: 9 },
          emotions: { escapism: 8, thrill: 7 }
        }
      }
    ]
  },
  {
    id: 4,
    stage: 1,
    title: '你更享受怎样的电影节奏与观影沉浸方式？',
    subtitle: '决定电影镜头切分的呼吸频率',
    options: [
      {
        id: 'q4_a',
        label: '静水流深：长镜头与呼吸留白，允许我走神与沉思',
        sublabel: '不需要台词塞满每一秒，光线与环境声音就是最好的台词',
        weights: {
          storytellingPacing: 'slow',
          branches: { arthouse_drama: 7, romance: 5 },
          emotions: { poetic_wonder: 7, existential_reflection: 7 }
        }
      },
      {
        id: 'q4_b',
        label: '行云流水：张弛有度，在情节推进与人物情感间达到均衡',
        sublabel: '有充足的戏剧情节，但给心灵留有咀嚼回味的余量',
        weights: {
          storytellingPacing: 'balanced',
          branches: { general_exploration: 7, romance: 5, comedy_light: 5 }
        }
      },
      {
        id: 'q4_c',
        label: '电光石火：信息密度极高，多线交织、反转不停、毫不拖沓',
        sublabel: '全程抓住眼球，没有哪怕一分钟的无聊废戏',
        weights: {
          storytellingPacing: 'fast',
          branches: { mystery_crime: 7, adventure_action: 7 },
          emotions: { thrill: 8, intellectual_stimulation: 7 }
        }
      },
      {
        id: 'q4_d',
        label: '诗意蒙太奇：打破常规逻辑，像翻开一本梦境画册',
        sublabel: '音乐与色彩带动画意，感受情绪的自由流动',
        weights: {
          storytellingStyle: 'surreal',
          branches: { arthouse_drama: 6, scifi_fantasy: 6 },
          emotions: { poetic_wonder: 9 }
        }
      },
      {
        id: 'q4_e',
        label: '密室剧场：聚焦狭窄空间里的人性拉锯与高能对峙',
        sublabel: '极少数演员、极强戏剧张力，像看一场神级话剧',
        weights: {
          storytellingStyle: 'character_driven',
          branches: { mystery_crime: 7, horror_thriller: 6 },
          emotions: { intellectual_stimulation: 8 }
        }
      },
      {
        id: 'q4_f',
        label: '轻快摇摆：伴随动听配乐，像喝下一杯冰镇气泡酒',
        sublabel: '肢体动作、机巧对话与节奏共振，心情随着银幕飞扬',
        weights: {
          storytellingPacing: 'fast',
          branches: { comedy_light: 8, romance: 6 },
          emotions: { joy_laughter: 8, comfort: 6 }
        }
      }
    ]
  },
  {
    id: 5,
    stage: 1,
    title: '以下哪种情况最容易破坏你今晚的观影兴致？',
    subtitle: '排斥雷区与偏好同样关键',
    options: [
      {
        id: 'q5_a',
        label: '故作高深的沉闷冗长，看完让人昏昏欲睡无所适从',
        sublabel: '今晚拒绝没有情节支撑的虚无装深沉',
        weights: {
          storytellingPacing: 'fast',
          branches: { comedy_light: 5, mystery_crime: 5, adventure_action: 5 }
        }
      },
      {
        id: 'q5_b',
        label: '廉价粗糙的爆米花套路，剧情降智毫无艺术追求',
        sublabel: '拒绝一眼看穿所有结局的工业流水线烂俗桥段',
        weights: {
          branches: { arthouse_drama: 6, mystery_crime: 5, scifi_fantasy: 5 },
          emotions: { intellectual_stimulation: 7 }
        }
      },
      {
        id: 'q5_c',
        label: '过度血腥残暴或生理反胃的无端惊吓',
        sublabel: '不想今晚做噩梦，拒绝廉价Jump Scare与恶心画面',
        weights: {
          branches: { romance: 5, comedy_light: 5, arthouse_drama: 5 }
        }
      },
      {
        id: 'q5_d',
        label: '工业糖精泛滥的虚假甜宠，脱离现实的悬浮剧情',
        sublabel: '无法忍受毫无心智魅力的狗血恋爱与塑料人设',
        weights: {
          branches: { arthouse_drama: 6, mystery_crime: 5 },
          storytellingStyle: 'character_driven'
        }
      },
      {
        id: 'q5_e',
        label: '过度压抑致郁、毫无希望与尊严的彻底绝望',
        sublabel: '现实生活已经够辛苦了，今晚需要一点光亮',
        weights: {
          endingType: 'warm_uplifting',
          branches: { comedy_light: 6, romance: 5, adventure_action: 4 }
        }
      },
      {
        id: 'q5_f',
        label: '高高在上的说教与道德批判，缺乏真诚与包容',
        sublabel: '讨厌被导演强行灌输价值观，想要平等的叙事共鸣',
        weights: {
          branches: { arthouse_drama: 5, general_exploration: 5 },
          emotions: { existential_reflection: 6 }
        }
      }
    ]
  }
];

// ==========================================
// STAGE 2: DYNAMIC BRANCH QUESTIONS (8 POOLS)
// ==========================================

export const BRANCH_QUESTIONS: Record<BranchId, QuizQuestion[]> = {
  // BRANCH 1: ROMANCE & RELATIONSHIPS
  romance: [
    {
      id: 6,
      stage: 2,
      branch: 'romance',
      title: '你最心仪哪种模式的亲密关系故事？',
      subtitle: '探索你关于爱的深层向往',
      options: [
        {
          id: 'br_rom_1_a',
          label: '甜蜜心动，从头到尾都很浪漫温暖',
          sublabel: '双向奔赴，被无微不至地珍视与呵护',
          weights: { emotions: { comfort: 10, romantic_longing: 8 }, endingType: 'warm_uplifting' }
        },
        {
          id: 'br_rom_1_b',
          label: '暧昧拉扯，明明喜欢却迟迟没有说出口',
          sublabel: '指尖若有若无的触碰、眼神交汇时的闪躲',
          weights: { emotions: { romantic_longing: 10, poetic_wonder: 7 }, storytellingPacing: 'slow' }
        },
        {
          id: 'br_rom_1_c',
          label: '相爱却无法在一起，充满宿命意难平',
          sublabel: '时代的藩篱或错位的时空，留下一生的叹息',
          weights: { emotions: { melancholy: 10, catharsis: 9 }, endingType: 'bitter_sweet' }
        },
        {
          id: 'br_rom_1_d',
          label: '现实生活中的爱情，有矛盾妥协也有成长',
          sublabel: '柴米油盐里的争吵与支撑，撕开爱情真实的骨肉',
          weights: { emotions: { existential_reflection: 8 }, storytellingStyle: 'character_driven' }
        },
        {
          id: 'br_rom_1_e',
          label: '复杂危险的隐秘情愫，充满欲望与心理博弈',
          sublabel: '禁忌的吸引力，在道德边缘试探的极致张力',
          weights: { emotions: { thrill: 8, romantic_longing: 7 } }
        },
        {
          id: 'br_rom_1_f',
          label: '不一定是爱情，细腻的友情与陪伴更打动我',
          sublabel: '两个灵魂在人世间风雨同舟的默契与抚慰',
          weights: { emotions: { comfort: 9, joy_laughter: 6 } }
        }
      ]
    },
    {
      id: 7,
      stage: 2,
      branch: 'romance',
      title: '爱意最动人的发生场景，往往是哪一幕？',
      subtitle: '细节之处见真章',
      options: [
        {
          id: 'br_rom_2_a',
          label: '异国街头毫无计划的漫步，在交谈中天光破晓',
          sublabel: '无需修饰的话题，两颗心在异乡无边夜色中贴近',
          weights: { visualAesthetics: 'retro_vintage', emotions: { romantic_longing: 9 } }
        },
        {
          id: 'br_rom_2_b',
          label: '昏黄狭窄的楼梯拐角，擦肩而过的旗袍与西装',
          sublabel: '那一低头的温柔与克制，所有心事都被光影藏起',
          weights: { visualAesthetics: 'warm_golden', storytellingPacing: 'slow' }
        },
        {
          id: 'br_rom_2_c',
          label: '雨中奔跑大笑，在简陋却温馨的厨房共享一碗热面',
          sublabel: '平凡日子里最真实的烟火温热',
          weights: { visualAesthetics: 'gritty_realistic', emotions: { comfort: 9 } }
        },
        {
          id: 'br_rom_2_d',
          label: '冬日海边迎着凛冽寒风，坐在结冰的沙滩上无言对视',
          sublabel: '即使爱情在消逝，回忆依然如海浪般清晰',
          weights: { visualAesthetics: 'minimalist_clean', emotions: { melancholy: 8 } }
        },
        {
          id: 'br_rom_2_e',
          label: '落日下双人起舞，跳着笨拙又快乐的舞步',
          sublabel: '紫色晚霞成为背景，只要身旁是你就足够',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { joy_laughter: 8 } }
        },
        {
          id: 'br_rom_2_f',
          label: '时隔多年的重逢，在人潮中相视一笑却无从开口',
          sublabel: '千帆过尽后的从容与释怀',
          weights: { emotions: { catharsis: 9, existential_reflection: 8 } }
        }
      ]
    },
    {
      id: 8,
      stage: 2,
      branch: 'romance',
      title: '对于电影里的“结局”，你的心理预期是？',
      subtitle: '终点会重新定义整个旅途',
      options: [
        {
          id: 'br_rom_3_a',
          label: '必须大团圆！历经千难险阻终于紧紧相拥',
          sublabel: '人生已多风雨，电影里必须给我完满的幸福',
          weights: { endingType: 'warm_uplifting', emotions: { comfort: 10 } }
        },
        {
          id: 'br_rom_3_b',
          label: '笑着流泪的遗憾分手，但彼此都因对方变成了更好的人',
          sublabel: '不求天长地久，只求曾经照亮过彼此的生命',
          weights: { endingType: 'bitter_sweet', emotions: { catharsis: 9 } }
        },
        {
          id: 'br_rom_3_c',
          label: '开放式留白，停留在他们转身或对视的最后一秒',
          sublabel: '把未来的无限可能留给观众的心去续写',
          weights: { endingType: 'open_thought_provoking', emotions: { poetic_wonder: 8 } }
        },
        {
          id: 'br_rom_3_d',
          label: '深刻的心碎挽歌，用痛彻心扉印证爱的厚度',
          sublabel: '唯有失去与悲剧，才能将爱铭刻为永恒的艺术',
          weights: { endingType: 'tragic_heartbreak', emotions: { melancholy: 10 } }
        },
        {
          id: 'br_rom_3_e',
          label: '平淡回归日常，生活继续流淌，爱化为静默陪伴',
          sublabel: '不是童话的终结，而是真实日子的启航',
          weights: { storytellingStyle: 'character_driven', emotions: { existential_reflection: 8 } }
        },
        {
          id: 'br_rom_3_f',
          label: '出人意料的转折，爱情在另一种维度得到奇妙升华',
          sublabel: '超越生死或世俗定义的精神相伴',
          weights: { endingType: 'mind_twist', emotions: { poetic_wonder: 9 } }
        }
      ]
    },
    {
      id: 9,
      stage: 2,
      branch: 'romance',
      title: '你更喜欢哪种主角对话风格？',
      subtitle: '声音与对白是情感流动的载体',
      options: [
        {
          id: 'br_rom_4_a',
          label: '机智敏锐、互相接梗的诙谐调侃',
          sublabel: '在言语过招中感受智力旗鼓相当的快乐',
          weights: { emotions: { joy_laughter: 8 }, storytellingPacing: 'fast' }
        },
        {
          id: 'br_rom_4_b',
          label: '关于宇宙、哲学与人生的深夜知性畅谈',
          sublabel: '思想先于肉体相爱，灵魂的共鸣才是极致性感',
          weights: { emotions: { intellectual_stimulation: 9, romantic_longing: 8 } }
        },
        {
          id: 'br_rom_4_c',
          label: '少言寡语，全靠微表情、眼神与呼吸声交流',
          sublabel: '沉默胜过千言万语，东方特有的含蓄留白',
          weights: { visualAesthetics: 'minimalist_clean', storytellingPacing: 'slow' }
        },
        {
          id: 'br_rom_4_d',
          label: '直白炽热、毫不掩饰的深情表白',
          sublabel: '爱就要大声喊出来，撕心裂肺的热烈',
          weights: { emotions: { catharsis: 9 } }
        },
        {
          id: 'br_rom_4_e',
          label: '书信式的优美旁白与呢喃自语',
          sublabel: '像一首读不完的情诗，字字句句浸透着墨香',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { poetic_wonder: 9 } }
        },
        {
          id: 'br_rom_4_f',
          label: '日常琐碎的闲聊唠叨，像真实生活一样亲切自然',
          sublabel: '今天吃了什么、天气如何，在细水长流中慢慢老去',
          weights: { emotions: { comfort: 8 }, storytellingStyle: 'character_driven' }
        }
      ]
    },
    {
      id: 10,
      stage: 2,
      branch: 'romance',
      title: '你心中的“高级浪漫感”是由什么构成的？',
      subtitle: '区分平庸甜宠与真正经典的审美分水岭',
      options: [
        {
          id: 'br_rom_5_a',
          label: '彼此独立完整，不依附也不拯救，两个世界的平等重叠',
          sublabel: '你是自由的，我也是自由的，但我们选择携手',
          weights: { storytellingStyle: 'character_driven', emotions: { intellectual_stimulation: 8 } }
        },
        {
          id: 'br_rom_5_b',
          label: '克制的欲言又止与体面的退让',
          sublabel: '懂得何时放手，比占有更需要惊人的教养与深情',
          weights: { storytellingPacing: 'slow', emotions: { melancholy: 8 } }
        },
        {
          id: 'br_rom_5_c',
          label: '对抗整个冷漠世界的唯一避风港',
          sublabel: '无论外面风雨多大，关上门这里就是整个宇宙',
          weights: { emotions: { comfort: 10 } }
        },
        {
          id: 'br_rom_5_d',
          label: '绝美的视听艺术加持：古典管弦乐与油画级构图',
          sublabel: '电影不仅在讲故事，更是一场极致的美学洗礼',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { poetic_wonder: 10 } }
        },
        {
          id: 'br_rom_5_e',
          label: '跨越漫长时光依然不褪色的默契回忆',
          sublabel: '青丝变白发，眼中依然盛着初见时的那束光',
          weights: { visualAesthetics: 'retro_vintage', emotions: { comfort: 9 } }
        },
        {
          id: 'br_rom_5_f',
          label: '打破世俗规则的叛逆与不屈生命力',
          sublabel: '就算与世界为敌，我也要奔向你',
          weights: { emotions: { thrill: 7, catharsis: 8 } }
        }
      ]
    }
  ],

  // BRANCH 2: MYSTERY & CRIME
  mystery_crime: [
    {
      id: 6,
      stage: 2,
      branch: 'mystery_crime',
      title: '哪种悬疑侦探类型最能让你欲罢不能？',
      subtitle: '推理世界的不同流派',
      options: [
        {
          id: 'br_mys_1_a',
          label: '暴风雪山庄经典阿加莎式本格推理',
          sublabel: '所有人被困在孤岛或古堡，每个人都有作案动机与秘密',
          weights: { storytellingStyle: 'puzzle_investigation', emotions: { intellectual_stimulation: 10 } }
        },
        {
          id: 'br_mys_1_b',
          label: '不到最后一秒猜不透的惊天大反转（Mind Twist）',
          sublabel: '全片所有铺垫都在颠覆你原本建立的全部认知',
          weights: { endingType: 'mind_twist', emotions: { thrill: 9, intellectual_stimulation: 9 } }
        },
        {
          id: 'br_mys_1_c',
          label: '神探与高智商罪犯的双雄心理博弈',
          sublabel: '棋逢对手的眼神交锋，猫鼠游戏的智力极限',
          weights: { storytellingStyle: 'character_driven', emotions: { intellectual_stimulation: 10 } }
        },
        {
          id: 'br_mys_1_d',
          label: '冷硬派社会派刑侦：深入雨夜都市的罪恶土壤',
          sublabel: '不只破案，更揭露体制沉疴与人心不可直视的阴暗面',
          weights: { visualAesthetics: 'noir_nocturnal', emotions: { existential_reflection: 8 } }
        },
        {
          id: 'br_mys_1_e',
          label: '阴郁压迫的悬疑氛围感，未知的恐惧如影随形',
          sublabel: '比凶手是谁更让人窒息的，是笼罩小镇的古怪气氛',
          weights: { storytellingPacing: 'slow', visualAesthetics: 'noir_nocturnal' }
        },
        {
          id: 'br_mys_1_f',
          label: '带有一丝黑色幽默与荒诞巧合的罪案多线叙事',
          sublabel: '几个倒霉蛋因为巧合撞在一起，引发连锁反应',
          weights: { emotions: { joy_laughter: 8 }, storytellingPacing: 'fast' }
        }
      ]
    },
    {
      id: 7,
      stage: 2,
      branch: 'mystery_crime',
      title: '你希望探寻真相的过程中，电影如何呈现信息？',
      subtitle: '视角与参与感的博弈',
      options: [
        {
          id: 'br_mys_2_a',
          label: '公平对决：所有线索早已摆在明面上，考验观众洞察力',
          sublabel: '没有机械降神，只要细心就能和侦探同时破案',
          weights: { storytellingStyle: 'puzzle_investigation', emotions: { intellectual_stimulation: 10 } }
        },
        {
          id: 'br_mys_2_b',
          label: '罗生门式多重视角：每个人口中的“真相”都不一样',
          sublabel: '在互相矛盾的证词拼图中拼凑出人性全貌',
          weights: { storytellingStyle: 'character_driven', emotions: { intellectual_stimulation: 9 } }
        },
        {
          id: 'br_mys_2_c',
          label: '不可靠叙述者：甚至连主角自己的记忆都存在谎言',
          sublabel: '失忆、创伤或自我欺骗，真假难辨',
          weights: { storytellingStyle: 'surreal', endingType: 'mind_twist' }
        },
        {
          id: 'br_mys_2_d',
          label: '倒计时高能推演：限时封闭空间内的法庭/审讯激辩',
          sublabel: '仅凭语言就能构筑惊涛骇浪',
          weights: { storytellingPacing: 'fast', visualAesthetics: 'minimalist_clean' }
        },
        {
          id: 'br_mys_2_e',
          label: '抽丝剥茧的慢热调查：翻阅档案、走访故人、岁月沉淀',
          sublabel: '像翻阅一部跨越数十年的尘封大案卷宗',
          weights: { storytellingPacing: 'slow', visualAesthetics: 'retro_vintage' }
        },
        {
          id: 'br_mys_2_f',
          label: '罪犯视角的逆向解构：看他们如何计划、实施与善后',
          sublabel: '紧张感来自于计划随时可能被戳破的致命破绽',
          weights: { emotions: { thrill: 9 } }
        }
      ]
    },
    {
      id: 8,
      stage: 2,
      branch: 'mystery_crime',
      title: '你更倾心怎样的破案主角人设？',
      subtitle: '领航者的性格决定故事气韵',
      options: [
        {
          id: 'br_mys_3_a',
          label: '儒雅得体、叼着烟斗或喝着红茶的古典大侦探',
          sublabel: '举止优雅，眼神如鹰，凭借纯脑力破解迷局',
          weights: { visualAesthetics: 'retro_vintage', emotions: { intellectual_stimulation: 9 } }
        },
        {
          id: 'br_mys_3_b',
          label: '满身疲惫、身陷酗酒与中年危机的沧桑硬汉老刑警',
          sublabel: '虽被生活摧残，但骨子里依旧坚守着最后一丝正义底线',
          weights: { visualAesthetics: 'gritty_realistic', storytellingStyle: 'character_driven' }
        },
        {
          id: 'br_mys_3_c',
          label: '神经质的天才怪咖，行事反传统却直击本质',
          sublabel: '不按常理出牌，思维跳跃让身边所有人抓狂',
          weights: { emotions: { joy_laughter: 7, intellectual_stimulation: 9 } }
        },
        {
          id: 'br_mys_3_d',
          label: '偶然被卷入阴谋的平凡普通人，在求生中步步反杀',
          sublabel: '没有金手指，全凭急智与本能在绝境中自保',
          weights: { emotions: { thrill: 9, catharsis: 8 } }
        },
        {
          id: 'br_mys_3_e',
          label: '冷静深沉、甚至带有冷血色彩的心理侧写专家',
          sublabel: '能瞬间看透人性的弱点与恐惧源泉',
          weights: { visualAesthetics: 'minimalist_clean', emotions: { intellectual_stimulation: 10 } }
        },
        {
          id: 'br_mys_3_f',
          label: '性格互补的一老一少搭档，彼此碰撞摩擦出火花',
          sublabel: '经验与冲劲的交织，在破案中建立亦师亦友的羁绊',
          weights: { storytellingStyle: 'character_driven', emotions: { comfort: 6 } }
        }
      ]
    },
    {
      id: 9,
      stage: 2,
      branch: 'mystery_crime',
      title: '对于罪案背后的动机与人性探讨，你期待看到什么？',
      subtitle: '好的悬疑片最终是人性的照妖镜',
      options: [
        {
          id: 'br_mys_4_a',
          label: '凶手并非纯粹的恶棍，而是被残酷命运逼入绝境的悲剧小人物',
          sublabel: '法律上他有罪，但情感上让人忍不住为他深深叹息',
          weights: { emotions: { catharsis: 9, melancholy: 8 } }
        },
        {
          id: 'br_mys_4_b',
          label: '纯粹精密的贪婪与阴谋，权贵阶层的虚伪假面被无情戳穿',
          sublabel: '撕开所谓体面与财富之下的肮脏溃烂',
          weights: { emotions: { intellectual_stimulation: 9, thrill: 7 } }
        },
        {
          id: 'br_mys_4_c',
          label: '哲学层面的病态执念与对神圣宿命的偏执理解',
          sublabel: '布道式作案，探讨人类原罪与现代文明的异化',
          weights: { storytellingStyle: 'philosophical', emotions: { existential_reflection: 9 } }
        },
        {
          id: 'br_mys_4_d',
          label: '家族世仇与深藏几十年的血亲恩怨',
          sublabel: '老一辈留下的诅咒，在这一代结出罪恶的花朵',
          weights: { visualAesthetics: 'retro_vintage', storytellingPacing: 'balanced' }
        },
        {
          id: 'br_mys_4_e',
          label: '为了保护最深爱之人所做出的绝望牺牲',
          sublabel: '这起案子从头到尾，只是一个关于爱的巨大谎言',
          weights: { emotions: { romantic_longing: 8, catharsis: 9 } }
        },
        {
          id: 'br_mys_4_f',
          label: '冷酷的制度漏洞与程序正义的艰难博弈',
          sublabel: '在规则与良知之间，正义究竟该如何得到伸张',
          weights: { emotions: { intellectual_stimulation: 9 } }
        }
      ]
    },
    {
      id: 10,
      stage: 2,
      branch: 'mystery_crime',
      title: '当真相揭晓的那一刻，你希望得到怎样的回甘？',
      subtitle: '案子结了，但故事才刚刚沉入心底',
      options: [
        {
          id: 'br_mys_5_a',
          label: '恍然大悟的智力通畅感，所有谜团严丝合缝闭合',
          sublabel: '如同解开了一道精妙绝伦的数学难题，极度爽快',
          weights: { endingType: 'warm_uplifting', emotions: { intellectual_stimulation: 10 } }
        },
        {
          id: 'br_mys_5_b',
          label: '细思极恐的背脊发凉，真相背后原来还隐藏着更深的黑暗',
          sublabel: '案件虽然告破，但更大的阴影刚刚张开翅膀',
          weights: { endingType: 'mind_twist', emotions: { thrill: 9 } }
        },
        {
          id: 'br_mys_5_c',
          label: '正义虽然迟到，但最终以坚韧的代价得以告慰',
          sublabel: '温暖而庄重的释然，为死者讨回尊严',
          weights: { endingType: 'warm_uplifting', emotions: { comfort: 8, catharsis: 8 } }
        },
        {
          id: 'br_mys_5_d',
          label: '无可奈何的怅惘，每个人都是受害者，没有真正的赢家',
          sublabel: '合上卷宗，只有窗外无休止的冷雨洗刷着街头',
          weights: { endingType: 'bitter_sweet', emotions: { melancholy: 9 } }
        },
        {
          id: 'br_mys_5_e',
          label: '主角战胜心魔、走出阴霾的心灵重生',
          sublabel: '查清了案子，也终于放下了困扰自己多年的创伤',
          weights: { endingType: 'warm_uplifting', emotions: { comfort: 9 } }
        },
        {
          id: 'br_mys_5_f',
          label: '一个意味深长的留白笑容或小动作，留给观众无尽猜想',
          sublabel: '他真的就是凶手吗？留白是最高的艺术',
          weights: { endingType: 'open_thought_provoking', emotions: { poetic_wonder: 8 } }
        }
      ]
    }
  ],

  // BRANCH 3: SCI-FI & FANTASY
  scifi_fantasy: [
    {
      id: 6,
      stage: 2,
      branch: 'scifi_fantasy',
      title: '你最心向往之的科幻或奇幻命题是什么？',
      subtitle: '放飞想象力的边界',
      options: [
        {
          id: 'br_sci_1_a',
          label: '浩瀚深空探索：黑洞、虫洞与跨越星系的苍茫远征',
          sublabel: '在浩瀚无垠的宇宙面前，感受人类渺小而伟大的爱',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { poetic_wonder: 10 } }
        },
        {
          id: 'br_sci_1_b',
          label: '时间维度的精妙博弈：时间循环、平行宇宙与祖父悖论',
          sublabel: '在时间的莫比乌斯环里寻找改变宿命的微小钥匙',
          weights: { storytellingStyle: 'philosophical', emotions: { intellectual_stimulation: 10 } }
        },
        {
          id: 'br_sci_1_c',
          label: '赛博朋克与人工智能意识：人类与机械的灵魂边界',
          sublabel: '霓虹雨夜、复制人的悲歌、记忆植入与自我的真实性',
          weights: { visualAesthetics: 'noir_nocturnal', emotions: { existential_reflection: 10 } }
        },
        {
          id: 'br_sci_1_d',
          label: '瑰丽神话异世界：神灵、魔法生物与古典魔幻史诗',
          sublabel: '拥有独立严谨世界观的奇幻大陆与英雄远征',
          weights: { emotions: { escapism: 10, poetic_wonder: 9 } }
        },
        {
          id: 'br_sci_1_e',
          label: '近未来反乌托邦预言：科技垄断下的社会异化与个人反抗',
          sublabel: '寓言式的警世之作，反思技术对人性的悄然剥夺',
          weights: { storytellingStyle: 'philosophical', emotions: { intellectual_stimulation: 9 } }
        },
        {
          id: 'br_sci_1_f',
          label: '软科幻温暖日常：一个小小的奇幻设定改善平凡生活',
          sublabel: '能够穿越回过去的衣柜、懂人类语言的机器人邻居',
          weights: { emotions: { comfort: 10, joy_laughter: 7 }, endingType: 'warm_uplifting' }
        }
      ]
    },
    {
      id: 7,
      stage: 2,
      branch: 'scifi_fantasy',
      title: '你更喜欢硬核科学逻辑，还是诗意浪漫意象？',
      subtitle: '科幻谱系的两端',
      options: [
        {
          id: 'br_sci_2_a',
          label: '硬核严谨：严守天体物理法则与科学理论推演',
          sublabel: '扎实的科学地基让震撼具有无与伦比的真实分量',
          weights: { emotions: { intellectual_stimulation: 10 } }
        },
        {
          id: 'br_sci_2_b',
          label: '极致诗意：把宇宙拍成一首关于爱与思念的深情诗篇',
          sublabel: '科技只是外壳，穿透时间和空间的永恒引力是爱',
          weights: { emotions: { poetic_wonder: 10, romantic_longing: 8 } }
        },
        {
          id: 'br_sci_2_c',
          label: '超现实脑洞：梦境层叠、重力翻转、视听奇观拉满',
          sublabel: '打破所有常规认知，带来纯粹的感官颠覆',
          weights: { storytellingStyle: 'surreal', emotions: { thrill: 8, poetic_wonder: 9 } }
        },
        {
          id: 'br_sci_2_d',
          label: '手绘水彩般的童话美学：温暖奇幻与纯真自然融为一体',
          sublabel: '绿意盎然的飞天扫帚、水上列车与毛茸茸的守护神',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { comfort: 10 } }
        },
        {
          id: 'br_sci_2_e',
          label: '冷峻极简主义：纯白太空舱、机械对称与几何美感',
          sublabel: '极具未来工业设计感的冷冽克制美学',
          weights: { visualAesthetics: 'minimalist_clean', storytellingPacing: 'slow' }
        },
        {
          id: 'br_sci_2_f',
          label: '废土蒸汽朋克：黄沙漫天、钢铁齿轮与末日重金属',
          sublabel: '粗粝野性的机械浪漫，文明衰退后的野蛮生机',
          weights: { visualAesthetics: 'gritty_realistic', emotions: { thrill: 9 } }
        }
      ]
    },
    {
      id: 8,
      stage: 2,
      branch: 'scifi_fantasy',
      title: '如果未来科技高度发达，你最关心的核心命题是？',
      subtitle: '科幻的终极归宿是哲学',
      options: [
        {
          id: 'br_sci_3_a',
          label: '记忆被篡改或消除后，我们还是原本的那个自己吗？',
          sublabel: '灵魂的本质是由记忆定义的，还是由当下的感受定义？',
          weights: { storytellingStyle: 'philosophical', emotions: { existential_reflection: 10 } }
        },
        {
          id: 'br_sci_3_b',
          label: '如果机器拥有了真挚的情感，人类是否还能自诩高等？',
          sublabel: '硅基生命对碳基生命的爱，可能比人类更加纯粹',
          weights: { emotions: { romantic_longing: 8, poetic_wonder: 9 } }
        },
        {
          id: 'br_sci_3_c',
          label: '如果注定知道结局的悲伤，我们是否依然选择经历这一生？',
          sublabel: '非线性时间观下对宿命的主动拥抱',
          weights: { endingType: 'bitter_sweet', emotions: { catharsis: 9 } }
        },
        {
          id: 'br_sci_3_d',
          label: '生活在一个虚假但完美的乌托邦，还是痛苦但真实的荒野？',
          sublabel: '楚门推开那扇门的勇气，对真实自由的永恒追求',
          weights: { endingType: 'warm_uplifting', emotions: { existential_reflection: 9 } }
        },
        {
          id: 'br_sci_3_e',
          label: '当人类文明面临绝境，道德与生存哪个该排在前面？',
          sublabel: '极端环境考验下的文明尊严与黑暗森林法理',
          weights: { emotions: { thrill: 8, intellectual_stimulation: 9 } }
        },
        {
          id: 'br_sci_3_f',
          label: '在无边宇宙孤独深处，人类能否找到同类甚至神迹？',
          sublabel: '对未知的敬畏，以及在星辰彼岸寻回对地球家园的眷恋',
          weights: { emotions: { poetic_wonder: 10 } }
        }
      ]
    },
    {
      id: 9,
      stage: 2,
      branch: 'scifi_fantasy',
      title: '你更喜欢哪种视听配乐风格来衬托世界观？',
      subtitle: '音乐是构建奇幻维度的无形画笔',
      options: [
        {
          id: 'br_sci_4_a',
          label: '恢弘震撼的教堂管风琴与交响乐（如汉斯·季默风格）',
          sublabel: '如同宇宙潮汐般澎湃涌来，撼动灵魂',
          weights: { emotions: { poetic_wonder: 10, thrill: 8 } }
        },
        {
          id: 'br_sci_4_b',
          label: '空灵纯净的久石让式长笛与钢琴变奏',
          sublabel: '瞬间唤醒童年所有的纯粹与感动',
          weights: { emotions: { comfort: 10 } }
        },
        {
          id: 'br_sci_4_c',
          label: '复古合成器浪潮（Synthwave）与低沉电子脉冲',
          sublabel: '迷幻霓虹律动，自带孤独时髦的未来感',
          weights: { visualAesthetics: 'noir_nocturnal' }
        },
        {
          id: 'br_sci_4_d',
          label: '古典交响乐与圆舞曲反差使用（如《蓝色多瑙河》漫步太空）',
          sublabel: '用古典的优雅衬托宇宙的冷酷庄严',
          weights: { visualAesthetics: 'retro_vintage', storytellingPacing: 'slow' }
        },
        {
          id: 'br_sci_4_e',
          label: '原始民族乐器、重金属电吉他与呼麦战吼',
          sublabel: '狂野充满生命力，激发最原始的荷尔蒙冲撞',
          weights: { emotions: { thrill: 10 }, storytellingPacing: 'fast' }
        },
        {
          id: 'br_sci_4_f',
          label: '近乎死寂的环境自然音效（风声、水滴、深空虚无）',
          sublabel: '以静制动，最大化凸显空间浩瀚与压迫',
          weights: { visualAesthetics: 'minimalist_clean', storytellingPacing: 'slow' }
        }
      ]
    },
    {
      id: 10,
      stage: 2,
      branch: 'scifi_fantasy',
      title: '一部伟大的科幻/奇幻电影离开时，应当在你的心上留下什么？',
      subtitle: '走出影院那一刻的恍惚',
      options: [
        {
          id: 'br_sci_5_a',
          label: '仰望今晚夜空的繁星，重获对宇宙与生命的无上敬畏',
          sublabel: '感觉自己的烦恼在亿万光年尺度前瞬间释怀',
          weights: { emotions: { poetic_wonder: 10, comfort: 8 } }
        },
        {
          id: 'br_sci_5_b',
          label: '迫不及待想拥抱身边心爱的人，因为爱跨越了维度',
          sublabel: '把科幻的宏大化作对眼前人真真切切的珍惜',
          weights: { emotions: { romantic_longing: 9, comfort: 9 }, endingType: 'warm_uplifting' }
        },
        {
          id: 'br_sci_5_c',
          label: '脑海里翻江倒海，拼命推演每个时间节点与隐喻细节',
          sublabel: '兴奋到睡不着觉，只想立刻看解析写影评',
          weights: { emotions: { intellectual_stimulation: 10 } }
        },
        {
          id: 'br_sci_5_d',
          label: '重新找回像孩子一样相信童话与魔法的清澈目光',
          sublabel: '坚信这个世界上一定有守护神在悄悄陪伴自己',
          weights: { emotions: { comfort: 10, joy_laughter: 8 } }
        },
        {
          id: 'br_sci_5_e',
          label: '对人类历史与未来的深刻警醒与独立批判思考',
          sublabel: '保持清醒，不被技术的假象裹挟',
          weights: { emotions: { existential_reflection: 10 } }
        },
        {
          id: 'br_sci_5_f',
          label: '纯粹视听奇观洗礼后的酣畅快感，精神满电复活',
          sublabel: '像经历了一场跨维度的过山车，太爽了',
          weights: { emotions: { thrill: 9, escapism: 9 } }
        }
      ]
    }
  ],

  // BRANCH 4: ART-HOUSE & REALISTIC DRAMA
  arthouse_drama: [
    {
      id: 6,
      stage: 2,
      branch: 'arthouse_drama',
      title: '你更倾心哪种类型的文艺现实质感？',
      subtitle: '现实主义光谱的聚焦点',
      options: [
        {
          id: 'br_art_1_a',
          label: '日式家庭与日常细碎：一餐一饭皆是人生滋味',
          sublabel: '梅子酒、夏日天妇罗、微风拂过的回廊，在平淡中见深沉',
          weights: { visualAesthetics: 'warm_golden', emotions: { comfort: 10 }, storytellingPacing: 'slow' }
        },
        {
          id: 'br_art_1_b',
          label: '严肃存在主义沉思：探讨孤独、衰老、死亡与救赎',
          sublabel: '北欧大师级的光影，直面生命最核心的沉重命题',
          weights: { storytellingStyle: 'philosophical', emotions: { existential_reflection: 10 } }
        },
        {
          id: 'br_art_1_c',
          label: '女性自我觉醒与细腻凝视：打破规训的隐秘光芒',
          sublabel: '油画般的肖像、无声的抗争、灵魂深处的相惜',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { poetic_wonder: 9 } }
        },
        {
          id: 'br_art_1_d',
          label: '青年成长与时代迷茫：残酷青春与无处安放的激情',
          sublabel: '奔跑在没有尽头的海滩，青春在阵痛中悄然拔节',
          weights: { storytellingStyle: 'character_driven', emotions: { melancholy: 9 } }
        },
        {
          id: 'br_art_1_e',
          label: '宏大时代浪潮下的家族变迁与世事浮沉',
          sublabel: '如同一部厚重的史诗小说，收纳数十年的人间真相',
          weights: { visualAesthetics: 'minimalist_clean', emotions: { existential_reflection: 9 } }
        },
        {
          id: 'br_art_1_f',
          label: '边缘小人物的苦中作乐与底层微光',
          sublabel: '虽然身处泥淖，但依然仰望星空，闪烁着人性的神圣',
          weights: { visualAesthetics: 'gritty_realistic', emotions: { catharsis: 9 } }
        }
      ]
    },
    {
      id: 7,
      stage: 2,
      branch: 'arthouse_drama',
      title: '你如何看待电影中的“留白与沉默”？',
      subtitle: '声画之间的间隙艺术',
      options: [
        {
          id: 'br_art_2_a',
          label: '留白才是电影的最高境界，不发一语却震耳欲聋',
          sublabel: '眼神的停顿、空镜头里的云卷云舒，胜过千句直白台词',
          weights: { storytellingPacing: 'slow', emotions: { poetic_wonder: 10 } }
        },
        {
          id: 'br_art_2_b',
          label: '喜欢文学性极强的深刻对白，每句台词都像一本好书',
          sublabel: '精雕细琢的哲理言辞，值得拿笔记本摘抄回味',
          weights: { emotions: { intellectual_stimulation: 9, existential_reflection: 9 } }
        },
        {
          id: 'br_art_2_c',
          label: '更依靠肢体语言与人物微动作传递情感',
          sublabel: '削苹果的方式、整理衣角的迟疑，真实的生活细节',
          weights: { storytellingStyle: 'character_driven', emotions: { comfort: 8 } }
        },
        {
          id: 'br_art_2_d',
          label: '画面如诗如画即可，剧情可以作为背景音乐流淌',
          sublabel: '享受极致的光影美学熏陶，像在画廊里度过两小时',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { poetic_wonder: 10 } }
        },
        {
          id: 'br_art_2_e',
          label: '在克制中逐渐积蓄力量，在片尾爆发出一记情感惊雷',
          sublabel: '前面越平静，最后的眼泪越汹涌澎湃',
          weights: { endingType: 'bitter_sweet', emotions: { catharsis: 10 } }
        },
        {
          id: 'br_art_2_f',
          label: '带有适度自嘲幽默的现实，生活太苦所以需要笑对',
          sublabel: '不卖惨，在荒唐世相中保有幽默体面',
          weights: { emotions: { joy_laughter: 7, comfort: 8 } }
        }
      ]
    },
    {
      id: 8,
      stage: 2,
      branch: 'arthouse_drama',
      title: '关于“家庭关系”，你最能产生共鸣的切面是？',
      subtitle: '血缘纽带里的爱与伤',
      options: [
        {
          id: 'br_art_3_a',
          label: '虽然互相深爱，但因笨拙与代沟而始终难以坦白表达',
          sublabel: '中国或东亚家庭最典型的沉重温柔',
          weights: { emotions: { catharsis: 9, comfort: 8 } }
        },
        {
          id: 'br_art_3_b',
          label: '非血缘之间构建起的互助港湾，比血亲更为纯粹真挚',
          sublabel: '失意之人在人海中拼凑起的新家',
          weights: { emotions: { comfort: 10 }, endingType: 'warm_uplifting' }
        },
        {
          id: 'br_art_3_c',
          label: '勇敢打破家庭的期待枷锁，走向真正的自我独立',
          sublabel: '即使带着伤痛，也要成为自己人生的主人',
          weights: { emotions: { existential_reflection: 9 } }
        },
        {
          id: 'br_art_3_d',
          label: '岁月无情流逝，面对父母逐渐衰老与离去的无力挽歌',
          sublabel: '在时光长河面前，学会告别与释怀',
          weights: { emotions: { melancholy: 10, catharsis: 9 } }
        },
        {
          id: 'br_art_3_e',
          label: '兄弟姐妹之间在争吵、嫉妒与互相扶持中长大',
          sublabel: '最懂你糗事也最在暗中为你撑腰的人',
          weights: { emotions: { comfort: 9, joy_laughter: 6 } }
        },
        {
          id: 'br_art_3_f',
          label: '婚姻从热烈走向平淡乃至解体过程中的真实撕扯',
          sublabel: '探讨亲密关系在现实琐碎中的保质期',
          weights: { storytellingStyle: 'character_driven', emotions: { existential_reflection: 8 } }
        }
      ]
    },
    {
      id: 9,
      stage: 2,
      branch: 'arthouse_drama',
      title: '哪种导演的美学印记最容易击中你的心？',
      subtitle: '大师镜头下的世界温度',
      options: [
        {
          id: 'br_art_4_a',
          label: '是枝裕和式的温润日常：清淡如水却回味甘甜',
          sublabel: '不批判、不煽情，静静注视着生命自然舒展',
          weights: { visualAesthetics: 'warm_golden', emotions: { comfort: 10 } }
        },
        {
          id: 'br_art_4_b',
          label: '杨德昌式的冷静剖析：精准如手术刀剖析现代都市人性',
          sublabel: '大画幅沉稳镜头，直击中产阶级的精神困境',
          weights: { visualAesthetics: 'minimalist_clean', emotions: { intellectual_stimulation: 9 } }
        },
        {
          id: 'br_art_4_c',
          label: '王家卫式的醉生梦死：光影摇曳、独白呢喃与时代惆怅',
          sublabel: '浓郁的感性浪漫，每一帧都是醉人的情绪琥珀',
          weights: { visualAesthetics: 'warm_golden', emotions: { poetic_wonder: 9, romantic_longing: 9 } }
        },
        {
          id: 'br_art_4_d',
          label: '维姆·文德斯式的诗意漫游：在最不起眼的日常中捕捉神圣',
          sublabel: '听磁带、给盆栽浇水、拍树叶光斑，发现生活本真的禅意',
          weights: { visualAesthetics: 'minimalist_clean', emotions: { existential_reflection: 10 } }
        },
        {
          id: 'br_art_4_e',
          label: '伯格曼式的心理深渊：人与自我的搏斗、信仰与虚无对峙',
          sublabel: '黑白面孔的特写，直视灵魂深处最恐惧的镜子',
          weights: { visualAesthetics: 'retro_vintage', emotions: { existential_reflection: 10 } }
        },
        {
          id: 'br_art_4_f',
          label: '李沧东式的社会阵痛与诗意燃烧：底层青年的无声呐喊',
          sublabel: '在现实的残忍荒野中，依然燃烧着不可磨灭的尊严',
          weights: { visualAesthetics: 'gritty_realistic', emotions: { catharsis: 10 } }
        }
      ]
    },
    {
      id: 10,
      stage: 2,
      branch: 'arthouse_drama',
      title: '你希望这部艺术电影对你的现实生活产生什么影响？',
      subtitle: '艺术映照生活的意义',
      options: [
        {
          id: 'br_art_5_a',
          label: '放慢呼吸，学会珍惜每一个平凡普通的当下瞬间',
          sublabel: '不再为未来的焦虑绑架，重新发现阳光与风的美好',
          weights: { emotions: { comfort: 10, existential_reflection: 9 } }
        },
        {
          id: 'br_art_5_b',
          label: '允许自己脆弱和不完美，与过去的伤痛握手言和',
          sublabel: '不再苛求事事如意，原谅生命中无法挽回的遗憾',
          weights: { emotions: { catharsis: 10, comfort: 8 } }
        },
        {
          id: 'br_art_5_c',
          label: '获得更广阔的同理心，更温柔地理解身边那些古怪的人',
          sublabel: '看见每个人背后的不易与隐痛，多一份宽容',
          weights: { emotions: { comfort: 9, intellectual_stimulation: 8 } }
        },
        {
          id: 'br_art_5_d',
          label: '激发自己的创作欲与对美的敏感感知力',
          sublabel: '想要写下一段文字、拍下一张照片，记录生命的痕迹',
          weights: { emotions: { poetic_wonder: 10 } }
        },
        {
          id: 'br_art_5_e',
          label: '获得直面现实生活的勇气与不妥协的傲骨',
          sublabel: '虽然看清了世界的荒诞，但依然热烈地生活下去',
          weights: { emotions: { catharsis: 9 } }
        },
        {
          id: 'br_art_5_f',
          label: '享受一段纯净的精神避风港，静静洗涤浮躁杂念',
          sublabel: '不需要任何答案，沉浸在纯粹的宁静之中',
          weights: { visualAesthetics: 'minimalist_clean', emotions: { comfort: 9 } }
        }
      ]
    }
  ],

  // BRANCH 5: COMEDY & LIGHTHEARTED
  comedy_light: [
    {
      id: 6,
      stage: 2,
      branch: 'comedy_light',
      title: '今晚你最期待哪种风格的幽默欢笑？',
      subtitle: '笑点与幽默机制的精确定位',
      options: [
        {
          id: 'br_com_1_a',
          label: '机智诙谐的英美式幽默：台词满分、笑料高级而不低俗',
          sublabel: '节奏紧凑、人物可爱，让人会心一笑又忍俊不禁',
          weights: { storytellingPacing: 'fast', emotions: { joy_laughter: 10 } }
        },
        {
          id: 'br_com_1_b',
          label: '荒诞离奇的多线巧合：几组笨蛋碰在一起引发大混乱',
          sublabel: '黑色幽默拉满，事情一步步滑向滑稽不可控的深渊',
          weights: { storytellingStyle: 'plot_driven', emotions: { joy_laughter: 10, thrill: 7 } }
        },
        {
          id: 'br_com_1_c',
          label: '暖心治愈的合家欢喜剧：笑中带泪，看完浑身暖洋洋',
          sublabel: '怪咖家庭在公路旅行中吵吵闹闹，最后紧紧拥抱',
          weights: { endingType: 'warm_uplifting', emotions: { comfort: 10, joy_laughter: 9 } }
        },
        {
          id: 'br_com_1_d',
          label: '极致对称美学的童话喜剧：画面如甜点般赏心悦目',
          sublabel: '韦斯·安德森式的奇趣旅程，强迫症福利',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { joy_laughter: 8, poetic_wonder: 9 } }
        },
        {
          id: 'br_com_1_e',
          label: '跨越阶级与身份的忘年挚友互怼：反差萌十足',
          sublabel: '贵族与混混、暴躁大叔与纯真少年，毫无保留的平等欢笑',
          weights: { storytellingStyle: 'character_driven', emotions: { joy_laughter: 9, comfort: 9 } }
        },
        {
          id: 'br_com_1_f',
          label: '辛辣犀利的讽刺喜剧：用荒诞解构现实沉疴与名利场',
          sublabel: '大笑之余，让人直呼讽刺得太精辟、太扎心',
          weights: { emotions: { joy_laughter: 9, intellectual_stimulation: 8 } }
        }
      ]
    },
    {
      id: 7,
      stage: 2,
      branch: 'comedy_light',
      title: '你更喜欢哪种主角组合来带来快乐？',
      subtitle: '人物化学反应是喜剧的灵魂',
      options: [
        {
          id: 'br_com_2_a',
          label: '反差极大的一对活宝搭档（例如：精致贵族 vs 粗线条混混）',
          sublabel: '三观完全不同的人碰撞在一起，互相改变彼此的轨迹',
          weights: { storytellingStyle: 'character_driven', emotions: { joy_laughter: 9, comfort: 8 } }
        },
        {
          id: 'br_com_2_b',
          label: '全员皆怪咖的奇葩家庭：各有各的精神状态与执念',
          sublabel: '一大家子没有一个正常人，但关键时刻比谁都讲义气',
          weights: { emotions: { joy_laughter: 10, comfort: 8 } }
        },
        {
          id: 'br_com_2_c',
          label: '天真烂漫甚至有点古怪的少女，悄悄给身边人制造奇迹',
          sublabel: '古灵精怪的法式小恶作剧，浪漫又无厘头',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { joy_laughter: 8, comfort: 9 } }
        },
        {
          id: 'br_com_2_d',
          label: '看似威严实则笨拙傲娇的成年人与机灵古怪的孩子',
          sublabel: '大人装酷屡屡吃瘪，在温情守护中找回纯真童心',
          weights: { visualAesthetics: 'warm_golden', emotions: { joy_laughter: 9, comfort: 10 } }
        },
        {
          id: 'br_com_2_e',
          label: '一个特立独行、挑战僵化体制的热血天才与他的倒霉室友',
          sublabel: '高燃励志与无厘头恶搞齐飞，笑到肚子疼又深受鼓舞',
          weights: { emotions: { joy_laughter: 10, catharsis: 9 } }
        },
        {
          id: 'br_com_2_f',
          label: '被生活反复暴击却依然嘴碎自嘲的普通打工人',
          sublabel: '句句都是社畜嘴替，吐槽精准让人拍大腿狂笑',
          weights: { visualAesthetics: 'retro_vintage', emotions: { joy_laughter: 9 } }
        }
      ]
    },
    {
      id: 8,
      stage: 2,
      branch: 'comedy_light',
      title: '在喜剧故事的结尾，你最希望获得的心态？',
      subtitle: '欢笑过后的精神补给',
      options: [
        {
          id: 'br_com_3_a',
          label: '重拾对生活的信心：天塌下来也有解决办法，“All is well”！',
          sublabel: '充满能量，感觉明天上班又能充满干劲了',
          weights: { endingType: 'warm_uplifting', emotions: { comfort: 10, joy_laughter: 9 } }
        },
        {
          id: 'br_com_3_b',
          label: '完全卸下防备，只想和喜欢的人喝一杯吃顿大餐',
          sublabel: '轻松惬意，把所有烦心事彻底抛诸脑后',
          weights: { endingType: 'warm_uplifting', emotions: { comfort: 9 } }
        },
        {
          id: 'br_com_3_c',
          label: '嘴角挂着笑意，眼里泛着感动的泪光',
          sublabel: '真挚纯洁的爱化解了一切偏见与隔阂',
          weights: { endingType: 'warm_uplifting', emotions: { catharsis: 8, comfort: 9 } }
        },
        {
          id: 'br_com_3_d',
          label: '带着一丝淡淡的怀旧惆怅：时代变了，但优雅与幽默永存',
          sublabel: '像合上一本泛黄但精巧至极的立体童话书',
          weights: { endingType: 'bitter_sweet', emotions: { poetic_wonder: 8 } }
        },
        {
          id: 'br_com_3_e',
          label: '释怀于自己的平凡：做一个快乐的普通人也是一种伟大',
          sublabel: '不被世俗的成功学绑架，原谅自己的不完美',
          weights: { endingType: 'warm_uplifting', emotions: { comfort: 10 } }
        },
        {
          id: 'br_com_3_f',
          label: '大呼过瘾！这波阴差阳错的反转脑洞简直太神了',
          sublabel: '智力与笑点的双重满足，意犹未尽',
          weights: { emotions: { joy_laughter: 9, intellectual_stimulation: 8 } }
        }
      ]
    },
    {
      id: 9,
      stage: 2,
      branch: 'comedy_light',
      title: '你更喜欢哪种节奏与视听风格的喜剧？',
      subtitle: '欢笑的节拍器',
      options: [
        {
          id: 'br_com_4_a',
          label: '连珠炮般的密集台词，句句有梗、笑料不断',
          sublabel: '需要集中注意力，生怕漏掉一个绝妙的包袱',
          weights: { storytellingPacing: 'fast', emotions: { joy_laughter: 10 } }
        },
        {
          id: 'br_com_4_b',
          label: '轻快动感的爵士乐与摇滚乐驱动，身体不由自主跟着摇摆',
          sublabel: '视听节奏极佳，像一场轻松惬意的派对',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { joy_laughter: 8 } }
        },
        {
          id: 'br_com_4_c',
          label: '慢悠悠的乡间微风与冷面笑匠的呆萌反差',
          sublabel: '不急不躁，在安静中突然爆出一个令人喷饭的笑点',
          weights: { storytellingPacing: 'slow', visualAesthetics: 'warm_golden' }
        },
        {
          id: 'br_com_4_d',
          label: '精致对称的古典构图，人物像发条玩具般滑稽运动',
          sublabel: '每一个镜头都是一幅可爱的插画',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { poetic_wonder: 9 } }
        },
        {
          id: 'br_com_4_e',
          label: '充满歌舞与热烈色彩的异国风情大狂欢',
          sublabel: '载歌载舞，把生命的热情挥洒得淋漓尽致',
          weights: { emotions: { joy_laughter: 9, escapism: 8 } }
        },
        {
          id: 'br_com_4_f',
          label: '自然写实派日常对话，毫无表演痕迹的天然幽默',
          sublabel: '就像坐在隔壁桌偷听朋友们讲八卦一样亲切好笑',
          weights: { storytellingStyle: 'character_driven', visualAesthetics: 'gritty_realistic' }
        }
      ]
    },
    {
      id: 10,
      stage: 2,
      branch: 'comedy_light',
      title: '对于喜剧中的“情感内核”，你的态度是？',
      subtitle: '笑声背后是否有深度',
      options: [
        {
          id: 'br_com_5_a',
          label: '纯粹无脑解压！今晚我只想开怀大笑，拒绝任何强行升华',
          sublabel: '快乐本身就是最高价值，不需要说教',
          weights: { emotions: { joy_laughter: 10, escapism: 9 } }
        },
        {
          id: 'br_com_5_b',
          label: '笑中带泪的深情内核：大笑过后能触动最柔软的心房',
          sublabel: '最好的喜剧往往藏着对人性的深沉慈悲',
          weights: { emotions: { catharsis: 9, comfort: 9 } }
        },
        {
          id: 'br_com_5_c',
          label: '浪漫甜蜜的情愫交织：一边爆笑一边被甜到打滚',
          sublabel: '双倍的快乐，幽默是爱情最好的春药',
          weights: { emotions: { romantic_longing: 9, joy_laughter: 8 } }
        },
        {
          id: 'br_com_5_d',
          label: '对社会现实与偏见的犀利反抗与讽刺',
          sublabel: '用笑声撕碎傲慢与荒谬，让人痛快击掌',
          weights: { emotions: { intellectual_stimulation: 9, joy_laughter: 8 } }
        },
        {
          id: 'br_com_5_e',
          label: '关于友谊与守护的承诺：无论发生什么，我们都在一起',
          sublabel: '在风雨中互相照亮的小人物情义',
          weights: { emotions: { comfort: 10 } }
        },
        {
          id: 'br_com_5_f',
          label: '拥抱生活的荒诞：既然世界这么荒谬，不如举杯同乐',
          sublabel: '以超然豁达的心态看待人生的起起落落',
          weights: { emotions: { existential_reflection: 8, joy_laughter: 8 } }
        }
      ]
    }
  ],

  // BRANCH 6: ADVENTURE & ACTION
  adventure_action: [
    {
      id: 6,
      stage: 2,
      branch: 'adventure_action',
      title: '你最渴望体验哪种热血与冒险情境？',
      subtitle: '内心的探索者渴望奔向何方',
      options: [
        {
          id: 'br_adv_1_a',
          label: '走出舒适圈的公路远行：冰岛、雪山、大海与未知的世界',
          sublabel: '踏上一场找回自我生命激情的灵魂蜕变大冒险',
          weights: { emotions: { escapism: 10, poetic_wonder: 9 }, endingType: 'warm_uplifting' }
        },
        {
          id: 'br_adv_1_b',
          label: '高能炸裂的重金属视听风暴：末日荒原狂飙与纯粹肉搏',
          sublabel: '全程无冷场，肾上腺素冲刷每一个毛孔的工业奇迹',
          weights: { emotions: { thrill: 10 }, storytellingPacing: 'fast' }
        },
        {
          id: 'br_adv_1_c',
          label: '壮丽磅礴的奇幻史诗远征：骑士、精灵与护戒之盟',
          sublabel: '跨越千山万水的誓约，在绝境中守护光明',
          weights: { emotions: { poetic_wonder: 10, thrill: 8, comfort: 8 } }
        },
        {
          id: 'br_adv_1_d',
          label: '荒野孤独生存求真：只身走进冰封阿拉斯加荒原',
          sublabel: '剥离一切现代社会的虚伪，直面最原始纯粹的自然与心灵',
          weights: { storytellingStyle: 'philosophical', emotions: { existential_reflection: 10 } }
        },
        {
          id: 'br_adv_1_e',
          label: '极速街头漂移与节拍枪战：踩着重低音音乐节奏飙车',
          sublabel: '时髦帅气、动感十足的酷炫动作爽片',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { thrill: 9 } }
        },
        {
          id: 'br_adv_1_f',
          label: '茫茫大海上的奇幻漂流：一人一虎与发光水母神迹',
          sublabel: '生存博弈与东方哲理意境的完美融合',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { poetic_wonder: 10 } }
        }
      ]
    },
    {
      id: 7,
      stage: 2,
      branch: 'adventure_action',
      title: '你更看重动作场景中的哪种特质？',
      subtitle: '身体与画面的动感追求',
      options: [
        {
          id: 'br_adv_2_a',
          label: '实打实的实拍特技与机械轰鸣，拒绝虚假绿幕特效',
          sublabel: '真实的重力和火药，带来无可替代的物理冲击感',
          weights: { visualAesthetics: 'gritty_realistic', emotions: { thrill: 10 } }
        },
        {
          id: 'br_adv_2_b',
          label: '极致的大自然壮美风光：航拍雪山、冰川、星空与海浪',
          sublabel: '每一帧都能直接当作壁纸的视觉盛宴',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { poetic_wonder: 10 } }
        },
        {
          id: 'br_adv_2_c',
          label: '音乐与动作的无缝咬合：刹车声和换弹夹都踩在鼓点上',
          sublabel: '像一场华丽过瘾的动作交响乐',
          weights: { storytellingPacing: 'fast', emotions: { joy_laughter: 7 } }
        },
        {
          id: 'br_adv_2_d',
          label: '古典西部的凝视与正午决斗：拔枪瞬间生死立判',
          sublabel: '漫长的眼神对峙与呼吸凝固，张力拉满',
          weights: { visualAesthetics: 'retro_vintage', storytellingPacing: 'balanced' }
        },
        {
          id: 'br_adv_2_e',
          label: '智勇双全的破局反杀：利用物理常识和地形以少胜多',
          sublabel: '不靠蛮力，全凭智慧在绝境中杀出重围',
          weights: { emotions: { intellectual_stimulation: 8, thrill: 9 } }
        },
        {
          id: 'br_adv_2_f',
          label: '浪漫豪情与救赎：为了心爱之人生死相随',
          sublabel: '行动的背后是誓死不渝的深情',
          weights: { emotions: { romantic_longing: 8, catharsis: 9 } }
        }
      ]
    },
    {
      id: 8,
      stage: 2,
      branch: 'adventure_action',
      title: '在一段未知的长途冒险中，你最向往的同行者是？',
      subtitle: '旅途上的灵魂伙伴',
      options: [
        {
          id: 'br_adv_3_a',
          label: '独自一人独自漫游，享受完全属于自己的心灵静谧',
          sublabel: '与大自然和自己的潜意识对话，找回失落的自我',
          weights: { storytellingStyle: 'character_driven', emotions: { existential_reflection: 10 } }
        },
        {
          id: 'br_adv_3_b',
          label: '并肩作战、把后背毫无保留托付给对方的生死兄弟',
          sublabel: '“我不能替你背负，但我能背负你”的生死羁绊',
          weights: { emotions: { comfort: 9, catharsis: 9 } }
        },
        {
          id: 'br_adv_3_c',
          label: '一个棋逢对手、亦敌亦友的强劲伙伴',
          sublabel: '在竞争与合作中逼出各自最强大的潜能',
          weights: { emotions: { thrill: 8, intellectual_stimulation: 8 } }
        },
        {
          id: 'br_adv_3_d',
          label: '一只充满灵性甚至凶猛但逐渐产生信任的动物',
          sublabel: '跨越物种的默契，在茫茫荒野中的唯一慰藉',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { comfort: 8, poetic_wonder: 9 } }
        },
        {
          id: 'br_adv_3_e',
          label: '为爱亡命天涯的爱人，携手冲破所有世俗阻碍',
          sublabel: '天地虽大，唯有彼此才是归宿',
          weights: { emotions: { romantic_longing: 9 } }
        },
        {
          id: 'br_adv_3_f',
          label: '性格迥异、各怀绝技的团队成员，在磨合中成为传奇',
          sublabel: '每个人都有高光时刻，各司其职打出漂亮战役',
          weights: { storytellingPacing: 'fast', emotions: { joy_laughter: 7 } }
        }
      ]
    },
    {
      id: 9,
      stage: 2,
      branch: 'adventure_action',
      title: '你更喜欢怎样的地理与空间舞台？',
      subtitle: '宏大场景的坐标系',
      options: [
        {
          id: 'br_adv_4_a',
          label: '北欧冰原、火山熔岩与格陵兰无垠冰海',
          sublabel: '冷色调的壮阔地球尽头，极度洗涤心灵',
          weights: { visualAesthetics: 'minimalist_clean', emotions: { poetic_wonder: 10 } }
        },
        {
          id: 'br_adv_4_b',
          label: '狂野沙漠废原与重金属机械钢铁城堡',
          sublabel: '灼热的黄沙与喷火的战车，野性十足',
          weights: { visualAesthetics: 'gritty_realistic', emotions: { thrill: 10 } }
        },
        {
          id: 'br_adv_4_c',
          label: '中世纪古堡、幽暗森林与宏伟的白石圣城',
          sublabel: '古典神话的梦境故乡，史诗感拉满',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { escapism: 10 } }
        },
        {
          id: 'br_adv_4_d',
          label: '浩瀚汪洋中的一叶孤舟与暴风雨怒涛',
          sublabel: '在深不可测的大海中央直面生存与神迹',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { poetic_wonder: 9 } }
        },
        {
          id: 'br_adv_4_e',
          label: '现代繁华大都市的高空吊桥、地下隧道与天台追逐',
          sublabel: '城市钢筋水泥丛林里的惊险特工博弈',
          weights: { visualAesthetics: 'noir_nocturnal', storytellingPacing: 'fast' }
        },
        {
          id: 'br_adv_4_f',
          label: '黄沙漫漫的美墨边境小镇与烈日孤阳',
          sublabel: '口哨声中的复古牛仔决斗场',
          weights: { visualAesthetics: 'retro_vintage', emotions: { thrill: 8 } }
        }
      ]
    },
    {
      id: 10,
      stage: 2,
      branch: 'adventure_action',
      title: '冒险结束回归现实时，你期望获得什么心境？',
      subtitle: '英雄凯旋后的心灵余音',
      options: [
        {
          id: 'br_adv_5_a',
          label: '重燃对平凡生活的热爱：不再空想，真正迈出改变的第一步',
          sublabel: '“去看世界，面对危险，这就是生活的意义”',
          weights: { endingType: 'warm_uplifting', emotions: { comfort: 10, catharsis: 9 } }
        },
        {
          id: 'br_adv_5_b',
          label: '纯粹被史诗悲壮所震撼的泪水与长久肃然起敬',
          sublabel: '见证了崇高勇气的力量，久久不能平静',
          weights: { endingType: 'warm_uplifting', emotions: { catharsis: 10, poetic_wonder: 9 } }
        },
        {
          id: 'br_adv_5_c',
          label: '明白了“快乐只有在分享时才真实”的深刻领悟',
          sublabel: '向往荒野，但最终懂得了人与人联结的珍贵',
          weights: { endingType: 'bitter_sweet', emotions: { existential_reflection: 10 } }
        },
        {
          id: 'br_adv_5_d',
          label: '酣畅淋漓的复仇大快人心，压抑已久的情绪瞬间爆发',
          sublabel: '正义战胜邪恶，坏人得到最痛快的惩戒',
          weights: { endingType: 'warm_uplifting', emotions: { thrill: 9, catharsis: 9 } }
        },
        {
          id: 'br_adv_5_e',
          label: '体会到生命虽然凶险，但勇敢面对它本身就是奇迹',
          sublabel: '在暴风雨后迎来的日出，格外的温暖刺目',
          weights: { endingType: 'warm_uplifting', emotions: { comfort: 9 } }
        },
        {
          id: 'br_adv_5_f',
          label: '享受了一场最畅快痛快的视觉大片，全身轻松毫无压力',
          sublabel: '痛痛快快爽过，今晚做个热血好梦',
          weights: { emotions: { escapism: 9, joy_laughter: 8 } }
        }
      ]
    }
  ],

  // BRANCH 7: HORROR & PSYCHOLOGICAL THRILLER
  horror_thriller: [
    {
      id: 6,
      stage: 2,
      branch: 'horror_thriller',
      title: '什么样的惊悚与恐怖体验最能激发你的神经？',
      subtitle: '恐惧的不同艺术维度',
      options: [
        {
          id: 'br_hor_1_a',
          label: '大师级心理惊悚：大雪封山古老饭店里逐步崩塌的理智',
          sublabel: '不用廉价跳吓，靠对称构图与逼仄空间让人背脊发凉',
          weights: { visualAesthetics: 'retro_vintage', emotions: { thrill: 10, intellectual_stimulation: 8 } }
        },
        {
          id: 'br_hor_1_b',
          label: '社会讽刺与诡异催眠：表面礼貌下令人毛骨悚然的阴谋',
          sublabel: '日常微笑背后的寒意，细思极恐的隐形控制',
          weights: { storytellingStyle: 'puzzle_investigation', emotions: { thrill: 9, intellectual_stimulation: 9 } }
        },
        {
          id: 'br_hor_1_c',
          label: '大卫·林奇式梦魇潜意识：真实与幻象撕裂的清醒噩梦',
          sublabel: '如同跌入深渊的蓝色盒子，艺术感与窒息感拉满',
          weights: { storytellingStyle: 'surreal', visualAesthetics: 'noir_nocturnal' }
        },
        {
          id: 'br_hor_1_d',
          label: '家庭创伤与跨代邪教宿命：蚀骨入髓的绝望压迫',
          sublabel: 'A24美学巅峰，将家庭裂痕雕刻得比任何恶魔更真切',
          weights: { storytellingPacing: 'slow', endingType: 'tragic_heartbreak' }
        },
        {
          id: 'br_hor_1_e',
          label: '艺术走火入魔与双重人格撕裂：黑天鹅在镜中蜕变',
          sublabel: '对完美的偏执追求最终吞噬了自我的肉体与灵魂',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { catharsis: 10 } }
        },
        {
          id: 'br_hor_1_f',
          label: '幽深太空幽闭与未知生化异形追猎：极致冷冽生存战',
          sublabel: '在没有声音的太空深处，唯有一只异形在阴影中等待',
          weights: { visualAesthetics: 'noir_nocturnal', emotions: { thrill: 10 } }
        }
      ]
    },
    {
      id: 7,
      stage: 2,
      branch: 'horror_thriller',
      title: '你对“恐惧表现手法”的底线与审美偏好是？',
      subtitle: '高级恐怖与低级血腥的分野',
      options: [
        {
          id: 'br_hor_2_a',
          label: '拒绝突脸噪音（Jump Scare），全靠氛围营造与心理悬念',
          sublabel: '最深重的恐惧产生于观众自己的想象之中',
          weights: { visualAesthetics: 'minimalist_clean', emotions: { intellectual_stimulation: 9 } }
        },
        {
          id: 'br_hor_2_b',
          label: '偏好古典胶片质感与冷色调构图，像一部阴暗的艺术画册',
          sublabel: '即使是恐怖片，也必须具备高级的美学修养',
          weights: { visualAesthetics: 'retro_vintage', emotions: { poetic_wonder: 8 } }
        },
        {
          id: 'br_hor_2_c',
          label: '高智商犯罪侧写与双向凝视：在防弹玻璃前听食人魔低语',
          sublabel: '优雅与残暴的结合体，心理博弈带来极高质量的刺激',
          weights: { storytellingStyle: 'character_driven', emotions: { intellectual_stimulation: 10 } }
        },
        {
          id: 'br_hor_2_d',
          label: '暴风雨与密闭空间：窗外电闪雷鸣，屋内信任崩塌',
          sublabel: '天气与环境成为推动剧情紧绷的最佳推手',
          weights: { visualAesthetics: 'noir_nocturnal', emotions: { thrill: 9 } }
        },
        {
          id: 'br_hor_2_e',
          label: '怪诞超现实视听：诡异的声效、倒带的录像带与暗门',
          sublabel: '颠覆感官常理，探索精神世界的不可名状',
          weights: { storytellingStyle: 'surreal', emotions: { poetic_wonder: 8 } }
        },
        {
          id: 'br_hor_2_f',
          label: '适度有生存反抗与反杀快感，不希望主角一味任人宰割',
          sublabel: '面对恶魔也能拿起武器打出帅气反击',
          weights: { emotions: { thrill: 9, catharsis: 8 } }
        }
      ]
    },
    {
      id: 8,
      stage: 2,
      branch: 'horror_thriller',
      title: '哪种空间环境最能唤醒你内心的紧张感？',
      subtitle: '恐怖地点的建筑心理学',
      options: [
        {
          id: 'br_hor_3_a',
          label: '大雪封山、空无一人但回荡着打字机声的豪华度假大饭店',
          sublabel: '走廊长得看不见尽头，尽头转角可能就是血水瀑布',
          weights: { visualAesthetics: 'retro_vintage', emotions: { thrill: 10 } }
        },
        {
          id: 'br_hor_3_b',
          label: '幽暗孤岛上的灯塔或精神病院，飓风切断了一切外界联络',
          sublabel: '面对不可靠的医生、看守与自己逐渐失控的记忆',
          weights: { visualAesthetics: 'noir_nocturnal', emotions: { intellectual_stimulation: 9 } }
        },
        {
          id: 'br_hor_3_c',
          label: '表面阳光明媚、修剪得整整齐齐的富人区郊区庄园',
          sublabel: '最恐怖的事情往往发生在阳光灿烂的白昼',
          weights: { visualAesthetics: 'minimalist_clean', emotions: { thrill: 9 } }
        },
        {
          id: 'br_hor_3_d',
          label: '夜深人静时的芭蕾排练厅，四面水银镜映出扭曲身影',
          sublabel: '镜子里的人动作比你慢了一秒',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { catharsis: 9 } }
        },
        {
          id: 'br_hor_3_e',
          label: '太空货运飞船冷凝水滴落的阴暗工业金属管道深处',
          sublabel: '幽闭窒息，雷达上的绿点正一步步向你靠近',
          weights: { visualAesthetics: 'noir_nocturnal', emotions: { thrill: 10 } }
        },
        {
          id: 'br_hor_3_f',
          label: '夜幕下的好莱坞山顶豪宅或寂静剧院的暗红幕布背后',
          sublabel: '名利场的欲望噩梦，神秘的红发歌伶在无声啼哭',
          weights: { visualAesthetics: 'noir_nocturnal', emotions: { poetic_wonder: 9 } }
        }
      ]
    },
    {
      id: 9,
      stage: 2,
      branch: 'horror_thriller',
      title: '你更喜欢主角在面对恐怖时展现怎样的状态？',
      subtitle: '主角的反应是共情的纽带',
      options: [
        {
          id: 'br_hor_4_a',
          label: '冷静理智、意志如铁，在惊恐中依然保持敏锐洞察',
          sublabel: '克拉丽斯直视汉尼拔的眼睛，用勇气克制颤抖',
          weights: { storytellingStyle: 'character_driven', emotions: { intellectual_stimulation: 10 } }
        },
        {
          id: 'br_hor_4_b',
          label: '逐步走向偏执与疯狂，在自我怀疑中走向毁灭与蜕变',
          sublabel: '看着主角一步步跨入深渊，令人心惊肉跳',
          weights: { storytellingStyle: 'character_driven', emotions: { catharsis: 10 } }
        },
        {
          id: 'br_hor_4_c',
          label: '机警敏锐，察觉细微不对劲便果断寻找逃脱生路',
          sublabel: '不作死、不降智，展现人类最高生存智商',
          weights: { storytellingPacing: 'fast', emotions: { thrill: 9 } }
        },
        {
          id: 'br_hor_4_d',
          label: '身陷创伤泥潭的母亲或父亲，为了保护孩子爆发潜能',
          sublabel: '母爱与父爱成为直面邪恶的最后护身符',
          weights: { emotions: { comfort: 7, catharsis: 9 } }
        },
        {
          id: 'br_hor_4_e',
          label: '像侦探一样在破碎幻象中拼凑真相的失忆者',
          sublabel: '随着真相揭开，自己原来就是那个关键棋子',
          weights: { endingType: 'mind_twist', emotions: { intellectual_stimulation: 9 } }
        },
        {
          id: 'br_hor_4_f',
          label: '绝命逃亡中的孤独战神，拿起喷火器战斗到底',
          sublabel: '太空第一女战神的铁血强悍',
          weights: { emotions: { thrill: 10, escapism: 8 } }
        }
      ]
    },
    {
      id: 10,
      stage: 2,
      branch: 'horror_thriller',
      title: '惊悚体验过后，你最希望收获什么？',
      subtitle: '恐惧的心理宣泄终点',
      options: [
        {
          id: 'br_hor_5_a',
          label: '重获安全的踏实感：关掉屏幕，由衷感叹现实生活的宁静可贵',
          sublabel: '通过一场人造的惊悚，释放平时的内耗与焦虑',
          weights: { endingType: 'warm_uplifting', emotions: { comfort: 10, catharsis: 9 } }
        },
        {
          id: 'br_hor_5_b',
          label: '被无与伦比的电影视听美学与构图彻底征服',
          sublabel: '不仅是一场惊悚，更是一场殿堂级的艺术享受',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { poetic_wonder: 10 } }
        },
        {
          id: 'br_hor_5_c',
          label: '沉浸在深层心理学隐喻中，反复咀嚼人性背后的幽暗',
          sublabel: '看懂了电影里的怪物，其实就是我们自己心中的心魔',
          weights: { storytellingStyle: 'philosophical', emotions: { existential_reflection: 10 } }
        },
        {
          id: 'br_hor_5_d',
          label: '反转震惊到从沙发上跳起来，拍手惊呼编剧太神了',
          sublabel: '极致的悬念落地，回味无穷',
          weights: { endingType: 'mind_twist', emotions: { thrill: 9, intellectual_stimulation: 10 } }
        },
        {
          id: 'br_hor_5_e',
          label: '为主角悲壮凄美的人生蜕变洒下一掬同情与震撼的眼泪',
          sublabel: '“它是完美的。”凄美与残酷在这一刻升华为崇高',
          weights: { endingType: 'tragic_heartbreak', emotions: { catharsis: 10 } }
        },
        {
          id: 'br_hor_5_f',
          label: '今晚彻底清醒，精神饱满，享受肾上腺素余温',
          sublabel: '比喝三杯冰美式还提神提气',
          weights: { emotions: { thrill: 9 } }
        }
      ]
    }
  ],

  // BRANCH 8: GENERAL EXPLORATION (For balanced / unclear preferences)
  general_exploration: [
    {
      id: 6,
      stage: 2,
      branch: 'general_exploration',
      title: '你更喜欢电影将聚光灯打在什么样的人物身上？',
      subtitle: '角色的质感是一部电影的灵魂',
      options: [
        {
          id: 'br_gen_1_a',
          label: '才华横溢但孤独疏离的天才或艺术家',
          sublabel: '与周遭世界格格不入，在自己的精神世界里灼灼发光',
          weights: { storytellingStyle: 'character_driven', emotions: { poetic_wonder: 9, melancholy: 7 } }
        },
        {
          id: 'br_gen_1_b',
          label: '满身缺点但真实可亲的小人物或普通打工人',
          sublabel: '在生活的泥潭中依然保持着笨拙的尊严与幽默感',
          weights: { emotions: { comfort: 10, joy_laughter: 7 } }
        },
        {
          id: 'br_gen_1_c',
          label: '背负着沉重过去或不可告人秘密的复杂神秘人物',
          sublabel: '灰度人格，善恶交织，让人捉摸不透却极具吸引力',
          weights: { storytellingStyle: 'puzzle_investigation', emotions: { intellectual_stimulation: 9 } }
        },
        {
          id: 'br_gen_1_d',
          label: '纯真无邪、用未经世俗污染的双眼看世界的孩子或动物',
          sublabel: '清澈澄净，一眼就能照穿大人们所有的伪善与荒唐',
          weights: { emotions: { comfort: 10, poetic_wonder: 8 } }
        },
        {
          id: 'br_gen_1_e',
          label: '勇敢打破时代禁锢、冲向未知的先锋女性或反叛者',
          sublabel: '不屈从世俗安排，活出独一无二的生命烈火',
          weights: { emotions: { catharsis: 9, thrill: 7 } }
        },
        {
          id: 'br_gen_1_f',
          label: '势均力敌、相知相惜又不得不分道扬镳的知己宿敌',
          sublabel: '只有彼此才真正懂对方全部的痛苦与高度',
          weights: { emotions: { romantic_longing: 8, intellectual_stimulation: 8 } }
        }
      ]
    },
    {
      id: 7,
      stage: 2,
      branch: 'general_exploration',
      title: '如果用一味饮品来比喻你今晚期待的电影风味，它像？',
      subtitle: '感官通感的奇妙联想',
      options: [
        {
          id: 'br_gen_2_a',
          label: '一杯温暖浓郁的热可可：甜而不腻，暖透冰冷身心',
          sublabel: '治愈系经典，看完只想安心裹紧被子入睡',
          weights: { emotions: { comfort: 10 }, endingType: 'warm_uplifting' }
        },
        {
          id: 'br_gen_2_b',
          label: '一杯加冰的单麦芽威士忌：泥煤烟熏、沉郁回甘、入口辛烈',
          sublabel: '需要人生阅历去细细体味的老派深度与醇厚',
          weights: { visualAesthetics: 'retro_vintage', emotions: { existential_reflection: 9 } }
        },
        {
          id: 'br_gen_2_c',
          label: '一杯气泡充足的冰镇香槟：果香四溢、轻快愉悦、微醺微甜',
          sublabel: '时髦浪漫，让神经跟着飞扬起舞',
          weights: { emotions: { joy_laughter: 9, romantic_longing: 7 } }
        },
        {
          id: 'br_gen_2_d',
          label: '一杯回甘悠长的高山清茶：初品微苦，而后满口生津',
          sublabel: '东方留白意境，静水流深，余音绕梁',
          weights: { visualAesthetics: 'minimalist_clean', storytellingPacing: 'slow' }
        },
        {
          id: 'br_gen_2_e',
          label: '一杯纯黑冰美式：苦涩纯粹、清醒提神、直击天灵盖',
          sublabel: '逻辑硬核，不加多余感情糖精，直面现实骨感',
          weights: { storytellingStyle: 'puzzle_investigation', emotions: { intellectual_stimulation: 10 } }
        },
        {
          id: 'br_gen_2_f',
          label: '一杯色彩斑斓的热带特调鸡尾酒：层次丰富、惊喜连连',
          sublabel: '天马行空的视听奇观，充满异域风情与魔幻想象',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { escapism: 9 } }
        }
      ]
    },
    {
      id: 8,
      stage: 2,
      branch: 'general_exploration',
      title: '你更喜欢电影如何处理“时间的流逝”？',
      subtitle: '时光是电影最具魔法的雕刻刀',
      options: [
        {
          id: 'br_gen_3_a',
          label: '浓缩于短短一夜或一天的紧凑戏剧：如同发生在眼前的奇遇',
          sublabel: '从日落到日出，几个小时改变两个人的一生',
          weights: { storytellingPacing: 'balanced', emotions: { romantic_longing: 8 } }
        },
        {
          id: 'br_gen_3_b',
          label: '跨越数十年、见证一个人从童年到苍老的时光长河',
          sublabel: '真实记录岁月痕迹，感受生命本身不可逆转的厚度',
          weights: { storytellingStyle: 'character_driven', emotions: { existential_reflection: 10 } }
        },
        {
          id: 'br_gen_3_c',
          label: '非线性打碎重组：记忆、现在与未来交织穿梭',
          sublabel: '拼图般的叙事结构，在错位中产生奇妙化学反应',
          weights: { storytellingStyle: 'philosophical', emotions: { intellectual_stimulation: 9 } }
        },
        {
          id: 'br_gen_3_d',
          label: '顺应自然的四季流转：春樱、夏雨、秋枫、冬雪',
          sublabel: '节气物候伴随人物命运悄然起伏，温润诗意',
          weights: { visualAesthetics: 'warm_golden', storytellingPacing: 'slow' }
        },
        {
          id: 'br_gen_3_e',
          label: '分秒必争的倒计时倒计时危机：炸弹、开庭或营救',
          sublabel: '时间是最大的敌人，压迫感让人坐立难安',
          weights: { storytellingPacing: 'fast', emotions: { thrill: 10 } }
        },
        {
          id: 'br_gen_3_f',
          label: '停留在永恒童话或梦境中的“无时间感”',
          sublabel: '没有钟表催促，沉浸在纯粹无垠的精神世界',
          weights: { emotions: { escapism: 10, poetic_wonder: 9 } }
        }
      ]
    },
    {
      id: 9,
      stage: 2,
      branch: 'general_exploration',
      title: '你如何看待电影中的“现实与虚幻”关系？',
      subtitle: '电影是每秒24格的真实谎言',
      options: [
        {
          id: 'br_gen_4_a',
          label: '必须扎根于真实的泥土，虚假的空中楼阁无法打动我',
          sublabel: '真实的生活肌理，才能让人发自内心地共情与反思',
          weights: { visualAesthetics: 'gritty_realistic', emotions: { existential_reflection: 9 } }
        },
        {
          id: 'br_gen_4_b',
          label: '电影本就该是一场美梦，是现实残酷之余的造梦机',
          sublabel: '让我沉入一个比现实更美丽、更浪漫的理想国度',
          weights: { emotions: { escapism: 10, comfort: 9 } }
        },
        {
          id: 'br_gen_4_c',
          label: '虚实难辨，梦境照进现实，现实又像一场大梦',
          sublabel: '探讨潜意识与真相的交织，在迷离中探寻自我',
          weights: { storytellingStyle: 'surreal', emotions: { poetic_wonder: 9 } }
        },
        {
          id: 'br_gen_4_d',
          label: '寓言式的黑色幽默：用最荒诞的形式说出最刺骨的真话',
          sublabel: '看似光怪陆离，骨子里全是对现实最精准的隐喻',
          weights: { emotions: { joy_laughter: 8, intellectual_stimulation: 9 } }
        },
        {
          id: 'br_gen_4_e',
          label: '以小见大：从一个极小的虚构设定推演出宏大的人间法则',
          sublabel: '精巧的思想实验，带来智性与情感的双重盛宴',
          weights: { emotions: { intellectual_stimulation: 10 } }
        },
        {
          id: 'br_gen_4_f',
          label: '记录时光流逝的真实记录片感与大师诗性留白并存',
          sublabel: '像一扇透明的窗户，窗外是真实的微风与阳光',
          weights: { visualAesthetics: 'minimalist_clean', emotions: { poetic_wonder: 8 } }
        }
      ]
    },
    {
      id: 10,
      stage: 2,
      branch: 'general_exploration',
      title: '一部电影能被称为“你的年度私人佳作”，最核心的特质通常是？',
      subtitle: '衡量精神共振的最高尺度',
      options: [
        {
          id: 'br_gen_5_a',
          label: '它精准说出了我心中深藏已久、却从未找到语言表达的情绪',
          sublabel: '如同被世界上某个人隔着银幕轻轻拍了拍肩膀',
          weights: { emotions: { catharsis: 10, comfort: 10 } }
        },
        {
          id: 'br_gen_5_b',
          label: '剧本无一处废笔，逻辑、伏笔与反转设计巧夺天工',
          sublabel: '对创作者顶级才华与叙事工匠精神的五体投地',
          weights: { storytellingStyle: 'puzzle_investigation', emotions: { intellectual_stimulation: 10 } }
        },
        {
          id: 'br_gen_5_c',
          label: '画面构图与配乐绝美至极，每一秒都是纯正的视听艺术享受',
          sublabel: '光影与旋律深深烙印在记忆中，反复重温',
          weights: { visualAesthetics: 'vivid_painterly', emotions: { poetic_wonder: 10 } }
        },
        {
          id: 'br_gen_5_d',
          label: '提供了一个全新的认知视角，重塑了我打量世界的眼光',
          sublabel: '看完之后，眼前的世界似乎变得更加宽广包容',
          weights: { storytellingStyle: 'philosophical', emotions: { existential_reflection: 10 } }
        },
        {
          id: 'br_gen_5_e',
          label: '纯粹而热烈的情感共振，让我重新相信爱、善良与理想主义',
          sublabel: '像在冰冷的冬夜里喝下一大口滚烫的清泉',
          weights: { endingType: 'warm_uplifting', emotions: { romantic_longing: 9, comfort: 9 } }
        },
        {
          id: 'br_gen_5_f',
          label: '酣畅淋漓的沉浸式脱轨体验，彻底忘却了现实两个小时',
          sublabel: '真正顶级的电影造梦魔术',
          weights: { emotions: { escapism: 10, thrill: 8 } }
        }
      ]
    }
  ]
};

// ==========================================
// STAGE 3: UNIVERSAL FINAL QUESTIONS (Q11 - Q15)
// ==========================================
export const STAGE_3_QUESTIONS: QuizQuestion[] = [
  {
    id: 11,
    stage: 3,
    title: '对于今晚的电影时长，你的偏好是？',
    subtitle: '匹配你当下的精力与观影时间预算',
    options: [
      {
        id: 'q11_a',
        label: '90分钟左右：轻巧利落，节奏紧凑不费力',
        sublabel: '下班后的轻松小酌，看完刚好入睡无负担',
        weights: { durationPreference: 'short' }
      },
      {
        id: 'q11_b',
        label: '100–120分钟：黄金标准时长，情节最完整饱满',
        sublabel: '主流杰作的最佳画幅，起承转合恰到好处',
        weights: { durationPreference: 'medium' }
      },
      {
        id: 'q11_c',
        label: '130分钟以上甚至3小时：沉浸式史诗深度大片',
        sublabel: '今晚时间充裕，想完整走进一段厚重的人生旅途',
        weights: { durationPreference: 'long' }
      },
      {
        id: 'q11_d',
        label: '只要故事好，长短完全无所谓',
        sublabel: '好电影从不看表，全身心交给导演调度',
        weights: { durationPreference: 'any' }
      },
      {
        id: 'q11_e',
        label: '希望前10分钟就能迅速抓住我，绝不能慢热拖沓',
        sublabel: '开篇即高能，迅速带入主线',
        weights: { storytellingPacing: 'fast' }
      },
      {
        id: 'q11_f',
        label: '愿意给它半小时慢热铺垫，越往后越有味道',
        sublabel: '耐得住寂寞，期待后半程的层层绽放',
        weights: { storytellingPacing: 'slow' }
      }
    ]
  },
  {
    id: 12,
    stage: 3,
    title: '今晚有哪些你绝对不想碰的“内容限制 / 避雷雷区”？',
    subtitle: '【可多选】算法将严格排除强冲突的影片，守护你的观影安全感',
    isMultiSelect: true,
    options: [
      {
        id: 'res_none',
        label: '没有任何限制（放飞推荐，我心态很开放）',
        sublabel: '百无禁忌，只要是好电影我都乐意尝试',
        weights: {}
      },
      {
        id: 'res_horror',
        label: '拒绝恐怖与灵异惊吓',
        sublabel: '今晚不想提心吊胆、疑神疑鬼',
        weights: {}
      },
      {
        id: 'res_gore',
        label: '拒绝血腥暴力与生理反胃画面',
        sublabel: '对断肢、血浆、过度残暴零容忍',
        weights: {}
      },
      {
        id: 'res_tragic',
        label: '拒绝意难平悲剧或刻骨绝望收尾',
        sublabel: '心太脆了，今晚经不起虐心痛击',
        weights: { endingType: 'warm_uplifting' }
      },
      {
        id: 'res_depressing',
        label: '拒绝过度沉重压抑的社会致郁题材',
        sublabel: '不想看完胸口闷堵、叹息连连',
        weights: { endingType: 'warm_uplifting' }
      },
      {
        id: 'res_messy_romance',
        label: '拒绝狗血出轨或过于复杂扭曲的多角恋',
        sublabel: '拒绝让人闹心的背叛与撕扯',
        weights: {}
      }
    ]
  },
  {
    id: 13,
    stage: 3,
    title: '你对电影的“国家与地域文化风貌”是否有偏好？',
    subtitle: '不同地域的光影有着截然不同的温度与美学气质',
    options: [
      {
        id: 'q13_a',
        label: '华语典藏与经典港台：母语语境下的东方细腻情思',
        sublabel: '王家卫的霓虹暗夜、杨德昌的沉静反思、经典武侠或市井烟火',
        weights: { regions: ['中国香港', '中国台湾', '中国大陆'] }
      },
      {
        id: 'q13_b',
        label: '欧洲艺术与英法浪漫：优雅、诗意、哲学与古典光影',
        sublabel: '法国左岸的咖啡香、英伦庄园的晨雾、意大利西西里的艳阳',
        weights: { regions: ['法国', '英国', '意大利', '德国', '西班牙'] }
      },
      {
        id: 'q13_c',
        label: '好莱坞黄金殿堂：工业成熟、故事圆融、视听视界一流',
        sublabel: '殿堂级编剧调度、教科书级演技与大荧幕奇观',
        weights: { regions: ['美国'] }
      },
      {
        id: 'q13_d',
        label: '日韩东亚美学：静水流深的日常治愈或极致社会手术刀',
        sublabel: '是枝裕和的和暖微风，或是奉俊昊的阶级隐喻',
        weights: { regions: ['日本', '韩国'] }
      },
      {
        id: 'q13_e',
        label: '小众国际视野：拉美魔幻、北欧冷冽、印度歌舞等多元视角',
        sublabel: '打破常规好莱坞框架，体验新鲜的异质文化冲击',
        weights: { regions: ['瑞典', '新西兰', '印度', '澳大利亚'] }
      },
      {
        id: 'q13_f',
        label: '世界主义：海纳百川，唯故事与艺术至上',
        sublabel: '哪个国家的无所谓，好电影没有国界',
        weights: { regions: [] }
      }
    ]
  },
  {
    id: 14,
    stage: 3,
    title: '对于电影的“时代烙印与大众知名度”，你倾向于？',
    subtitle: '在大师经典与小众宝藏之间找到平衡',
    options: [
      {
        id: 'q14_a',
        label: '冷门宝藏佳作（Hidden Gem）：高分但不烂俗，少有人发现',
        sublabel: '享受挖掘遗珠的惊喜，带有私人专属感的秘密心头好',
        weights: { popularityType: 'hidden_gem' }
      },
      {
        id: 'q14_b',
        label: '影史不朽神作（Masterpiece）：公认殿堂级经典，值得反复观摩',
        sublabel: '经受住几十年时光淘洗的无冕之王，一生必看一次',
        weights: { popularityType: 'masterpiece' }
      },
      {
        id: 'q14_c',
        label: '大众好评口碑片（Crowd Pleaser）：通俗好看、毫无门槛',
        sublabel: '高分且极度抓人，绝不踩雷，任何人都能享受其中',
        weights: { popularityType: 'crowd_pleaser' }
      },
      {
        id: 'q14_d',
        label: '90年代至00年代千禧胶片黄金时代：质感无敌，巨星璀璨',
        sublabel: '那个未被数字特效统治的纯真光影巅峰年代',
        weights: { eraType: 'retro_90s_00s' }
      },
      {
        id: 'q14_e',
        label: '近几年高分新片（2015-至今）：画质前沿、视听现代、议题切中当代',
        sublabel: '符合当下审美节奏的高清晰度现代佳作',
        weights: { eraType: 'modern_recent' }
      },
      {
        id: 'q14_f',
        label: '古典好莱坞与欧洲黑白经典（黄金年代）：老派绅士与淑女风范',
        sublabel: '在黑白光影中感受永不磨灭的优雅与尊严',
        weights: { eraType: 'classic' }
      }
    ]
  },
  {
    id: 15,
    stage: 3,
    title: '今晚这部电影，你最希望它成为你生活的哪一种存在？',
    subtitle: '最后一题，替今晚做个决定',
    options: [
      {
        id: 'q15_a',
        label: '一剂温柔的安神药：抚平焦虑，带来无条件的抚慰与安全感',
        sublabel: '今晚不需要复杂深刻，只需要被善意和美好包裹',
        weights: { emotions: { comfort: 10 }, endingType: 'warm_uplifting' }
      },
      {
        id: 'q15_b',
        label: '一把精神的手术刀：刺激思考，打破固化的思维枷锁',
        sublabel: '渴望一场酣畅淋漓的智性碰撞与哲学顿悟',
        weights: { emotions: { intellectual_stimulation: 10, existential_reflection: 9 } }
      },
      {
        id: 'q15_c',
        label: '一场美丽的梦境出逃：暂时放下现实中的烦恼与琐碎',
        sublabel: '把身心彻底交托给两个小时的绚烂光影',
        weights: { emotions: { escapism: 10, poetic_wonder: 9 } }
      },
      {
        id: 'q15_d',
        label: '一记真挚的心灵重击：痛痛快快流泪，释放深藏的委屈与柔情',
        sublabel: '给疲惫麻木的心来一场透彻的雨后初晴',
        weights: { emotions: { catharsis: 10, melancholy: 8 } }
      },
      {
        id: 'q15_e',
        label: '一缕心动的浪漫微风：重新唤醒对爱与亲密关系的渴望',
        sublabel: '让两颗心靠近的悸动在心底悄悄生根发芽',
        weights: { emotions: { romantic_longing: 10 } }
      },
      {
        id: 'q15_f',
        label: '一剂热血强心针：重燃内心的勇气，相信明天又是全新的一天',
        sublabel: '热烈、昂扬，哪怕孤身一人也有面对一切的胆气',
        weights: { emotions: { thrill: 8, comfort: 8 }, endingType: 'warm_uplifting' }
      }
    ]
  }
];

// Helper to determine the dynamic branch based on Stage 1 (Q1 - Q5) answers
export function determineDynamicBranch(stage1Answers: Record<number, string | string[]>): {
  primaryBranch: BranchId;
  secondaryBranch?: BranchId;
  transitionReason: string;
  isDualBranch: boolean;
  selectedQuestions: QuizQuestion[];
} {
  const branchScores: Record<BranchId, number> = {
    romance: 0,
    mystery_crime: 0,
    scifi_fantasy: 0,
    arthouse_drama: 0,
    comedy_light: 0,
    adventure_action: 0,
    horror_thriller: 0,
    general_exploration: 0
  };

  STAGE_1_QUESTIONS.forEach((q) => {
    const ans = stage1Answers[q.id];
    if (!ans) return;

    const optIds = Array.isArray(ans) ? ans : [ans];
    optIds.forEach((optId) => {
      const opt = q.options.find((o) => o.id === optId);
      if (opt?.weights.branches) {
        Object.entries(opt.weights.branches).forEach(([b, score]) => {
          branchScores[b as BranchId] += score || 0;
        });
      }
    });
  });

  const sortedBranches = (Object.keys(branchScores) as BranchId[])
    .filter((b) => b !== 'general_exploration')
    .sort((a, b) => branchScores[b] - branchScores[a]);

  const top1 = sortedBranches[0];
  const top2 = sortedBranches[1];
  const top1Score = branchScores[top1];
  const top2Score = branchScores[top2];

  // If unclear (scores too low or difference negligible across multiple)
  if (top1Score < 4 || (top1Score <= 6 && top1Score - top2Score < 1)) {
    return {
      primaryBranch: 'general_exploration',
      transitionReason: '你的品味兼收并蓄且情感层次丰沛，已为你开启【深度综合探索】专属分支。',
      isDualBranch: false,
      selectedQuestions: BRANCH_QUESTIONS['general_exploration']
    };
  }

  // If two branches are close (within 30% difference)
  if (top2Score > 0 && top1Score - top2Score <= 3) {
    const qBranch1 = BRANCH_QUESTIONS[top1].slice(0, 3);
    const qBranch2 = BRANCH_QUESTIONS[top2].slice(0, 2);
    // Renumber IDs to ensure 6, 7, 8, 9, 10
    const combined = [...qBranch1, ...qBranch2].map((q, idx) => ({
      ...q,
      id: 6 + idx
    }));

    const branchNames: Record<BranchId, string> = {
      romance: '浪漫与亲密关系',
      mystery_crime: '悬疑与心智博弈',
      scifi_fantasy: '科幻奇幻与宏大世界',
      arthouse_drama: '现实主义与艺术质感',
      comedy_light: '机智幽默与轻快治愈',
      adventure_action: '热血冒险与纯粹视听',
      horror_thriller: '心理惊悚与暗黑探秘',
      general_exploration: '深度综合探索'
    };

    return {
      primaryBranch: top1,
      secondaryBranch: top2,
      transitionReason: `根据前5题，你在【${branchNames[top1]}】与【${branchNames[top2]}】两端展现出同样敏锐的审美，已为你融合双重深度问答。`,
      isDualBranch: true,
      selectedQuestions: combined
    };
  }

  // Dominant branch: pick 5 from top branch
  const branchNames: Record<BranchId, string> = {
    romance: '浪漫与亲密关系',
    mystery_crime: '悬疑与心智博弈',
    scifi_fantasy: '科幻奇幻与宏大世界',
    arthouse_drama: '现实主义与艺术质感',
    comedy_light: '机智幽默与轻快治愈',
    adventure_action: '热血冒险与纯粹视听',
    horror_thriller: '心理惊悚与暗黑探秘',
    general_exploration: '深度综合探索'
  };

  return {
    primaryBranch: top1,
    transitionReason: `根据前5题，你在【${branchNames[top1]}】维度展现出强烈的审美共鸣，已为你开启定制分支。`,
    isDualBranch: false,
    selectedQuestions: BRANCH_QUESTIONS[top1]
  };
}
