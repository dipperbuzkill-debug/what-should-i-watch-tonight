/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Sparkles, ArrowRight, CheckCircle2, KeyRound, PlayCircle, Film, Compass } from 'lucide-react';
import { MOOD_IMAGES } from '../data/questions';
import { Movie } from '../types';
import { MOVIE_DATABASE } from '../data/movies';
import { MoviePoster } from './MoviePoster';

interface HeroProps {
  onStartQuiz: () => void;
  onOpenActivation: () => void;
  isActivated: boolean;
  activeCode?: string;
  onSelectMovie?: (movie: Movie) => void;
}

export const Hero: React.FC<HeroProps> = ({
  onStartQuiz,
  onOpenActivation,
  isActivated,
  activeCode,
  onSelectMovie,
}) => {
  // 5 iconic sample movies representing different genres for homepage cover preview
  const sampleMovies = MOVIE_DATABASE.filter((m) =>
    ['m1', 'm16', 'm2', 'm26', 'm19'].includes(m.id)
  );
  return (
    <div className="relative overflow-hidden pt-8 pb-16 lg:py-20">
      {/* Background paper texture & subtle warm gradient */}
      <div className="max-w-7xl mx-auto px-6">
        {/* Top Editorial Issue Ribbon */}
        <div className="flex flex-wrap items-center justify-between border-b border-[#9B8575]/30 pb-4 mb-10 text-xs tracking-widest text-[#9B8575] font-serif uppercase">
          <div className="flex items-center gap-2">
            <span>ISSUE NO. 07</span>
            <span aria-hidden="true">·</span>
            <span>CINEMATIC DISCOVERY JOURNAL</span>
            <span aria-hidden="true">·</span>
            <span>AUTUMN 2026</span>
          </div>
          <div className="flex items-center gap-3">
            {isActivated ? (
              <span className="text-[#702D32] font-semibold">
                ● 通行证已激活（{activeCode}）· 永久无限测评
              </span>
            ) : (
              <button
                onClick={onOpenActivation}
                className="hover:text-[#702D32] transition-colors underline underline-offset-4 cursor-pointer"
              >
                持有小红书兑换码？立即激活
              </button>
            )}
          </div>
        </div>

        {/* 2-Column Editorial Spread */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Headlines & Call to Action */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            <span className="text-xs font-mono tracking-[0.25em] text-[#702D32] font-semibold uppercase mb-3">
              WHAT SHOULD I WATCH TONIGHT?
            </span>
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#242321] leading-[1.15] text-balance mb-6">
              今晚，不如让电影
              <br />
              <span className="text-[#702D32] italic font-serif">替你做个决定。</span>
            </h1>

            <p className="text-base sm:text-lg text-[#242321]/80 font-serif leading-relaxed max-w-xl mb-8">
              15道深度选择题，探索你的真实情绪与视听审美。根据前5题答案动态解锁专属分支，为你定制5部绝不雷同的精美封面片单。
            </p>

            {/* Feature Metadata Ribbon - Clean unboxed text with typographic separators */}
            <div className="flex flex-wrap items-center gap-y-2 gap-x-3 text-xs sm:text-sm text-[#9B8575] font-medium mb-8">
              <span>15道精选题</span>
              <span aria-hidden="true">·</span>
              <span>约3–5分钟</span>
              <span aria-hidden="true">·</span>
              <span>一次购买</span>
              <span aria-hidden="true">·</span>
              <span>永久访问</span>
              <span aria-hidden="true">·</span>
              <span>无限次重测</span>
            </div>

            {/* Action Group */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto">
              <button
                onClick={onStartQuiz}
                className="flex items-center justify-center gap-2.5 px-8 py-3.5 bg-[#702D32] hover:bg-[#582327] text-[#F3EFE6] font-serif text-base font-semibold rounded-sm shadow-md hover:shadow-lg transition-all active:scale-[0.98] cursor-pointer"
              >
                <span>{isActivated ? '进入15题测评' : '开始今晚测评'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {!isActivated && (
                <button
                  onClick={onOpenActivation}
                  className="flex items-center justify-center gap-2 px-6 py-3.5 bg-white/70 hover:bg-white text-[#242321] border border-[#9B8575]/40 font-serif text-sm font-medium rounded-sm transition-all hover:border-[#702D32]/60 cursor-pointer"
                >
                  <KeyRound className="w-4 h-4 text-[#702D32]" />
                  <span>输入兑换码激活</span>
                </button>
              )}
            </div>

            {/* Anti-Slop Trust Note */}
            <p className="text-[12px] text-[#9B8575] font-serif mt-5">
              * 独立算法运行，不调用外接模糊AI，根据100+经典与冷门片库加权精准匹配。
            </p>
          </div>

          {/* Right Column: Editorial Visual Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-sm lg:max-w-none">
              {/* Back Card shadow offset */}
              <div className="absolute inset-0 bg-[#DED5C8] translate-x-3 translate-y-3 rounded-sm border border-[#9B8575]/30 -z-10" />

              {/* Main Editorial Image Frame */}
              <div className="relative overflow-hidden rounded-sm border border-[#9B8575]/35 bg-[#1E1D1B] shadow-xl">
                <img
                  src={MOOD_IMAGES.hero}
                  alt="Cinema projection light beam in vintage theater"
                  className="w-full aspect-[4/3] object-cover transition-transform duration-700 hover:scale-105"
                  referrerPolicy="no-referrer"
                />

                {/* Scrim Overlay & Typography */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent flex flex-col justify-end p-6 text-[#F3EFE6] text-left">
                  <span className="text-[10px] tracking-widest uppercase text-[#DED5C8] font-mono mb-1">
                    VOL. VII · CURATED SELECTION
                  </span>
                  <h3 className="font-serif text-xl sm:text-2xl font-bold leading-snug">
                    每一部被推荐的电影，
                    <br />
                    都有它独一无二的封面与理由。
                  </h3>
                  <div className="mt-3 pt-3 border-t border-white/20 flex items-center justify-between text-xs text-[#DED5C8]">
                    <span>5部专属封面片单</span>
                    <span className="font-mono">100% 独立品味计算</span>
                  </div>
                </div>
              </div>

              {/* Mini Magazine Sticker / Quote */}
              <div className="absolute -bottom-6 -left-6 hidden sm:block bg-[#F3EFE6] p-4 border border-[#9B8575]/35 shadow-lg max-w-[220px] text-left">
                <span className="block text-[9px] uppercase tracking-widest text-[#702D32] font-mono">
                  READER QUOTE
                </span>
                <p className="font-serif text-xs text-[#242321] italic mt-1 leading-relaxed">
                  “终于不用在各个APP里刷一小时预告片，最后却什么都没看了。”
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Section B: How It Works Mechanism */}
        <section id="mechanism" className="mt-24 pt-12 border-t border-[#9B8575]/25 text-left">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
            <div>
              <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#702D32]">
                THE RECOMMENDATION LOGIC
              </span>
              <h2 className="font-serif text-2xl lg:text-3xl font-bold text-[#242321] mt-1">
                拒绝同质化：三阶段动态分支探索
              </h2>
            </div>
            <p className="text-sm text-[#9B8575] font-serif max-w-md">
              两个人可能都喜欢“爱情片”，但一个人渴望甜宠治愈，另一个人渴望撕心裂肺。我们用动态分支精准区分真正差异。
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="p-6 bg-white/70 border border-[#9B8575]/25 rounded-sm flex flex-col justify-between">
              <div>
                <span className="font-mono text-xs text-[#702D32] font-semibold tracking-wider">
                  STAGE 01 · Q1–Q5
                </span>
                <h3 className="font-serif text-lg font-bold text-[#242321] mt-2 mb-3">
                  通用审美与情绪摸底
                </h3>
                <p className="text-sm text-[#242321]/75 font-serif leading-relaxed">
                  每题提供6个复合选项，多维扫描你当下最紧迫的情感需求、光影色调偏好、叙事切入点与核心雷区。
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#9B8575]/15 text-xs text-[#9B8575] font-mono">
                全员必答 · 确立基础坐标
              </div>
            </div>

            {/* Step 2 */}
            <div className="p-6 bg-white/70 border border-[#702D32]/40 rounded-sm flex flex-col justify-between relative shadow-sm">
              <div className="absolute top-3 right-3 bg-[#702D32] text-[#F3EFE6] text-[10px] px-2 py-0.5 font-mono">
                核心亮点
              </div>
              <div>
                <span className="font-mono text-xs text-[#702D32] font-semibold tracking-wider">
                  STAGE 02 · Q6–Q10
                </span>
                <h3 className="font-serif text-lg font-bold text-[#242321] mt-2 mb-3">
                  动态专属分支深入
                </h3>
                <p className="text-sm text-[#242321]/75 font-serif leading-relaxed">
                  根据前5题自动计算主次偏好，实时切换至爱情、悬疑、科幻、文艺、喜剧等8大专属题库，绝不千篇一律。
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#9B8575]/15 text-xs text-[#702D32] font-mono font-medium">
                8大分支动态选择 · 挖掘个体差异
              </div>
            </div>

            {/* Step 3 */}
            <div className="p-6 bg-white/70 border border-[#9B8575]/25 rounded-sm flex flex-col justify-between">
              <div>
                <span className="font-mono text-xs text-[#702D32] font-semibold tracking-wider">
                  STAGE 03 · Q11–Q15
                </span>
                <h3 className="font-serif text-lg font-bold text-[#242321] mt-2 mb-3">
                  观影条件与避雷确认
                </h3>
                <p className="text-sm text-[#242321]/75 font-serif leading-relaxed">
                  严谨锁定片长预算、国家地域、知名度喜好，并支持多选严格避雷（血腥、悲剧、恐怖等），确保绝对对味。
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#9B8575]/15 text-xs text-[#9B8575] font-mono">
                排雷过滤 · 生成5部精选报告
              </div>
            </div>
          </div>
        </section>

        {/* Section C: Featured Official Theatrical Posters Preview */}
        <section className="mt-20 pt-12 border-t border-[#9B8575]/25 text-left">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-3">
            <div>
              <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#702D32] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>OFFICIAL THEATRICAL POSTERS ARCHIVE</span>
              </span>
              <h2 className="font-serif text-2xl lg:text-3xl font-bold text-[#242321] mt-1">
                官方原版公映海报精选预览
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-[#9B8575] font-serif max-w-sm">
              首批严格收录影史官方发行方原版院线海报，保留真实排版构图与公映出处，点击查看高清档案。
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 sm:gap-6">
            {sampleMovies.map((movie) => (
              <div key={movie.id} className="flex flex-col">
                <MoviePoster
                  movie={movie}
                  showTitles
                  onClick={() => onSelectMovie?.(movie)}
                  className="w-full"
                />
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
