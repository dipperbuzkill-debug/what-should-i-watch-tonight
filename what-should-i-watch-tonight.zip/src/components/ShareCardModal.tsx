/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { X, Download, Copy, Check, Sparkles, Share2 } from 'lucide-react';
import { UserProfile } from '../types';
import { MoviePoster } from './MoviePoster';

function drawClapperboardFallback(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  title?: string,
  year?: number
) {
  // Clapperboard dark background
  ctx.fillStyle = '#1A1918';
  ctx.fillRect(x, y, w, h);

  // Clapper stripes bar at top
  const barH = 50;
  ctx.fillStyle = '#242321';
  ctx.fillRect(x, y, w, barH);

  // Black and white chevron stripes
  const stripeW = 28;
  for (let sx = x - 20; sx < x + w + 20; sx += stripeW * 2) {
    ctx.fillStyle = '#DED5C8';
    ctx.beginPath();
    ctx.moveTo(sx, y);
    ctx.lineTo(sx + stripeW, y);
    ctx.lineTo(sx, y + barH);
    ctx.lineTo(sx - stripeW, y + barH);
    ctx.closePath();
    ctx.fill();
  }

  // Accent divider line
  ctx.strokeStyle = '#E5A93C';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x, y + barH);
  ctx.lineTo(x + w, y + barH);
  ctx.stroke();

  // Clapperboard body metadata
  ctx.fillStyle = '#E5A93C';
  ctx.font = 'bold 12px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('SCENE: OFFICIAL RELEASE', x + 20, y + barH + 40);

  ctx.fillStyle = '#9B8575';
  ctx.font = '12px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('DATE: ' + (year || '2026') + ' · TAKE: 01', x + 20, y + barH + 65);

  // Film Title
  ctx.fillStyle = '#F3EFE6';
  ctx.font = 'bold 22px "Noto Serif SC", serif';
  ctx.fillText(title || '电影原片', x + 20, y + barH + 130);

  // Pending Status Notice Box
  ctx.fillStyle = 'rgba(155, 133, 117, 0.15)';
  ctx.fillRect(x + 16, y + h - 110, w - 32, 90);
  ctx.strokeStyle = 'rgba(155, 133, 117, 0.4)';
  ctx.lineWidth = 1;
  ctx.strokeRect(x + 16, y + h - 110, w - 32, 90);

  ctx.fillStyle = '#DED5C8';
  ctx.font = 'bold 13px "Noto Serif SC", serif';
  ctx.fillText('原版院线公映海报待补充', x + 28, y + h - 75);

  ctx.fillStyle = '#9B8575';
  ctx.font = '11px "Noto Serif SC", serif';
  ctx.fillText('严格收录官方发行原图 · 杜绝AI仿制', x + 28, y + h - 45);
}

interface ShareCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
}

export const ShareCardModal: React.FC<ShareCardModalProps> = ({
  isOpen,
  onClose,
  profile
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);

  if (!isOpen) return null;

  const topMovie = profile.recommendedTonight[0]?.movie;
  const otherMovies = profile.recommendedTonight.slice(1, 5).map((r) => r.movie);

  const handleCopyText = () => {
    const textLines = [
      `🎬 今晚看什么？ · 我的专属电影画像`,
      `【电影品味人设】：${profile.profileTitle}`,
      `“${profile.cinemaPhilosophy}”`,
      ``,
      `✨ 今晚最适合我：`,
      `《${topMovie?.chineseTitle}》 (${topMovie?.releaseYear}) · 导演：${topMovie?.director}`,
      `“${profile.recommendedTonight[0]?.categoryReason}”`,
      ``,
      `🎞 专属定制片单：`,
      ...otherMovies.map((m, idx) => `${idx + 2}. 《${m.chineseTitle}》 · ${m.genre.join('/')}`),
      ``,
      `👉 15道动态分支测评 · 探索今晚专属电影`
    ];

    navigator.clipboard.writeText(textLines.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadImage = async () => {
    if (!cardRef.current) return;
    setDownloading(true);

    try {
      // High-res canvas export via standard HTML5 Canvas draw
      const card = cardRef.current;
      const width = 1080;
      const height = 1440; // 3:4 vertical Xiaohongshu standard

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');

      if (!ctx) return;

      // 1. Draw elegant background (#F3EFE6)
      ctx.fillStyle = '#F3EFE6';
      ctx.fillRect(0, 0, width, height);

      // Subtle editorial borders
      ctx.strokeStyle = 'rgba(155, 133, 117, 0.4)';
      ctx.lineWidth = 4;
      ctx.strokeRect(36, 36, width - 72, height - 72);

      // 2. Header
      ctx.fillStyle = '#9B8575';
      ctx.font = '24px "Plus Jakarta Sans", sans-serif';
      ctx.letterSpacing = '4px';
      ctx.fillText('CINEMA DISCOVERY JOURNAL · SPECIAL ISSUE', 60, 90);

      ctx.fillStyle = '#242321';
      ctx.font = 'bold 58px "Noto Serif SC", Georgia, serif';
      ctx.fillText('今晚看什么？', 60, 165);

      ctx.fillStyle = '#702D32';
      ctx.font = 'bold 22px "Plus Jakarta Sans", sans-serif';
      ctx.letterSpacing = '6px';
      ctx.fillText('WHAT SHOULD I WATCH TONIGHT?', 420, 155);

      // Divider
      ctx.beginPath();
      ctx.moveTo(60, 195);
      ctx.lineTo(width - 60, 195);
      ctx.strokeStyle = 'rgba(112, 45, 50, 0.3)';
      ctx.lineWidth = 2;
      ctx.stroke();

      // 3. User Persona Badge
      ctx.fillStyle = '#702D32';
      ctx.fillRect(60, 230, 260, 42);
      ctx.fillStyle = '#F3EFE6';
      ctx.font = 'bold 20px "Noto Serif SC", serif';
      ctx.fillText('我的电影品味画像', 85, 258);

      ctx.fillStyle = '#242321';
      ctx.font = 'bold 50px "Noto Serif SC", serif';
      ctx.fillText(profile.profileTitle, 60, 340);

      ctx.fillStyle = '#9B8575';
      ctx.font = 'italic 24px "Noto Serif SC", Georgia, serif';
      ctx.fillText(`“${profile.cinemaPhilosophy}”`, 60, 390);

      // 4. Draw Top Recommended Film Box
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(60, 430, width - 120, 580);
      ctx.strokeStyle = 'rgba(155, 133, 117, 0.3)';
      ctx.lineWidth = 2;
      ctx.strokeRect(60, 430, width - 120, 580);

      ctx.fillStyle = '#702D32';
      ctx.font = 'bold 20px "Plus Jakarta Sans", sans-serif';
      ctx.fillText('TONIGHT\'S NO.1 MATCH · 今晚最适合你', 90, 480);

      ctx.fillStyle = '#242321';
      ctx.font = 'bold 44px "Noto Serif SC", serif';
      ctx.fillText(topMovie?.chineseTitle || '', 90, 545);

      ctx.fillStyle = '#9B8575';
      ctx.font = 'italic 24px "Noto Serif SC", serif';
      ctx.fillText(`${topMovie?.originalTitle} (${topMovie?.releaseYear}) · 导演：${topMovie?.director}`, 90, 590);

      ctx.fillStyle = '#242321';
      ctx.font = '24px "Noto Serif SC", serif';
      // Word wrap reasoning
      const reason = profile.recommendedTonight[0]?.categoryReason || topMovie?.whyRecommendedDefault || '';
      ctx.fillText(reason.slice(0, 38), 90, 650);
      if (reason.length > 38) {
        ctx.fillText(reason.slice(38, 76), 90, 690);
      }

      // Draw top movie poster on canvas (x: width - 380, y: 460, w: 280, h: 420)
      const posterX = width - 380;
      const posterY = 460;
      const posterW = 280;
      const posterH = 420;

      // Authentic Official Theatrical Poster or Clapperboard Pending Card
      const officialPosterSrc = topMovie?.hasOfficialPoster ? topMovie.officialPosterUrl : '';

      if (officialPosterSrc) {
        try {
          const img = new Image();
          img.crossOrigin = 'anonymous';
          await new Promise<void>((resolve) => {
            img.onload = () => resolve();
            img.onerror = () => resolve();
            img.src = officialPosterSrc;
          });
          if (img.complete && img.naturalWidth > 0) {
            // Draw authentic theatrical poster with crisp cover framing
            ctx.save();
            ctx.beginPath();
            ctx.rect(posterX, posterY, posterW, posterH);
            ctx.clip();
            // Calculate cover aspect ratio
            const imgAspect = img.naturalWidth / img.naturalHeight;
            const targetAspect = posterW / posterH;
            let drawW = posterW;
            let drawH = posterH;
            let drawX = posterX;
            let drawY = posterY;

            if (imgAspect > targetAspect) {
              drawW = posterH * imgAspect;
              drawX = posterX - (drawW - posterW) / 2;
            } else {
              drawH = posterW / imgAspect;
              drawY = posterY - (drawH - posterH) / 2;
            }
            ctx.drawImage(img, drawX, drawY, drawW, drawH);
            ctx.restore();

            // Authentic badge overlay on bottom
            ctx.fillStyle = 'rgba(26, 25, 24, 0.85)';
            ctx.fillRect(posterX, posterY + posterH - 32, posterW, 32);
            ctx.fillStyle = '#E5A93C';
            ctx.font = 'bold 11px "Plus Jakarta Sans", sans-serif';
            ctx.fillText('OFFICIAL THEATRICAL POSTER · 原版公映海报', posterX + 12, posterY + posterH - 12);
          } else {
            drawClapperboardFallback(ctx, posterX, posterY, posterW, posterH, topMovie?.chineseTitle, topMovie?.releaseYear);
          }
        } catch {
          drawClapperboardFallback(ctx, posterX, posterY, posterW, posterH, topMovie?.chineseTitle, topMovie?.releaseYear);
        }
      } else {
        drawClapperboardFallback(ctx, posterX, posterY, posterW, posterH, topMovie?.chineseTitle, topMovie?.releaseYear);
      }

      // Outer gold border for theatrical poster card
      ctx.strokeStyle = '#9B8575';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(posterX, posterY, posterW, posterH);

      // 5. Other Recommendations Grid
      ctx.fillStyle = '#9B8575';
      ctx.font = 'bold 22px "Plus Jakarta Sans", sans-serif';
      ctx.letterSpacing = '2px';
      ctx.fillText('CURATED SELECTIONS · 完整片单', 60, 1060);

      otherMovies.slice(0, 4).forEach((m, idx) => {
        const y = 1110 + idx * 55;
        ctx.fillStyle = '#702D32';
        ctx.font = 'bold 26px "Plus Jakarta Sans", sans-serif';
        ctx.fillText(`0${idx + 2}`, 60, y);

        ctx.fillStyle = '#242321';
        ctx.font = 'bold 26px "Noto Serif SC", serif';
        ctx.fillText(`《${m.chineseTitle}》`, 120, y);

        ctx.fillStyle = '#9B8575';
        ctx.font = '22px "Noto Serif SC", serif';
        ctx.fillText(`${m.originalTitle} (${m.releaseYear}) · ${m.genre.join('/')}`, 400, y);
      });

      // 6. Footer
      ctx.fillStyle = '#9B8575';
      ctx.font = '20px "Plus Jakarta Sans", sans-serif';
      ctx.fillText('15道题动态分支电影测评 · 小红书独家呈现', 60, 1370);
      ctx.fillText('WHAT SHOULD I WATCH TONIGHT?', width - 420, 1370);

      // Trigger download
      const dataUrl = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `今晚看什么_电影画像_${profile.profileTitle}.png`;
      a.click();
    } catch (err) {
      console.error('Image generation error:', err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto bg-[#F3EFE6] text-[#242321] rounded-sm border border-[#9B8575]/40 shadow-2xl p-6 text-left">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 text-[#9B8575] hover:text-[#242321] transition-colors rounded-sm cursor-pointer z-10"
          aria-label="关闭分享窗口"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-2 text-xs font-mono tracking-widest text-[#702D32] uppercase mb-1">
          <Share2 className="w-4 h-4" />
          <span>XIAOHONGSHU JOURNAL COVER · 小红书分享卡</span>
        </div>
        <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#242321]">
          生成专属电影杂志封面
        </h2>
        <p className="font-serif text-xs text-[#9B8575] mt-0.5">
          标准3:4竖版高清画幅，适合保存并分享到小红书、朋友圈或影迷群
        </p>

        {/* Live Preview Card */}
        <div
          ref={cardRef}
          className="my-5 p-6 bg-white border border-[#9B8575]/35 rounded-sm shadow-md aspect-[3/4] flex flex-col justify-between overflow-hidden relative"
        >
          {/* Subtle Watermark Texture */}
          <div className="absolute inset-0 opacity-5 pointer-events-none film-grain" />

          {/* Top Magazine Header */}
          <div className="border-b border-[#9B8575]/25 pb-3">
            <div className="flex items-center justify-between text-[10px] font-mono tracking-widest text-[#9B8575] uppercase">
              <span>CINEMA DISCOVERY JOURNAL</span>
              <span>SPECIAL ISSUE</span>
            </div>
            <div className="flex items-baseline justify-between mt-1">
              <h1 className="font-serif text-2xl font-black tracking-tight text-[#242321]">
                今晚看什么？
              </h1>
              <span className="font-mono text-[9px] tracking-widest text-[#702D32] uppercase">
                WHAT SHOULD I WATCH TONIGHT?
              </span>
            </div>
          </div>

          {/* Taste Persona Lockup */}
          <div className="my-3">
            <span className="inline-block bg-[#702D32] text-[#F3EFE6] text-[10px] font-mono px-2 py-0.5 mb-1.5 uppercase tracking-wider">
              我的电影品味画像
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#242321] tracking-tight">
              {profile.profileTitle}
            </h2>
            <p className="font-serif italic text-xs text-[#9B8575] mt-1 line-clamp-2">
              “{profile.cinemaPhilosophy}”
            </p>
          </div>

          {/* Top Movie Spotlight */}
          <div className="p-3.5 bg-[#F3EFE6]/70 border border-[#9B8575]/25 rounded-sm flex items-center gap-3">
            {topMovie && (
              <div className="w-16 h-24 rounded-xs overflow-hidden shrink-0 shadow-sm">
                <MoviePoster movie={topMovie} className="w-full h-full" aspectRatioClass="h-full" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <span className="text-[9px] font-mono text-[#702D32] font-semibold tracking-wider uppercase block">
                TONIGHT'S NO.1 · 今晚最适合你
              </span>
              <h3 className="font-serif text-base font-bold text-[#242321] truncate mt-0.5">
                {topMovie?.chineseTitle}
              </h3>
              <p className="text-[11px] font-serif italic text-[#9B8575] truncate">
                {topMovie?.originalTitle} ({topMovie?.releaseYear})
              </p>
              <p className="text-[11px] font-serif text-[#242321]/80 line-clamp-2 mt-1 leading-snug">
                {profile.recommendedTonight[0]?.categoryReason}
              </p>
            </div>
          </div>

          {/* Curated Selections List */}
          <div className="my-2">
            <span className="text-[10px] font-mono tracking-widest text-[#9B8575] uppercase block mb-1">
              CURATED SELECTION · 完整推荐片单
            </span>
            <div className="space-y-1">
              {otherMovies.slice(0, 3).map((m, idx) => (
                <div key={m.id} className="flex items-center justify-between text-xs font-serif">
                  <span className="font-medium text-[#242321] truncate">
                    0{idx + 2}. 《{m.chineseTitle}》
                  </span>
                  <span className="text-[11px] font-mono text-[#9B8575] shrink-0 ml-2">
                    {m.releaseYear}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Footer Bar */}
          <div className="pt-2 border-t border-[#9B8575]/20 flex items-center justify-between text-[10px] font-mono text-[#9B8575]">
            <span>15道动态分支测试 · 独家品味生成</span>
            <span className="text-[#702D32] font-bold">小红书精选推荐</span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
          <button
            onClick={handleDownloadImage}
            disabled={downloading}
            className="flex-1 w-full py-3 bg-[#702D32] hover:bg-[#582327] disabled:opacity-50 text-[#F3EFE6] font-serif text-xs sm:text-sm font-semibold rounded-sm shadow transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>{downloading ? '正在生成高清图片...' : '保存高清小红书图片 (3:4)'}</span>
          </button>

          <button
            onClick={handleCopyText}
            className="w-full sm:w-auto px-5 py-3 bg-white hover:bg-[#F3EFE6] text-[#242321] border border-[#9B8575]/40 font-serif text-xs sm:text-sm font-medium rounded-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-700" />
                <span className="text-emerald-800">文案已复制！</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-[#702D32]" />
                <span>复制片单笔记文案</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
