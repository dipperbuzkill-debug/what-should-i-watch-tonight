/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, KeyRound, ShieldCheck, AlertCircle, HelpCircle, Laptop, CheckCircle2 } from 'lucide-react';
import { getOrCreateDeviceId } from '../utils/device';

interface ActivationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (code: string) => void;
  isActivated: boolean;
  currentCode?: string;
}

export const ActivationModal: React.FC<ActivationModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  isActivated,
  currentCode
}) => {
  const [inputCode, setInputCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleActivate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputCode.trim()) {
      setErrorMessage('请输入您的兑换码');
      return;
    }

    setLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const deviceId = getOrCreateDeviceId();
      const res = await fetch('/api/activation/activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: inputCode.trim(),
          deviceId
        })
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setSuccessMessage(data.message || '激活成功！');
        setTimeout(() => {
          onSuccess(data.code);
          onClose();
        }, 1200);
      } else {
        setErrorMessage(data.message || '激活失败，请检查兑换码输入');
      }
    } catch (err) {
      console.error('Activation network error:', err);
      setErrorMessage('网络请求异常，请稍后重试');
    } finally {
      setLoading(false);
    }
  };

  const fillDemoCode = (code: string) => {
    setInputCode(code);
    setErrorMessage(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg bg-[#F3EFE6] text-[#242321] rounded-sm border border-[#9B8575]/40 shadow-2xl p-6 sm:p-8 text-left">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1 text-[#9B8575] hover:text-[#242321] transition-colors cursor-pointer"
          aria-label="关闭窗口"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-2.5 text-xs font-mono tracking-widest text-[#702D32] uppercase mb-1">
          <KeyRound className="w-4 h-4" />
          <span>ACTIVATION PASS · 兑换与激活</span>
        </div>
        <h2 className="font-serif text-2xl font-bold text-[#242321]">
          {isActivated ? '您的电影通行证已生效' : '输入兑换码解锁完整测评'}
        </h2>
        <p className="font-serif text-xs sm:text-sm text-[#242321]/75 mt-1 leading-relaxed">
          购买一次，永久无限次测评使用。支持多设备切换，无需注册账号。
        </p>

        {/* Current Activation Status Card */}
        {isActivated && currentCode ? (
          <div className="mt-5 p-4 bg-white/80 border border-[#702D32]/30 rounded-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono text-[#702D32] font-semibold">
                CURRENT CODE
              </span>
              <span className="flex items-center gap-1 text-xs text-emerald-800 font-medium">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                永久有效
              </span>
            </div>
            <div className="text-xl font-mono font-bold tracking-wider text-[#242321]">
              {currentCode}
            </div>
            <p className="text-xs text-[#9B8575] font-serif mt-2">
              您已解锁完整的15题动态分支与个性化推荐报告，可随时无限次重新测评。
            </p>
          </div>
        ) : null}

        {/* Activation Form */}
        <form onSubmit={handleActivate} className="mt-6 space-y-4">
          <div>
            <label className="block text-xs font-serif font-medium text-[#242321] mb-1.5">
              {isActivated ? '更换其他兑换码（可选）：' : '兑换码 / ACTIVATION CODE：'}
            </label>
            <input
              type="text"
              value={inputCode}
              onChange={(e) => setInputCode(e.target.value)}
              placeholder="例如：CINEMA2026 或 VIP888"
              className="w-full px-4 py-3 bg-white border border-[#9B8575]/40 rounded-sm font-mono text-base uppercase tracking-wider text-[#242321] placeholder:text-[#9B8575]/60 focus:outline-none focus:border-[#702D32] focus:ring-1 focus:ring-[#702D32]"
              disabled={loading}
              autoFocus={!isActivated}
            />
          </div>

          {/* Quick Demo Test Codes */}
          <div className="pt-1">
            <span className="text-[11px] font-serif text-[#9B8575] block mb-1.5">
              测试与体验快捷填入：
            </span>
            <div className="flex flex-wrap gap-2">
              {['CINEMA2026', 'VIP888', 'REDVELVET'].map((code) => (
                <button
                  key={code}
                  type="button"
                  onClick={() => fillDemoCode(code)}
                  className="px-2.5 py-1 text-xs font-mono bg-white/70 hover:bg-white text-[#702D32] border border-[#702D32]/30 rounded-sm transition-colors cursor-pointer"
                >
                  {code}
                </button>
              ))}
            </div>
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 text-red-900 text-xs rounded-sm">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Success Message */}
          {successMessage && (
            <div className="flex items-center gap-2 p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs rounded-sm">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 bg-[#702D32] hover:bg-[#582327] disabled:opacity-50 text-[#F3EFE6] font-serif font-semibold text-sm tracking-wider rounded-sm shadow-md transition-all cursor-pointer"
          >
            {loading ? '正在安全核验中...' : isActivated ? '切换并重新验证' : '立即验证激活'}
          </button>
        </form>

        {/* Footer Guidance */}
        <div className="mt-6 pt-4 border-t border-[#9B8575]/25 text-xs text-[#9B8575] font-serif leading-relaxed">
          <div className="flex items-center gap-1.5 text-[#242321] font-medium mb-1">
            <HelpCircle className="w-3.5 h-3.5 text-[#702D32]" />
            <span>购买与售后说明</span>
          </div>
          <p>
            1. 在小红书官方渠道购买后，客服将通过私信发送唯一激活码；
            <br />
            2. 每个激活码默认支持2–5台设备同时使用，更换新手机或电脑时直接输入即可；
            <br />
            3. 若遇到“达到设备上限”或“激活码失效”，请在小红书咨询客服重置设备记录。
          </p>
        </div>
      </div>
    </div>
  );
};
