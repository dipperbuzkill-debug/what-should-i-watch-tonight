/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Sparkles, Clock, Globe, Film, User, AlertTriangle, Compass } from 'lucide-react';
import { Movie, RecommendationResult } from '../types';
import { MoviePoster } from './MoviePoster';

interface MovieDetailModalProps {
  movie: Movie | null;
  recommendation?: RecommendationResult | null;
  onClose: () => void;
}

export const MovieDetailModal: React.FC<MovieDetailModalProps> = ({
  movie,
  recommendation,
  onClose
}) => {
  if (!movie) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-[#F3EFE6] text-[#242321] rounded-sm border border-[#9B8575]/40 shadow-2xl p-6 sm:p-8 text-left">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 text-[#9B8575] hover:text-[#242321] transition-colors rounded-sm cursor-pointer z-10"
          aria-label="关闭详情"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Modal Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 sm:gap-8 items-start">
          {/* Left Column: Big Movie Poster */}
          <div className="md:col-span-5">
            <MoviePoster movie={movie} className="w-full shadow-lg" />
            <div className="mt-3 text-[10px] font-mono text-[#9B8575] flex flex-col gap-1 border-t border-[#9B8575]/20 pt-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-[#702D32]">
                  {movie.hasOfficialPoster ? '● 官方原版院线公映海报' : '○ 原版院线海报收录中'}
                </span>
                <span>2:3 胶片标准画幅</span>
              </div>
              <span className="text-[9px] text-[#9B8575] truncate">
                来源归档：{movie.posterSource || (movie.hasOfficialPoster ? '公映发行方正版物料' : '官方资料库核验中')}
              </span>
            </div>
          </div>

          {/* Right Column: Comprehensive Film Metadata & Curatorial Notes */}
          <div className="md:col-span-7 flex flex-col justify-between">
            <div>
              {/* Category label if recommendation is present */}
              {recommendation && (
                <div className="inline-block text-[11px] font-mono font-bold tracking-widest text-[#702D32] uppercase mb-1.5 border-b border-[#702D32]/40 pb-0.5">
                  ● {recommendation.categoryLabel} · 匹配度 {recommendation.score}%
                </div>
              )}

              <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#242321] leading-tight">
                {movie.chineseTitle}
              </h2>
              <p className="font-serif italic text-sm sm:text-base text-[#9B8575] mt-1">
                {movie.originalTitle} ({movie.releaseYear})
              </p>

              {/* Quick Specs Definition List */}
              <div className="grid grid-cols-2 gap-y-2 gap-x-4 py-4 my-4 border-y border-[#9B8575]/25 text-xs text-[#242321]/80 font-serif">
                <div className="flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-[#702D32] shrink-0" />
                  <span>导演：{movie.director}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-[#702D32] shrink-0" />
                  <span>地区：{movie.country}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-[#702D32] shrink-0" />
                  <span>时长：{movie.runtime} 分钟</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Film className="w-3.5 h-3.5 text-[#702D32] shrink-0" />
                  <span>类型：{movie.genre.join(' / ')}</span>
                </div>
              </div>

              {/* Synopsis */}
              <div className="mb-5">
                <span className="block text-xs font-mono tracking-widest text-[#9B8575] uppercase mb-1.5">
                  SYNOPSIS · 剧情梗概
                </span>
                <p className="font-serif text-sm text-[#242321] leading-relaxed">
                  {movie.synopsis}
                </p>
              </div>

              {/* Tags Section */}
              <div className="mb-5 space-y-2">
                <div className="text-xs text-[#9B8575] flex items-center gap-2">
                  <span className="font-mono uppercase tracking-wider shrink-0 text-[#242321] font-semibold">
                    情绪氛围：
                  </span>
                  <span>{movie.moodTags.join(' · ')}</span>
                </div>
                <div className="text-xs text-[#9B8575] flex items-center gap-2">
                  <span className="font-mono uppercase tracking-wider shrink-0 text-[#242321] font-semibold">
                    视听风格：
                  </span>
                  <span>{movie.visualTags.join(' · ')}</span>
                </div>
              </div>

              {/* Why This Movie Matches */}
              <div className="p-4 bg-white/80 border border-[#702D32]/25 rounded-sm mb-4">
                <span className="flex items-center gap-1.5 text-xs font-mono font-bold tracking-wider text-[#702D32] uppercase mb-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>为何精准匹配你今晚的答案</span>
                </span>
                <p className="font-serif text-xs sm:text-sm text-[#242321] leading-relaxed">
                  {recommendation?.categoryReason || movie.whyRecommendedDefault}
                </p>
              </div>

              {/* Best Viewing Atmosphere */}
              <div className="p-3 bg-[#DED5C8]/40 border border-[#9B8575]/25 rounded-sm text-xs font-serif text-[#242321]">
                <span className="font-semibold text-[#702D32] block mb-0.5">
                  观影氛围建议：
                </span>
                <span>{movie.bestViewingAtmosphere}</span>
              </div>

              {/* Content Warnings */}
              {movie.contentWarnings.length > 0 && (
                <div className="mt-3 flex items-center gap-1.5 text-xs text-amber-800">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                  <span>内容提示：{movie.contentWarnings.join(' · ')}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
