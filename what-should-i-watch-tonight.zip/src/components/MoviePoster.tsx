/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Film, Clapperboard, ExternalLink, ShieldCheck, Clock } from 'lucide-react';
import { Movie } from '../types';
import { getOfficialPoster } from '../data/posterCatalog';

interface MoviePosterProps {
  movie: Movie;
  className?: string;
  onClick?: () => void;
  showTitles?: boolean;
  aspectRatioClass?: string;
}

export const MoviePoster: React.FC<MoviePosterProps> = ({
  movie,
  className = '',
  onClick,
  showTitles = false,
  aspectRatioClass = 'aspect-[2/3]'
}) => {
  const [imgFailed, setImgFailed] = useState(false);

  // Retrieve verified official theatrical poster record
  const officialRecord = getOfficialPoster(movie.id);
  const posterUrl = officialRecord?.officialPosterUrl || movie.officialPosterUrl;
  const hasValidOfficialPoster = Boolean(posterUrl && !imgFailed);

  return (
    <div className={`group flex flex-col ${className}`}>
      <div
        onClick={onClick}
        className={`relative w-full ${aspectRatioClass} overflow-hidden rounded-sm bg-[#181716] border border-[#9B8575]/35 shadow-md cursor-pointer transition-all duration-300 group-hover:shadow-2xl group-hover:border-[#702D32] group-hover:-translate-y-1 select-none flex flex-col`}
      >
        {/* CASE 1: Authentic Verified Official Theatrical Movie Poster */}
        {hasValidOfficialPoster ? (
          <>
            <img
              src={posterUrl}
              alt={`${movie.chineseTitle} 官方原版院线海报`}
              loading="lazy"
              onError={() => setImgFailed(true)}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />

            {/* Official Theatrical Quality Badge (Top-Right) */}
            <div className="absolute top-2 right-2 z-20 pointer-events-none">
              <span className="bg-[#242321]/90 backdrop-blur-md text-[#F3EFE6] text-[8.5px] px-2 py-0.5 tracking-wider font-mono border border-white/20 uppercase shadow flex items-center gap-1">
                <ShieldCheck className="w-2.5 h-2.5 text-[#E5A93C]" />
                <span>官方原版院线海报</span>
              </span>
            </div>

            {/* Hover Scrim: Reveals Theatrical Provenance & Title */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/92 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4 text-[#F3EFE6] text-left z-20">
              <span className="text-[9px] font-mono tracking-widest text-[#E5A93C] uppercase">
                THEATRICAL ARCHIVE · {movie.releaseYear}
              </span>
              <h4 className="font-serif text-lg font-bold line-clamp-1 leading-snug">
                {movie.chineseTitle}
              </h4>
              <p className="text-xs font-serif italic text-[#DED5C8] opacity-90 line-clamp-1">
                {movie.originalTitle}
              </p>
              <div className="mt-2 text-[10px] text-[#DED5C8]/80 font-mono line-clamp-1">
                来源：{officialRecord?.posterSource || movie.posterSource || '官方院线公映物料'}
              </div>
              <div className="mt-2 pt-2 border-t border-white/20 flex items-center justify-between text-[11px] font-medium text-[#F3EFE6]">
                <span className="underline underline-offset-4 decoration-[#702D32]">查看完整影评</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Film Grain Texture */}
            <div className="absolute inset-0 opacity-10 pointer-events-none film-grain" />
          </>
        ) : (
          /* CASE 2: Minimalist Film Clapperboard Pending Placeholder Card */
          <div className="relative w-full h-full flex flex-col justify-between p-3.5 sm:p-4 text-left bg-[#1C1B1A] text-[#F3EFE6] border border-[#9B8575]/25">
            {/* Clapperboard Top Slates with 45-degree diagonal stripes */}
            <div className="relative w-full h-7 sm:h-8 rounded-xs overflow-hidden border border-white/20 shadow-inner flex shrink-0">
              <div
                className="w-full h-full"
                style={{
                  background: 'repeating-linear-gradient(45deg, #181716, #181716 12px, #EFECE6 12px, #EFECE6 24px)'
                }}
              />
              <div className="absolute inset-0 flex items-center justify-between px-2 text-[8px] font-mono font-bold tracking-widest text-black bg-white/70 backdrop-blur-[1px]">
                <span>SCENE 01</span>
                <span>TAKE 2:3</span>
                <span>ROLL 35MM</span>
              </div>
            </div>

            {/* Clapperboard Production Metadata Body */}
            <div className="my-auto py-2 flex flex-col justify-center text-left space-y-2">
              <div>
                <span className="block text-[7.5px] font-mono tracking-widest uppercase text-[#9B8575]">
                  PROD. / 电影片名
                </span>
                <h3 className="font-serif text-lg sm:text-xl font-bold text-[#F3EFE6] leading-snug line-clamp-2">
                  {movie.chineseTitle}
                </h3>
                <p className="font-serif italic text-xs text-[#9B8575] line-clamp-1 mt-0.5">
                  {movie.originalTitle}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-1.5 pt-1.5 border-t border-white/10 text-[9px] font-mono text-[#DED5C8]">
                <div>
                  <span className="text-[#9B8575] block text-[7px] uppercase">DIRECTOR</span>
                  <span className="truncate block font-serif">{movie.director}</span>
                </div>
                <div>
                  <span className="text-[#9B8575] block text-[7px] uppercase">YEAR / NATION</span>
                  <span className="truncate block">{movie.releaseYear} · {movie.country.split(' / ')[0]}</span>
                </div>
              </div>

              {/* Explicit Honest Status Box */}
              <div className="pt-2">
                <div className="p-2 rounded-xs bg-[#242321] border border-[#9B8575]/30 flex flex-col items-center text-center">
                  <div className="flex items-center gap-1.5 text-[10px] font-mono text-[#E5A93C] font-semibold">
                    <Clock className="w-3 h-3 animate-pulse" />
                    <span>原版院线海报收录中</span>
                  </div>
                  <span className="text-[7.5px] font-mono text-[#9B8575] mt-0.5">
                    PENDING OFFICIAL POSTER ARCHIVE
                  </span>
                  <span className="text-[7px] font-serif text-[#DED5C8]/70 mt-1">
                    严格审核公映发行出处 · 杜绝AI冒充
                  </span>
                </div>
              </div>
            </div>

            {/* Footer Specifications */}
            <div className="pt-1.5 border-t border-white/10 flex items-center justify-between text-[8px] font-mono text-[#9B8575]">
              <span>{movie.genre[0]} · {movie.runtime} MIN</span>
              <span>2:3 ARCHIVE RATIO</span>
            </div>

            {/* Subtle Film Grain */}
            <div className="absolute inset-0 opacity-15 pointer-events-none film-grain" />
          </div>
        )}
      </div>

      {showTitles && (
        <div className="mt-2 text-left">
          <div className="flex items-center justify-between">
            <h4 className="font-serif text-sm sm:text-base font-bold text-[#242321] group-hover:text-[#702D32] transition-colors leading-tight line-clamp-1">
              {movie.chineseTitle}
            </h4>
            {hasValidOfficialPoster ? (
              <span className="text-[8px] font-mono text-[#702D32] bg-[#702D32]/10 px-1 rounded-xs shrink-0 ml-1">
                官方原版
              </span>
            ) : (
              <span className="text-[8px] font-mono text-[#9B8575] bg-black/5 px-1 rounded-xs shrink-0 ml-1">
                待补充
              </span>
            )}
          </div>
          <p className="text-xs font-serif text-[#9B8575] italic line-clamp-1 mt-0.5">
            {movie.originalTitle} · {movie.director} ({movie.releaseYear})
          </p>
        </div>
      )}
    </div>
  );
};
