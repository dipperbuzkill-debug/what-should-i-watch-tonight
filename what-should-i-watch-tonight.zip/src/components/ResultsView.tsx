/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Sparkles,
  RotateCcw,
  Share2,
  Copy,
  Check,
  ExternalLink,
  ChevronRight,
  Info,
  Clock,
  Globe,
  User,
  HeartHandshake
} from 'lucide-react';
import { UserProfile, Movie, RecommendationResult } from '../types';
import { MoviePoster } from './MoviePoster';
import { MovieDetailModal } from './MovieDetailModal';
import { ShareCardModal } from './ShareCardModal';

interface ResultsViewProps {
  profile: UserProfile;
  onRetake: () => void;
  onGoHome: () => void;
}

export const ResultsView: React.FC<ResultsViewProps> = ({
  profile,
  onRetake,
  onGoHome
}) => {
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [selectedRec, setSelectedRec] = useState<RecommendationResult | null>(null);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [copiedList, setCopiedList] = useState(false);

  const topRecommendation = profile.recommendedTonight[0];
  const otherRecommendations = profile.recommendedTonight.slice(1, 5);

  const openDetail = (rec: RecommendationResult) => {
    setSelectedMovie(rec.movie);
    setSelectedRec(rec);
  };

  const handleCopyList = () => {
    const lines = [
      `🎬 今晚看什么？ · 我的专属电影画像与五部片单`,
      `【电影品味人设】：${profile.profileTitle}`,
      `“${profile.cinemaPhilosophy}”`,
      ``,
      ...profile.recommendedTonight.map(
        (r, idx) =>
          `${idx + 1}. [${r.categoryLabel} · 匹配度${r.score}%] 《${r.movie.chineseTitle}》 (${r.movie.releaseYear}) 导演：${r.movie.director}\n   理由：${r.categoryReason}`
      )
    ];

    navigator.clipboard.writeText(lines.join('\n'));
    setCopiedList(true);
    setTimeout(() => setCopiedList(false), 2000);
  };

  return (
    <div className="py-8 lg:py-12 max-w-7xl mx-auto px-6 text-left animate-fade-in">
      {/* Top Breadcrumb & Actions Bar */}
      <div className="flex flex-wrap items-center justify-between border-b border-[#9B8575]/25 pb-4 mb-10 gap-4">
        <div className="flex items-center gap-2 text-xs font-mono tracking-widest text-[#9B8575] uppercase">
          <span>CURATED RESULTS REPORT</span>
          <span aria-hidden="true">·</span>
          <span>专属电影报告</span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsShareModalOpen(true)}
            className="px-4 py-2 bg-white hover:bg-[#F3EFE6] border border-[#9B8575]/40 text-[#702D32] text-xs font-serif font-semibold rounded-sm transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>生成小红书分享卡</span>
          </button>

          <button
            onClick={handleCopyList}
            className="px-4 py-2 bg-white hover:bg-[#F3EFE6] border border-[#9B8575]/40 text-[#242321] text-xs font-serif font-medium rounded-sm transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            {copiedList ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-700" />
                <span className="text-emerald-800">已复制整份片单</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-[#9B8575]" />
                <span>复制片单文本</span>
              </>
            )}
          </button>

          <button
            onClick={onRetake}
            className="px-4 py-2 bg-[#702D32] hover:bg-[#582327] text-[#F3EFE6] text-xs font-serif font-semibold rounded-sm transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>重新测评</span>
          </button>
        </div>
      </div>

      {/* SECTION A: PERSONAL MOVIE PROFILE (EDITORIAL MAGAZINE STYLE) */}
      <section className="mb-16 bg-white/80 border border-[#9B8575]/30 rounded-sm p-6 sm:p-10 relative shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-8">
          {/* Persona Header */}
          <div className="lg:max-w-2xl">
            <div className="inline-block bg-[#702D32] text-[#F3EFE6] text-[10px] font-mono px-2.5 py-0.5 uppercase tracking-widest mb-3">
              PERSONAL CINEMA TASTE IDENTITY
            </div>
            <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#242321] tracking-tight leading-tight">
              {profile.profileTitle}
            </h1>
            <p className="font-mono text-xs text-[#702D32] font-semibold tracking-widest uppercase mt-1">
              {profile.profileSubtitle}
            </p>
            <p className="font-serif text-base text-[#242321]/80 mt-4 leading-relaxed">
              {profile.profileDescription}
            </p>
            <blockquote className="mt-5 pl-4 border-l-2 border-[#702D32] font-serif italic text-sm text-[#702D32]/90">
              “{profile.cinemaPhilosophy}”
            </blockquote>
          </div>

          {/* Persona Dimensional Breakdown Grid */}
          <div className="lg:w-80 bg-[#F3EFE6]/70 border border-[#9B8575]/25 p-5 rounded-sm shrink-0">
            <span className="text-[10px] font-mono uppercase tracking-widest text-[#9B8575] block mb-3 border-b border-[#9B8575]/20 pb-1">
              DIMENSIONAL PROFILE · 维度切片
            </span>
            <div className="space-y-3 text-xs font-serif">
              <div>
                <span className="text-[#9B8575] block text-[11px]">首要情绪体验：</span>
                <span className="font-semibold text-[#242321]">{profile.topEmotions.join(' · ')}</span>
              </div>
              <div>
                <span className="text-[#9B8575] block text-[11px]">视听美学偏好：</span>
                <span className="text-[#242321]">{profile.preferredVisualAtmosphere}</span>
              </div>
              <div>
                <span className="text-[#9B8575] block text-[11px]">叙事节奏呼吸：</span>
                <span className="text-[#242321]">{profile.storytellingPreference}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION B: #1 MATCH (今晚最适合你 - HERO SPOTLIGHT) */}
      {topRecommendation && (
        <section className="mb-16">
          <div className="flex items-center justify-between mb-6">
            <div>
              <span className="text-xs font-mono font-bold tracking-widest text-[#702D32] uppercase">
                CATEGORY 01 · NO.1 MATCH
              </span>
              <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#242321] mt-0.5">
                今晚最适合你
              </h2>
            </div>
            <span className="font-mono text-sm text-[#702D32] font-bold border border-[#702D32]/30 px-3 py-1 rounded-sm bg-white">
              匹配度 {topRecommendation.score}%
            </span>
          </div>

          <div className="bg-white border border-[#9B8575]/35 rounded-sm shadow-md overflow-hidden grid grid-cols-1 md:grid-cols-12 gap-8 p-6 sm:p-8 items-center">
            {/* Big Movie Cover */}
            <div className="md:col-span-5 lg:col-span-4">
              <MoviePoster
                movie={topRecommendation.movie}
                onClick={() => openDetail(topRecommendation)}
                className="w-full max-w-sm mx-auto shadow-xl"
              />
            </div>

            {/* Movie Information & Match Reasoning */}
            <div className="md:col-span-7 lg:col-span-8 flex flex-col justify-between h-full">
              <div>
                <div className="text-xs text-[#9B8575] font-serif mb-1 flex items-center gap-2">
                  <span>{topRecommendation.movie.country}</span>
                  <span aria-hidden="true">·</span>
                  <span>{topRecommendation.movie.releaseYear}</span>
                  <span aria-hidden="true">·</span>
                  <span>{topRecommendation.movie.genre.join(' / ')}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono">{topRecommendation.movie.runtime} 分钟</span>
                </div>

                <h3
                  onClick={() => openDetail(topRecommendation)}
                  className="font-serif text-3xl sm:text-4xl font-bold text-[#242321] hover:text-[#702D32] transition-colors cursor-pointer leading-tight"
                >
                  {topRecommendation.movie.chineseTitle}
                </h3>
                <p className="font-serif italic text-base text-[#9B8575] mt-1">
                  {topRecommendation.movie.originalTitle} · 导演：{topRecommendation.movie.director}
                </p>

                {/* Synopsis */}
                <p className="font-serif text-sm text-[#242321]/80 mt-4 leading-relaxed line-clamp-3 sm:line-clamp-4">
                  {topRecommendation.movie.synopsis}
                </p>

                {/* Why This Matches Your Answers */}
                <div className="mt-5 p-4 bg-[#F3EFE6] border border-[#9B8575]/25 rounded-sm">
                  <span className="flex items-center gap-1.5 text-xs font-mono font-bold tracking-wider text-[#702D32] uppercase mb-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>为何是今晚的最优解</span>
                  </span>
                  <p className="font-serif text-xs sm:text-sm text-[#242321] leading-relaxed">
                    {topRecommendation.categoryReason}
                  </p>
                </div>

                {/* Atmosphere Guidance */}
                <div className="mt-3 text-xs font-serif text-[#9B8575]">
                  <span className="text-[#242321] font-semibold">推荐观影心境：</span>
                  <span>{topRecommendation.movie.bestViewingAtmosphere}</span>
                </div>
              </div>

              {/* View Detail Action */}
              <div className="mt-6 pt-4 border-t border-[#9B8575]/20 flex items-center justify-between">
                <div className="text-xs font-serif text-[#9B8575]">
                  情绪标签：{topRecommendation.movie.moodTags.join(' · ')}
                </div>
                <button
                  onClick={() => openDetail(topRecommendation)}
                  className="text-xs font-serif font-bold text-[#702D32] hover:text-[#582327] transition-colors flex items-center gap-1 underline underline-offset-4 cursor-pointer"
                >
                  <span>查看完整影评档案</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* SECTION C: 4 OTHER CURATED RECOMMENDATIONS WITH COVERS */}
      <section className="mb-16">
        <div className="mb-8 border-b border-[#9B8575]/25 pb-3">
          <span className="text-xs font-mono font-bold tracking-widest text-[#702D32] uppercase">
            CATEGORIES 02–05 · FOUR DISTINCTIVE PERSPECTIVES
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#242321] mt-0.5">
            四种不同维度的定制佳作
          </h2>
          <p className="font-serif text-xs sm:text-sm text-[#9B8575] mt-1">
            涵盖冷门宝藏、跳出舒适圈的新鲜体验、以及疲惫时轻松疗愈的备选
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {otherRecommendations.map((rec, idx) => (
            <div
              key={rec.movie.id}
              className="bg-white border border-[#9B8575]/25 rounded-sm p-6 flex flex-col justify-between hover:shadow-md transition-all group"
            >
              <div>
                {/* Header Category Tag & Compatibility Score */}
                <div className="flex items-center justify-between border-b border-[#9B8575]/20 pb-2.5 mb-4">
                  <span className="text-xs font-mono font-bold tracking-wider text-[#702D32] uppercase">
                    ● {rec.categoryLabel}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#242321]">
                    匹配度 {rec.score}%
                  </span>
                </div>

                {/* 2-Column Poster & Deck Layout */}
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-5 items-start">
                  <div className="sm:col-span-5">
                    <MoviePoster
                      movie={rec.movie}
                      onClick={() => openDetail(rec)}
                      className="w-full shadow"
                    />
                  </div>

                  <div className="sm:col-span-7 flex flex-col">
                    <h3
                      onClick={() => openDetail(rec)}
                      className="font-serif text-xl font-bold text-[#242321] group-hover:text-[#702D32] transition-colors cursor-pointer leading-tight"
                    >
                      {rec.movie.chineseTitle}
                    </h3>
                    <p className="font-serif italic text-xs text-[#9B8575] mt-0.5">
                      {rec.movie.originalTitle} ({rec.movie.releaseYear})
                    </p>
                    <div className="text-[11px] font-serif text-[#9B8575] mt-1">
                      {rec.movie.country} · {rec.movie.director}
                    </div>

                    <p className="font-serif text-xs text-[#242321]/80 mt-2.5 leading-relaxed line-clamp-3">
                      {rec.movie.synopsis}
                    </p>

                    <div className="mt-3 p-2.5 bg-[#F3EFE6] border border-[#9B8575]/20 rounded-sm">
                      <span className="text-[10px] font-mono text-[#702D32] font-semibold block uppercase">
                        为什么推荐：
                      </span>
                      <p className="font-serif text-xs text-[#242321] mt-0.5 leading-snug">
                        {rec.categoryReason}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Footer */}
              <div className="mt-5 pt-3 border-t border-[#9B8575]/15 flex items-center justify-between text-xs font-serif">
                <span className="text-[#9B8575]">
                  {rec.movie.genre.slice(0, 2).join(' · ')}
                </span>
                <button
                  onClick={() => openDetail(rec)}
                  className="font-medium text-[#702D32] hover:text-[#582327] underline underline-offset-4 cursor-pointer"
                >
                  查看详情
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SECTION D: RETEST & EXPLORE AGAIN */}
      <section className="bg-white/70 border border-[#9B8575]/30 rounded-sm p-8 text-center max-w-2xl mx-auto my-12">
        <h3 className="font-serif text-2xl font-bold text-[#242321]">
          想要重新做一次决定？
        </h3>
        <p className="font-serif text-sm text-[#9B8575] mt-2">
          您的激活码享受永久有效权益。不同日子的心境截然不同，您可以随时开启新的问答分支。
        </p>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-4">
          <button
            onClick={onRetake}
            className="px-6 py-2.5 bg-[#702D32] hover:bg-[#582327] text-[#F3EFE6] font-serif text-sm font-semibold rounded-sm transition-all shadow-sm cursor-pointer"
          >
            开启全新测试
          </button>
          <button
            onClick={onGoHome}
            className="px-6 py-2.5 bg-white hover:bg-[#F3EFE6] border border-[#9B8575]/40 text-[#242321] font-serif text-sm font-medium rounded-sm transition-all cursor-pointer"
          >
            返回杂志首页
          </button>
        </div>
      </section>

      {/* Modals */}
      <MovieDetailModal
        movie={selectedMovie}
        recommendation={selectedRec}
        onClose={() => {
          setSelectedMovie(null);
          setSelectedRec(null);
        }}
      />

      <ShareCardModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        profile={profile}
      />
    </div>
  );
};
