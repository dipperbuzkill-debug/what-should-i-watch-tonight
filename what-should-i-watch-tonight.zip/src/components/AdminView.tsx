/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Lock,
  Plus,
  Search,
  Download,
  Power,
  RotateCw,
  X,
  Shield,
  Laptop,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

interface CodeItem {
  code: string;
  createdAt: string;
  activatedAt?: string;
  devicesUsed: string[];
  maxDevices: number;
  isActive: boolean;
  notes?: string;
}

interface AdminViewProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminView: React.FC<AdminViewProps> = ({ isOpen, onClose }) => {
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  const [codes, setCodes] = useState<CodeItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);

  // Generation Modal States
  const [generateCount, setGenerateCount] = useState(1);
  const [generateMaxDevices, setGenerateMaxDevices] = useState(3);
  const [generatePrefix, setGeneratePrefix] = useState('XHS');
  const [generateNotes, setGenerateNotes] = useState('小红书批次');
  const [isGenerating, setIsGenerating] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    const savedToken = localStorage.getItem('__tonight_admin_token');
    if (savedToken) {
      setAuthToken(savedToken);
      fetchCodes(savedToken);
    }
  }, []);

  if (!isOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoading(true);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: passwordInput.trim() })
      });
      const data = await res.json();

      if (res.ok && data.success) {
        setAuthToken(data.token);
        localStorage.setItem('__tonight_admin_token', data.token);
        fetchCodes(data.token);
      } else {
        setLoginError(data.message || '密码错误，请重试');
      }
    } catch (err) {
      setLoginError('网络请求失败');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    setAuthToken(null);
    localStorage.removeItem('__tonight_admin_token');
  };

  const fetchCodes = async (token: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/codes', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setCodes(data.codes || []);
      } else if (res.status === 401) {
        handleLogout();
      }
    } catch (err) {
      console.error('Fetch codes failed', err);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authToken) return;
    setIsGenerating(true);
    setFeedbackMsg(null);

    try {
      const res = await fetch('/api/admin/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`
        },
        body: JSON.stringify({
          count: generateCount,
          maxDevices: generateMaxDevices,
          prefix: generatePrefix,
          notes: generateNotes
        })
      });
      const data = await res.json();

      if (res.ok && data.success) {
        setFeedbackMsg({ type: 'success', text: `成功生成 ${data.createdCount} 个新兑换码！` });
        fetchCodes(authToken);
      } else {
        setFeedbackMsg({ type: 'error', text: data.message || '生成失败' });
      }
    } catch (err) {
      setFeedbackMsg({ type: 'error', text: '请求异常' });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleToggleCode = async (code: string, currentActive: boolean) => {
    if (!authToken) return;
    try {
      const res = await fetch('/api/admin/toggle', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`
        },
        body: JSON.stringify({ code, isActive: !currentActive })
      });
      if (res.ok) {
        fetchCodes(authToken);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleResetDevices = async (code: string) => {
    if (!authToken) return;
    if (!window.confirm(`确定要重置兑换码 ${code} 的所有已绑定设备吗？重置后用户可在新设备重新激活。`)) {
      return;
    }

    try {
      const res = await fetch('/api/admin/update-limit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`
        },
        body: JSON.stringify({ code, resetDevices: true })
      });
      if (res.ok) {
        fetchCodes(authToken);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleExportCSV = () => {
    const headers = ['兑换码', '状态', '已用设备数', '最大设备数', '创建时间', '首次激活时间', '备注'];
    const rows = filteredCodes.map((c) => [
      c.code,
      c.isActive ? '正常启用' : '已停用',
      c.devicesUsed.length,
      c.maxDevices,
      c.createdAt ? new Date(c.createdAt).toLocaleDateString() : '',
      c.activatedAt ? new Date(c.activatedAt).toLocaleString() : '未激活',
      `"${c.notes || ''}"`
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `今晚看什么_兑换码清单_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredCodes = codes.filter(
    (c) =>
      c.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.notes && c.notes.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in text-left">
      <div className="relative w-full max-w-5xl max-h-[92vh] overflow-y-auto bg-[#F3EFE6] text-[#242321] rounded-sm border border-[#9B8575]/40 shadow-2xl p-6 sm:p-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 text-[#9B8575] hover:text-[#242321] transition-colors rounded-sm cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-2 text-xs font-mono tracking-widest text-[#702D32] uppercase mb-1">
          <Shield className="w-4 h-4" />
          <span>ADMINISTRATION CONSOLE · 兑换码管理中心</span>
        </div>
        <h2 className="font-serif text-2xl font-bold text-[#242321]">
          激活码分发与设备限制管理
        </h2>

        {/* Not Logged In View */}
        {!authToken ? (
          <div className="my-8 max-w-sm mx-auto p-6 bg-white border border-[#9B8575]/30 rounded-sm shadow-sm text-center">
            <Lock className="w-8 h-8 text-[#702D32] mx-auto mb-3" />
            <h3 className="font-serif text-lg font-bold text-[#242321] mb-1">
              需要管理员访问凭证
            </h3>
            <p className="text-xs text-[#9B8575] font-serif mb-4">
              请输入后台管理密码以生成或注销激活码（初始默认密码：<code className="text-[#702D32]">cinema2026admin</code>）
            </p>

            <form onSubmit={handleLogin} className="space-y-3">
              <input
                type="password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="管理员密码"
                className="w-full px-3 py-2 bg-[#F3EFE6] border border-[#9B8575]/40 rounded-sm text-sm focus:outline-none focus:border-[#702D32]"
              />

              {loginError && (
                <div className="text-xs text-red-600 font-serif">{loginError}</div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-[#702D32] hover:bg-[#582327] disabled:opacity-50 text-[#F3EFE6] font-serif text-xs font-semibold rounded-sm transition-all cursor-pointer"
              >
                {loading ? '核验中...' : '登录管理后台'}
              </button>
            </form>
          </div>
        ) : (
          /* Logged In Admin Dashboard */
          <div className="mt-6 space-y-6">
            {/* Top Stats Ribbon & Actions */}
            <div className="flex flex-wrap items-center justify-between border-b border-[#9B8575]/25 pb-4 gap-4">
              <div className="flex items-center gap-4 text-xs font-serif text-[#242321]">
                <span>
                  共计 <strong>{codes.length}</strong> 个激活码
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  已激活：<strong>{codes.filter((c) => c.activatedAt).length}</strong>
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  已启用：<strong>{codes.filter((c) => c.isActive).length}</strong>
                </span>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={handleExportCSV}
                  className="px-3 py-1.5 bg-white hover:bg-[#F3EFE6] border border-[#9B8575]/35 text-[#242321] text-xs font-serif rounded-sm flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-[#9B8575]" />
                  <span>导出 CSV</span>
                </button>

                <button
                  onClick={() => fetchCodes(authToken)}
                  className="p-1.5 bg-white hover:bg-[#F3EFE6] border border-[#9B8575]/35 text-[#9B8575] hover:text-[#242321] text-xs rounded-sm transition-colors cursor-pointer"
                  title="刷新数据"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={handleLogout}
                  className="text-xs text-[#702D32] hover:underline cursor-pointer"
                >
                  退出登录
                </button>
              </div>
            </div>

            {/* Batch Code Generation Box */}
            <div className="p-5 bg-white border border-[#9B8575]/25 rounded-sm">
              <span className="text-xs font-mono font-bold tracking-wider text-[#702D32] uppercase block mb-3">
                GENERATE NEW ACTIVATION CODES · 批量生成兑换码
              </span>

              <form onSubmit={handleGenerate} className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
                <div>
                  <label className="block text-[11px] font-serif text-[#9B8575] mb-1">
                    生成数量
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={generateCount}
                    onChange={(e) => setGenerateCount(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#F3EFE6] border border-[#9B8575]/35 rounded-sm text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-serif text-[#9B8575] mb-1">
                    允许最大设备数
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={generateMaxDevices}
                    onChange={(e) => setGenerateMaxDevices(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#F3EFE6] border border-[#9B8575]/35 rounded-sm text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-serif text-[#9B8575] mb-1">
                    编码前缀
                  </label>
                  <input
                    type="text"
                    value={generatePrefix}
                    onChange={(e) => setGeneratePrefix(e.target.value)}
                    placeholder="如 XHS / CINEMA"
                    className="w-full px-3 py-2 bg-[#F3EFE6] border border-[#9B8575]/35 rounded-sm text-xs font-mono uppercase"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isGenerating}
                  className="w-full py-2 bg-[#702D32] hover:bg-[#582327] disabled:opacity-50 text-[#F3EFE6] font-serif text-xs font-semibold rounded-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer h-[35px]"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isGenerating ? '正在生成...' : '立即生成批次'}</span>
                </button>
              </form>

              {feedbackMsg && (
                <div
                  className={`mt-3 p-2.5 text-xs rounded-sm flex items-center gap-2 ${
                    feedbackMsg.type === 'success'
                      ? 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                      : 'bg-red-50 text-red-900 border border-red-200'
                  }`}
                >
                  {feedbackMsg.type === 'success' ? (
                    <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                  )}
                  <span>{feedbackMsg.text}</span>
                </div>
              )}
            </div>

            {/* Search Box */}
            <div className="relative">
              <Search className="w-4 h-4 text-[#9B8575] absolute left-3 top-3 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="搜索兑换码或备注关键词..."
                className="w-full pl-9 pr-4 py-2 bg-white border border-[#9B8575]/35 rounded-sm text-xs font-mono text-[#242321] placeholder:text-[#9B8575]/60 focus:outline-none focus:border-[#702D32]"
              />
            </div>

            {/* Codes Data Table */}
            <div className="border border-[#9B8575]/30 rounded-sm overflow-hidden bg-white">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-serif">
                  <thead className="bg-[#F3EFE6] border-b border-[#9B8575]/25 text-[#9B8575] uppercase font-mono tracking-wider">
                    <tr>
                      <th className="py-2.5 px-4">兑换码</th>
                      <th className="py-2.5 px-3">状态</th>
                      <th className="py-2.5 px-3">设备数 / 上限</th>
                      <th className="py-2.5 px-3">首次激活</th>
                      <th className="py-2.5 px-3">备注</th>
                      <th className="py-2.5 px-4 text-right">操作</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#9B8575]/15 font-mono">
                    {filteredCodes.map((c) => (
                      <tr key={c.code} className="hover:bg-[#F3EFE6]/40 transition-colors">
                        <td className="py-2.5 px-4 font-bold text-[#242321] tracking-wider">
                          {c.code}
                        </td>
                        <td className="py-2.5 px-3">
                          {c.isActive ? (
                            <span className="text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-sm border border-emerald-200 text-[11px]">
                              正常有效
                            </span>
                          ) : (
                            <span className="text-red-800 bg-red-50 px-2 py-0.5 rounded-sm border border-red-200 text-[11px]">
                              已停用
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="tabular-nums">
                            {c.devicesUsed.length} / {c.maxDevices} 台
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-[#9B8575] text-[11px]">
                          {c.activatedAt
                            ? new Date(c.activatedAt).toLocaleDateString()
                            : '未激活'}
                        </td>
                        <td className="py-2.5 px-3 font-serif text-[#242321]/80 max-w-xs truncate">
                          {c.notes || '-'}
                        </td>
                        <td className="py-2.5 px-4 text-right space-x-2 font-serif">
                          <button
                            onClick={() => handleToggleCode(c.code, c.isActive)}
                            className={`text-xs underline cursor-pointer ${
                              c.isActive
                                ? 'text-amber-800 hover:text-amber-900'
                                : 'text-emerald-800 hover:text-emerald-900'
                            }`}
                          >
                            {c.isActive ? '停用' : '启用'}
                          </button>
                          {c.devicesUsed.length > 0 && (
                            <button
                              onClick={() => handleResetDevices(c.code)}
                              className="text-xs text-[#702D32] hover:underline cursor-pointer"
                            >
                              解绑设备
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                    {filteredCodes.length === 0 && (
                      <tr>
                        <td colSpan={6} className="py-8 text-center text-[#9B8575] font-serif">
                          没有匹配的兑换码记录
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
