/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ArrowLeft, ArrowRight, Check, Compass, Sparkles, AlertCircle } from 'lucide-react';
import { QuizQuestion, QuizOption, BranchId } from '../types';
import { STAGE_1_QUESTIONS, STAGE_3_QUESTIONS, determineDynamicBranch } from '../data/questions';

interface QuizViewProps {
  onComplete: (answers: Record<number, string | string[]>, activeQuestions: QuizQuestion[]) => void;
  onExit: () => void;
}

export const QuizView: React.FC<QuizViewProps> = ({ onComplete, onExit }) => {
  // Current question index (0 to 14 -> 1 to 15)
  const [currentIndex, setCurrentIndex] = useState(0);

  // User answers keyed by question ID (1 to 15)
  const [answers, setAnswers] = useState<Record<number, string | string[]>>({});

  // Dynamic branch state computed after Q5
  const [dynamicBranchState, setDynamicBranchState] = useState<{
    primaryBranch: BranchId;
    secondaryBranch?: BranchId;
    transitionReason: string;
    isDualBranch: boolean;
    selectedQuestions: QuizQuestion[];
  } | null>(null);

  // Show branch transition banner when arriving at Question 6
  const [showTransitionBanner, setShowTransitionBanner] = useState(false);

  // Load any existing session from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('__tonight_movie_quiz_state');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.answers) setAnswers(parsed.answers);
        if (typeof parsed.currentIndex === 'number') setCurrentIndex(parsed.currentIndex);
      }
    } catch (e) {
      console.warn('Failed reading quiz cache', e);
    }
  }, []);

  // Save session to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(
        '__tonight_movie_quiz_state',
        JSON.stringify({ answers, currentIndex })
      );
    } catch (e) {
      console.warn('Failed saving quiz cache', e);
    }
  }, [answers, currentIndex]);

  // Compute dynamic branch whenever Stage 1 answers change
  useEffect(() => {
    const q1to5Answered = [1, 2, 3, 4, 5].every((id) => answers[id]);
    if (q1to5Answered) {
      const branchResult = determineDynamicBranch(answers);
      setDynamicBranchState(branchResult);
    }
  }, [answers]);

  // Build the complete 15 questions list
  const activeQuestions: QuizQuestion[] = React.useMemo(() => {
    const stage2 = dynamicBranchState
      ? dynamicBranchState.selectedQuestions
      : // Fallback generic before Q5 answered
        STAGE_1_QUESTIONS.slice(0, 5); // temporary placeholder until unlocked

    return [...STAGE_1_QUESTIONS, ...stage2, ...STAGE_3_QUESTIONS];
  }, [dynamicBranchState]);

  const currentQuestion = activeQuestions[currentIndex];

  // Selected state for current question
  const currentAnswer = answers[currentQuestion?.id];

  const handleSelectOption = (optId: string) => {
    if (!currentQuestion) return;

    if (currentQuestion.isMultiSelect) {
      const existing = Array.isArray(currentAnswer) ? [...currentAnswer] : [];
      let updated: string[];

      // Special handling for "res_none" (no restrictions)
      if (optId === 'res_none') {
        updated = ['res_none'];
      } else {
        const filtered = existing.filter((id) => id !== 'res_none');
        if (filtered.includes(optId)) {
          updated = filtered.filter((id) => id !== optId);
        } else {
          updated = [...filtered, optId];
        }
        if (updated.length === 0) {
          updated = ['res_none'];
        }
      }

      setAnswers((prev) => ({
        ...prev,
        [currentQuestion.id]: updated
      }));
    } else {
      setAnswers((prev) => ({
        ...prev,
        [currentQuestion.id]: optId
      }));

      // For single select: advance after subtle selection delay
      setTimeout(() => {
        handleNext();
      }, 260);
    }
  };

  const handleNext = () => {
    if (!currentAnswer || (Array.isArray(currentAnswer) && currentAnswer.length === 0)) {
      return;
    }

    if (currentIndex === 4) {
      // Transitioning from Q5 to Q6 (entering dynamic branch)
      setShowTransitionBanner(true);
      setCurrentIndex(5);
    } else if (currentIndex < 14) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      // Completed all 15 questions!
      localStorage.removeItem('__tonight_movie_quiz_state');
      onComplete(answers, activeQuestions);
    }
  };

  const handleBack = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    } else {
      onExit();
    }
  };

  if (!currentQuestion) return null;

  const currentStage = currentQuestion.stage;
  const stageNames = {
    1: '阶段一 · 通用审美与情绪摸底',
    2: '阶段二 · 深度个性化动态分支',
    3: '阶段三 · 观影条件与避雷确认'
  };

  const isOptionSelected = (optId: string): boolean => {
    if (Array.isArray(currentAnswer)) {
      return currentAnswer.includes(optId);
    }
    return currentAnswer === optId;
  };

  return (
    <div className="min-h-[85vh] flex flex-col justify-between py-6 max-w-4xl mx-auto px-6 text-left">
      {/* Top Header: Progress & Stage Indicator */}
      <div>
        <div className="flex items-center justify-between border-b border-[#9B8575]/25 pb-3 mb-6">
          <div className="flex items-center gap-3">
            <button
              onClick={handleBack}
              className="p-1.5 -ml-1.5 text-[#9B8575] hover:text-[#242321] transition-colors rounded-sm cursor-pointer flex items-center gap-1 text-xs font-serif"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{currentIndex === 0 ? '返回主页' : '上一题'}</span>
            </button>
            <span className="text-[#9B8575]/50">|</span>
            <span className="text-xs font-mono tracking-wider text-[#702D32] uppercase">
              {stageNames[currentStage]}
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-[#9B8575]">
            <span className="text-[#242321] font-bold text-sm">
              {String(currentIndex + 1).padStart(2, '0')}
            </span>
            <span>/</span>
            <span>15</span>
          </div>
        </div>

        {/* Minimal Hairline Progress Bar */}
        <div className="w-full bg-[#DED5C8] h-1 mb-8 overflow-hidden rounded-full">
          <div
            className="bg-[#702D32] h-full transition-all duration-300 ease-out"
            style={{ width: `${((currentIndex + 1) / 15) * 100}%` }}
          />
        </div>

        {/* Dynamic Branch Transition Announcement (shown once at Q6) */}
        {showTransitionBanner && dynamicBranchState && (
          <div className="mb-6 p-4 bg-[#702D32]/10 border border-[#702D32]/40 rounded-sm flex items-start justify-between gap-3 animate-fade-in">
            <div className="flex items-start gap-3">
              <Compass className="w-5 h-5 text-[#702D32] shrink-0 mt-0.5" />
              <div>
                <span className="block text-xs font-mono font-bold tracking-wider text-[#702D32] uppercase">
                  BRANCH UNLOCKED · 已为你解锁专属分支
                </span>
                <p className="font-serif text-sm text-[#242321] mt-0.5">
                  {dynamicBranchState.transitionReason}
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowTransitionBanner(false)}
              className="text-xs text-[#9B8575] hover:text-[#242321] underline shrink-0 cursor-pointer"
            >
              继续答题
            </button>
          </div>
        )}

        {/* Question Headings */}
        <div className="mb-8">
          <span className="text-xs font-mono text-[#9B8575] uppercase tracking-widest block mb-1">
            QUESTION {currentIndex + 1} OF 15
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#242321] leading-snug">
            {currentQuestion.title}
          </h2>
          {currentQuestion.subtitle && (
            <p className="text-sm font-serif text-[#9B8575] mt-1.5">
              {currentQuestion.subtitle}
            </p>
          )}
        </div>

        {/* 6 Answer Options Grid */}
        <div
          className={`grid gap-3.5 ${
            currentQuestion.options.some((o) => o.imageUrl)
              ? 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3'
              : 'grid-cols-1 md:grid-cols-2'
          }`}
        >
          {currentQuestion.options.map((option, idx) => {
            const selected = isOptionSelected(option.id);
            const letter = String.fromCharCode(65 + idx);

            return (
              <div
                key={option.id}
                onClick={() => handleSelectOption(option.id)}
                className={`group relative p-4 rounded-sm border transition-all duration-200 cursor-pointer select-none flex flex-col justify-between ${
                  selected
                    ? 'bg-[#FFFFFF] border-[#702D32] shadow-md ring-1 ring-[#702D32]'
                    : 'bg-white/60 hover:bg-white border-[#9B8575]/25 hover:border-[#9B8575]/60 hover:shadow-sm'
                }`}
              >
                {/* Visual Image if present */}
                {option.imageUrl && (
                  <div className="relative w-full aspect-[16/10] overflow-hidden rounded-sm mb-3 bg-[#1E1D1B]">
                    <img
                      src={option.imageUrl}
                      alt={option.label}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors" />
                  </div>
                )}

                <div className="flex items-start gap-3">
                  {/* Option Letter Tag */}
                  <div
                    className={`w-6 h-6 rounded-full border flex items-center justify-center text-xs font-mono font-medium shrink-0 transition-colors ${
                      selected
                        ? 'bg-[#702D32] text-[#F3EFE6] border-[#702D32]'
                        : 'border-[#9B8575]/40 text-[#9B8575] group-hover:border-[#702D32]/60 group-hover:text-[#702D32]'
                    }`}
                  >
                    {currentQuestion.isMultiSelect && selected ? (
                      <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                    ) : (
                      letter
                    )}
                  </div>

                  <div className="text-left">
                    <h3
                      className={`font-serif text-sm sm:text-base font-semibold leading-snug transition-colors ${
                        selected ? 'text-[#702D32]' : 'text-[#242321]'
                      }`}
                    >
                      {option.label}
                    </h3>
                    {option.sublabel && (
                      <p className="font-serif text-xs text-[#9B8575] mt-1 leading-relaxed">
                        {option.sublabel}
                      </p>
                    )}
                  </div>
                </div>

                {/* Subtle active indicator marker */}
                {selected && (
                  <div className="absolute top-2 right-2 text-[#702D32]">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#702D32] block" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom Sticky Controls */}
      <div className="mt-10 pt-6 border-t border-[#9B8575]/25 flex items-center justify-between">
        <span className="text-xs font-serif text-[#9B8575]">
          {currentQuestion.isMultiSelect
            ? '本题支持多选，选好后请点击下一步'
            : '单选点击后自动进入下一题，亦可点击按钮'}
        </span>

        <button
          onClick={handleNext}
          disabled={!currentAnswer || (Array.isArray(currentAnswer) && currentAnswer.length === 0)}
          className="flex items-center gap-2 px-6 py-2.5 bg-[#702D32] hover:bg-[#582327] disabled:opacity-40 disabled:cursor-not-allowed text-[#F3EFE6] font-serif text-sm font-semibold rounded-sm transition-all shadow-sm cursor-pointer"
        >
          <span>{currentIndex === 14 ? '生成专属电影报告' : '下一步'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
