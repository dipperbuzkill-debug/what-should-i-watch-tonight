/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Film, ShieldCheck, KeyRound } from 'lucide-react';

interface NavbarProps {
  onStartQuiz: () => void;
  onOpenActivation: () => void;
  onOpenAdmin: () => void;
  onNavigateHome: () => void;
  isActivated: boolean;
  activeCode?: string;
  onViewDatabase: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onStartQuiz,
  onOpenActivation,
  onOpenAdmin,
  onNavigateHome,
  isActivated,
  activeCode,
  onViewDatabase,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#F3EFE6]/95 backdrop-blur-md border-b border-[#9B8575]/25">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-6 py-4">
        {/* Zone 1: Brand wordmark single text element in display serif */}
        <button
          onClick={onNavigateHome}
          className="text-left font-serif text-xl lg:text-2xl font-bold tracking-tight text-[#242321] hover:text-[#702D32] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          今晚看什么？
        </button>

        {/* Zone 2: 4 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#242321]/80">
          <button
            onClick={onNavigateHome}
            className="hover:text-[#702D32] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            杂志首页
          </button>
          <a
            href="#mechanism"
            className="hover:text-[#702D32] transition-colors whitespace-nowrap shrink-0"
          >
            探索机制
          </a>
          <button
            onClick={onViewDatabase}
            className="hover:text-[#702D32] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            典藏片库
          </button>
          <button
            onClick={onOpenActivation}
            className="hover:text-[#702D32] transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5"
          >
            {isActivated ? (
              <span className="flex items-center gap-1 text-[#702D32] font-semibold">
                <ShieldCheck className="w-4 h-4" />
                已激活通行证
              </span>
            ) : (
              <span className="flex items-center gap-1">
                <KeyRound className="w-4 h-4" />
                兑换与激活
              </span>
            )}
          </button>
          <button
            onClick={onOpenAdmin}
            className="text-xs text-[#9B8575] hover:text-[#242321] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            后台管理
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onStartQuiz}
            className="px-5 py-2.5 text-xs lg:text-sm font-serif font-semibold tracking-wider text-[#F3EFE6] bg-[#702D32] hover:bg-[#582327] rounded-sm transition-all shadow-sm hover:shadow active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer"
          >
            {isActivated ? '开始电影测评' : '输入兑换码测评'}
          </button>
        </div>
      </div>
    </header>
  );
};
