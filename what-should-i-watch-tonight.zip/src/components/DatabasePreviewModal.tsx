/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { X, Search, Film, ChevronLeft, ChevronRight, SlidersHorizontal, Globe } from 'lucide-react';
import { MOVIE_DATABASE } from '../data/movies';
import { Movie } from '../types';
import { MoviePoster } from './MoviePoster';

interface DatabasePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectMovie: (movie: Movie) => void;
}

const ITEMS_PER_PAGE = 24;

export const DatabasePreviewModal: React.FC<DatabasePreviewModalProps> = ({
  isOpen,
  onClose,
  onSelectMovie
}) => {
  const [search, setSearch] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<string>('all');
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState<number>(1);

  const genres = [
    { key: 'all', label: '全部流派' },
    { key: '爱情', label: '爱情' },
    { key: '悬疑', label: '悬疑' },
    { key: '剧情', label: '剧情' },
    { key: '科幻', label: '科幻' },
    { key: '喜剧', label: '喜剧' },
    { key: '动作', label: '动作/冒险' },
    { key: '动画', label: '动画' },
    { key: '惊悚', label: '惊悚' },
    { key: '犯罪', label: '犯罪' },
  ];

  const regions = [
    { key: 'all', label: '全部地区' },
    { key: 'china', label: '华语 (中/港/台)' },
    { key: 'japan', label: '日本' },
    { key: 'korea', label: '韩国' },
    { key: 'europe', label: '欧洲 (法/英/德/意/西等)' },
    { key: 'usa', label: '美加 / 澳' },
    { key: 'other', label: '亚非拉 / 其他' }
  ];

  const filteredMovies = useMemo(() => {
    const q = search.trim().toLowerCase();
    return MOVIE_DATABASE.filter((m) => {
      const matchSearch =
        !q ||
        m.chineseTitle.toLowerCase().includes(q) ||
        m.originalTitle.toLowerCase().includes(q) ||
        m.director.toLowerCase().includes(q) ||
        m.country.toLowerCase().includes(q);

      const matchGenre =
        selectedGenre === 'all' ||
        m.genre.some((g) => g.includes(selectedGenre) || selectedGenre.includes(g));

      let matchRegion = true;
      if (selectedRegion === 'china') {
        matchRegion = m.country.includes('中国') || m.country.includes('香港') || m.country.includes('台湾');
      } else if (selectedRegion === 'japan') {
        matchRegion = m.country.includes('日本');
      } else if (selectedRegion === 'korea') {
        matchRegion = m.country.includes('韩国');
      } else if (selectedRegion === 'europe') {
        matchRegion =
          m.country.includes('法') ||
          m.country.includes('英') ||
          m.country.includes('德') ||
          m.country.includes('意') ||
          m.country.includes('西') ||
          m.country.includes('瑞典') ||
          m.country.includes('波兰') ||
          m.country.includes('丹麦') ||
          m.country.includes('希腊') ||
          m.country.includes('爱尔兰') ||
          m.country.includes('挪威');
      } else if (selectedRegion === 'usa') {
        matchRegion = m.country.includes('美国') || m.country.includes('加拿大') || m.country.includes('澳大利亚');
      } else if (selectedRegion === 'other') {
        matchRegion =
          m.country.includes('印度') ||
          m.country.includes('泰国') ||
          m.country.includes('阿根廷') ||
          m.country.includes('巴西') ||
          m.country.includes('伊朗') ||
          m.country.includes('黎巴嫩') ||
          m.country.includes('新西兰');
      }

      return matchSearch && matchGenre && matchRegion;
    });
  }, [search, selectedGenre, selectedRegion]);

  const totalPages = Math.max(1, Math.ceil(filteredMovies.length / ITEMS_PER_PAGE));
  const currentSafePage = Math.min(currentPage, totalPages);
  const pagedMovies = filteredMovies.slice((currentSafePage - 1) * ITEMS_PER_PAGE, currentSafePage * ITEMS_PER_PAGE);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75 backdrop-blur-sm animate-fade-in text-left">
      <div className="relative w-full max-w-6xl max-h-[94vh] flex flex-col bg-[#F3EFE6] text-[#242321] rounded-sm border border-[#9B8575]/40 shadow-2xl p-5 sm:p-7 overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 text-[#9B8575] hover:text-[#242321] transition-colors rounded-sm cursor-pointer z-10 hover:bg-black/5"
          title="关闭"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="shrink-0 pb-3 border-b border-[#9B8575]/25 pr-10">
          <div className="flex items-center gap-2 text-[10px] font-mono tracking-widest text-[#702D32] uppercase mb-1">
            <Film className="w-3.5 h-3.5" />
            <span>CURATED ARCHIVE · 300+ 典藏片单库 (共 {MOVIE_DATABASE.length} 部真实电影)</span>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-1">
            <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#242321]">
              严选影史经典、国际影展与独立电影典藏
            </h2>
            <span className="text-[11px] font-mono text-[#9B8575]">
              当前筛选符合：<strong className="text-[#702D32]">{filteredMovies.length}</strong> 部影片
            </span>
          </div>
          <p className="font-serif text-xs text-[#9B8575] mt-0.5">
            涵盖华语、日韩、欧洲、美洲及跨文化独立佳作，每部均严格配置六维审美与情绪特征，供推荐引擎严谨加权匹配。
          </p>
        </div>

        {/* Filter & Search Bar */}
        <div className="shrink-0 py-3 space-y-2 border-b border-[#9B8575]/20">
          <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-2.5">
            {/* Genre Tabs */}
            <div className="flex flex-wrap items-center gap-1">
              <span className="text-[10px] font-mono text-[#9B8575] mr-1 hidden sm:inline flex items-center gap-1">
                <SlidersHorizontal className="w-3 h-3" /> 流派:
              </span>
              {genres.map((g) => (
                <button
                  key={g.key}
                  onClick={() => {
                    setSelectedGenre(g.key);
                    setCurrentPage(1);
                  }}
                  className={`px-2.5 py-1 text-xs font-serif rounded-xs transition-colors cursor-pointer ${
                    selectedGenre === g.key
                      ? 'bg-[#702D32] text-[#F3EFE6] font-semibold shadow-xs'
                      : 'bg-white/80 hover:bg-white text-[#242321] border border-[#9B8575]/30'
                  }`}
                >
                  {g.label}
                </button>
              ))}
            </div>

            {/* Search Box */}
            <div className="relative w-full md:w-64 shrink-0">
              <Search className="w-3.5 h-3.5 text-[#9B8575] absolute left-3 top-2.5 pointer-events-none" />
              <input
                type="text"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="搜索片名、导演、地区..."
                className="w-full pl-8 pr-3 py-1 bg-white border border-[#9B8575]/35 rounded-xs text-xs font-serif text-[#242321] focus:outline-none focus:border-[#702D32]"
              />
            </div>
          </div>

          {/* Region Tabs */}
          <div className="flex flex-wrap items-center gap-1 pt-1">
            <span className="text-[10px] font-mono text-[#9B8575] mr-1 hidden sm:inline flex items-center gap-1">
              <Globe className="w-3 h-3" /> 地区:
            </span>
            {regions.map((r) => (
              <button
                key={r.key}
                onClick={() => {
                  setSelectedRegion(r.key);
                  setCurrentPage(1);
                }}
                className={`px-2 py-0.5 text-[11px] font-serif rounded-xs transition-colors cursor-pointer ${
                  selectedRegion === r.key
                    ? 'bg-[#242321] text-[#F3EFE6] font-medium'
                    : 'bg-white/60 hover:bg-white text-[#5C5549] border border-[#9B8575]/25'
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>
        </div>

        {/* Movie Grid Scroll Area */}
        <div className="flex-1 overflow-y-auto py-4 pr-1">
          {filteredMovies.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5 sm:gap-4">
              {pagedMovies.map((movie) => (
                <div
                  key={movie.id}
                  onClick={() => {
                    onSelectMovie(movie);
                  }}
                  className="cursor-pointer group flex flex-col"
                >
                  <MoviePoster
                    movie={movie}
                    showTitles
                    className="w-full"
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="py-20 text-center text-[#9B8575] font-serif">
              <p className="text-sm">没有找到与筛选条件匹配的电影</p>
              <button
                onClick={() => {
                  setSearch('');
                  setSelectedGenre('all');
                  setSelectedRegion('all');
                  setCurrentPage(1);
                }}
                className="mt-3 px-3 py-1 text-xs font-serif text-[#702D32] underline cursor-pointer"
              >
                重置所有筛选
              </button>
            </div>
          )}
        </div>

        {/* Pagination Footer */}
        {filteredMovies.length > 0 && (
          <div className="shrink-0 pt-3 border-t border-[#9B8575]/25 flex items-center justify-between text-xs font-mono text-[#5C5549]">
            <div>
              <span>显示第 {(currentSafePage - 1) * ITEMS_PER_PAGE + 1} - {Math.min(currentSafePage * ITEMS_PER_PAGE, filteredMovies.length)} 部 / 共 {filteredMovies.length} 部</span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentSafePage <= 1}
                className="px-2.5 py-1 rounded-xs border border-[#9B8575]/30 bg-white hover:bg-[#F3EFE6] disabled:opacity-30 disabled:cursor-not-allowed flex items-center gap-1 transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span>上一页</span>
              </button>

              <span className="px-2 text-xs font-semibold text-[#242321]">
                {currentSafePage} / {totalPages}
              </span>

              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentSafePage >= totalPages}
                className="px-2.5 py-1 rounded-xs border border-[#9B8575]/30 bg-white hover:bg-[#F3EFE6] disabled:opacity-30 disabled:cursor-not-allowed flex items-center gap-1 transition-colors cursor-pointer"
              >
                <span>下一页</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

