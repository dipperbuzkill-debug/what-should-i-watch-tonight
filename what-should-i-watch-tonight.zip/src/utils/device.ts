/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Generate or retrieve a persistent client device ID for licensing
export function getOrCreateDeviceId(): string {
  if (typeof window === 'undefined') return 'server_device';
  
  const KEY = '__tonight_movie_device_id';
  let deviceId = localStorage.getItem(KEY);
  
  if (!deviceId) {
    const randomHex = Math.random().toString(36).substring(2, 10);
    const timeStamp = Date.now().toString(36);
    deviceId = `dev_${randomHex}_${timeStamp}`;
    localStorage.setItem(KEY, deviceId);
  }
  
  return deviceId;
}
