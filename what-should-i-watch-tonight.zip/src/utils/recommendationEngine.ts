/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Movie, RecommendationResult, UserProfile, QuizQuestion } from '../types';
import { MOVIE_DATABASE } from '../data/movies';
import { STAGE_1_QUESTIONS, STAGE_3_QUESTIONS } from '../data/questions';

export function calculateMovieRecommendations(
  answers: Record<number, string | string[]>,
  allActiveQuestions: QuizQuestion[] = []
): UserProfile {
  // Aggregate dimensional desires from user answers
  const userEmotions: Record<string, number> = {};
  const userBranches: Record<string, number> = {};
  const userVisuals: Record<string, number> = {};
  const userPacing: Record<string, number> = {};
  const userStyles: Record<string, number> = {};
  const userEndings: Record<string, number> = {};
  const userEras: Record<string, number> = {};
  const userPopularity: Record<string, number> = {};
  let durationPref: 'short' | 'medium' | 'long' | 'any' = 'any';
  const preferredRegions: string[] = [];

  // Content restrictions from Q12
  const restrictions: string[] = [];
  const q12Answer = answers[12];
  if (q12Answer) {
    if (Array.isArray(q12Answer)) {
      restrictions.push(...q12Answer);
    } else {
      restrictions.push(q12Answer);
    }
  }

  // Iterate over all active questions and their selected options
  allActiveQuestions.forEach((q) => {
    const ans = answers[q.id];
    if (!ans) return;

    const optIds = Array.isArray(ans) ? ans : [ans];
    optIds.forEach((optId) => {
      const opt = q.options.find((o) => o.id === optId);
      if (!opt) return;

      const w = opt.weights;
      if (w.emotions) {
        Object.entries(w.emotions).forEach(([k, v]) => {
          userEmotions[k] = (userEmotions[k] || 0) + (v || 0);
        });
      }
      if (w.branches) {
        Object.entries(w.branches).forEach(([k, v]) => {
          userBranches[k] = (userBranches[k] || 0) + (v || 0);
        });
      }
      if (w.visualAesthetics) {
        userVisuals[w.visualAesthetics] = (userVisuals[w.visualAesthetics] || 0) + 10;
      }
      if (w.storytellingPacing) {
        userPacing[w.storytellingPacing] = (userPacing[w.storytellingPacing] || 0) + 10;
      }
      if (w.storytellingStyle) {
        userStyles[w.storytellingStyle] = (userStyles[w.storytellingStyle] || 0) + 10;
      }
      if (w.endingType) {
        userEndings[w.endingType] = (userEndings[w.endingType] || 0) + 10;
      }
      if (w.eraType) {
        userEras[w.eraType] = (userEras[w.eraType] || 0) + 10;
      }
      if (w.popularityType) {
        userPopularity[w.popularityType] = (userPopularity[w.popularityType] || 0) + 10;
      }
      if (w.durationPreference) {
        durationPref = w.durationPreference;
      }
      if (w.regions && w.regions.length > 0) {
        preferredRegions.push(...w.regions);
      }
    });
  });

  // Strict negative content filtering:
  // If user selected restrictions in Q12 (unless 'res_none' is selected alone)
  const isExcluded = (movie: Movie): boolean => {
    if (restrictions.includes('res_none')) return false;

    if (restrictions.includes('res_horror')) {
      if (movie.genre.includes('恐怖') || movie.genre.includes('惊悚') && movie.attributes.primaryBranch === 'horror_thriller') {
        return true;
      }
    }
    if (restrictions.includes('res_gore')) {
      if (movie.contentWarnings.some((w) => w.includes('血') || w.includes('暴力') || w.includes('残暴'))) {
        return true;
      }
    }
    if (restrictions.includes('res_tragic')) {
      if (movie.endingTag === 'tragic_heartbreak') {
        return true;
      }
    }
    if (restrictions.includes('res_depressing')) {
      if (movie.contentWarnings.some((w) => w.includes('压抑') || w.includes('致郁') || w.includes('绝望'))) {
        return true;
      }
    }
    if (restrictions.includes('res_messy_romance')) {
      if (movie.romanceTag === 'complex_intense' && movie.contentWarnings.some((w) => w.includes('纠葛') || w.includes('争吵'))) {
        return true;
      }
    }
    return false;
  };

  const eligibleMovies = MOVIE_DATABASE.filter((m) => !isExcluded(m));

  // Score each movie based on the 6 weighted dimensions:
  // Emotional needs: 20%
  // Genre preferences: 20%
  // Storytelling preferences: 20%
  // Visual aesthetics: 15%
  // Pacing preferences: 10%
  // Ending preferences: 15%
  interface ScoredMovie {
    movie: Movie;
    totalScore: number;
    emotionalScore: number;
    genreScore: number;
    storytellingScore: number;
    visualScore: number;
    pacingScore: number;
    endingScore: number;
    matchHighlights: string[];
  }

  const scoredMovies: ScoredMovie[] = eligibleMovies.map((movie) => {
    const highlights: string[] = [];

    // 1. Emotional Score (max 100 * 0.20 = 20)
    let emotionalMatchSum = 0;
    let emotionalMaxSum = 0;
    Object.entries(userEmotions).forEach(([emotion, userWeight]) => {
      emotionalMaxSum += userWeight;
      const movieAttrWeight = (movie.attributes.emotionalNeeds as Record<string, number>)[emotion] || 0;
      emotionalMatchSum += (userWeight * (movieAttrWeight / 10));
    });
    const emotionalScore = emotionalMaxSum > 0 ? (emotionalMatchSum / emotionalMaxSum) * 100 : 70;
    if (emotionalScore > 80 && movie.moodTags[0]) {
      highlights.push(`契合你的情绪体验：${movie.moodTags[0]}`);
    }

    // 2. Genre / Branch Score (max 100 * 0.20 = 20)
    let genreScore = 50;
    const primaryBranchWeight = userBranches[movie.attributes.primaryBranch] || 0;
    const secondaryBranchWeight = movie.attributes.secondaryBranch ? (userBranches[movie.attributes.secondaryBranch] || 0) : 0;
    const totalBranchVotes = Object.values(userBranches).reduce((a, b) => a + b, 0) || 1;
    genreScore = Math.min(100, Math.round(((primaryBranchWeight * 1.5 + secondaryBranchWeight * 0.8) / (totalBranchVotes * 0.35)) * 100));
    if (genreScore > 75) {
      highlights.push(`精准对味你当下所处的【${movie.genre.join(' / ')}】探索分支`);
    }

    // 3. Storytelling preferences (max 100 * 0.20 = 20)
    let storytellingScore = 60;
    const styleMatches = (userStyles[movie.attributes.storytellingStyle] || 0) > 0;
    if (styleMatches) {
      storytellingScore += 30;
      highlights.push(`叙事形态：${movie.storytellingTags[0] || '大师级叙事'}`);
    }
    // Duration modifier
    if (durationPref === 'short' && movie.runtime <= 105) storytellingScore += 10;
    if (durationPref === 'long' && movie.runtime >= 130) storytellingScore += 10;
    if (durationPref === 'medium' && movie.runtime > 100 && movie.runtime < 135) storytellingScore += 10;
    storytellingScore = Math.min(100, storytellingScore);

    // 4. Visual aesthetics (max 100 * 0.15 = 15)
    let visualScore = 60;
    if ((userVisuals[movie.attributes.visualAesthetics] || 0) > 0) {
      visualScore = 95;
      highlights.push(`视觉质感：${movie.visualTags[0] || '独特光影'}`);
    } else {
      visualScore = 70;
    }

    // 5. Pacing preferences (max 100 * 0.10 = 10)
    let pacingScore = 60;
    if (userPacing[movie.attributes.storytellingPacing]) {
      pacingScore = 95;
    } else if (movie.attributes.storytellingPacing === 'balanced') {
      pacingScore = 80;
    }

    // 6. Ending preferences (max 100 * 0.15 = 15)
    let endingScore = 65;
    if (userEndings[movie.attributes.endingType]) {
      endingScore = 95;
    } else if (movie.attributes.endingType === 'warm_uplifting') {
      endingScore = 80;
    }

    // Additional region/era resonance
    let bonus = 0;
    if (preferredRegions.length > 0 && preferredRegions.some((r) => movie.country.includes(r))) {
      bonus += 3;
    }
    if (userEras[movie.attributes.eraType]) {
      bonus += 2;
    }
    if (userPopularity[movie.attributes.popularityType]) {
      bonus += 2;
    }

    const totalRaw =
      emotionalScore * 0.20 +
      genreScore * 0.20 +
      storytellingScore * 0.20 +
      visualScore * 0.15 +
      pacingScore * 0.10 +
      endingScore * 0.15 +
      bonus;

    // Normalizing between 75 and 98 to keep realistic, believable editorial precision
    const totalScore = Math.min(98, Math.max(76, Math.round(totalRaw)));

    return {
      movie,
      totalScore,
      emotionalScore,
      genreScore,
      storytellingScore,
      visualScore,
      pacingScore,
      endingScore,
      matchHighlights: highlights
    };
  });

  // Sort by totalScore descending
  scoredMovies.sort((a, b) => b.totalScore - a.totalScore);

  // Diversity-aware selection for top 5 films:
  // 1. 今晚最适合你 (Best overall match)
  // 2. 你可能错过的佳片 (Hidden gem with high compatibility)
  // 3. 走出舒适圈 (Out of comfort zone / distinctive art gem)
  // 4. 轻松一点的选择 (Lighter alternative)
  // 5. 深度共鸣 (Deep resonance match)
  const selectedList: RecommendationResult[] = [];
  const usedDirectors = new Set<string>();
  const usedIds = new Set<string>();

  // Slot 1: Best overall
  const topCandidate = scoredMovies[0];
  selectedList.push({
    movie: topCandidate.movie,
    score: topCandidate.totalScore,
    category: 'primary_match',
    categoryLabel: '今晚最适合你',
    categoryReason: '综合你今晚的情感需求、叙事偏好与视觉期待，这是当下最完美的命中作品。',
    matchHighlights: topCandidate.matchHighlights
  });
  usedDirectors.add(topCandidate.movie.director);
  usedIds.add(topCandidate.movie.id);

  // Slot 2: Hidden Gem (popularityType === 'hidden_gem' or 'cult_arthouse' with top score)
  const gemCandidate = scoredMovies.find(
    (s) =>
      !usedIds.has(s.movie.id) &&
      !usedDirectors.has(s.movie.director) &&
      (s.movie.attributes.popularityType === 'hidden_gem' || s.movie.attributes.popularityType === 'cult_arthouse')
  ) || scoredMovies.find((s) => !usedIds.has(s.movie.id) && !usedDirectors.has(s.movie.director));

  if (gemCandidate) {
    selectedList.push({
      movie: gemCandidate.movie,
      // Slight smooth scale
      score: Math.min(topCandidate.totalScore - 2, gemCandidate.totalScore),
      category: 'hidden_gem',
      categoryLabel: '你可能错过的佳片',
      categoryReason: '口碑封神但鲜少被大众算法推送的珍藏好片，充满意想不到的惊喜。',
      matchHighlights: gemCandidate.matchHighlights
    });
    usedDirectors.add(gemCandidate.movie.director);
    usedIds.add(gemCandidate.movie.id);
  }

  // Slot 3: Out of comfort zone (distinct secondary branch or philosophical depth)
  const comfortCandidate = scoredMovies.find(
    (s) =>
      !usedIds.has(s.movie.id) &&
      !usedDirectors.has(s.movie.director) &&
      s.movie.attributes.primaryBranch !== topCandidate.movie.attributes.primaryBranch
  ) || scoredMovies.find((s) => !usedIds.has(s.movie.id) && !usedDirectors.has(s.movie.director));

  if (comfortCandidate) {
    selectedList.push({
      movie: comfortCandidate.movie,
      score: Math.min(topCandidate.totalScore - 4, comfortCandidate.totalScore),
      category: 'out_of_comfort',
      categoryLabel: '走出舒适圈',
      categoryReason: '跳出惯性审美的艺术奇遇，用全新的视角带你领略不同维度的光影力量。',
      matchHighlights: comfortCandidate.matchHighlights
    });
    usedDirectors.add(comfortCandidate.movie.director);
    usedIds.add(comfortCandidate.movie.id);
  }

  // Slot 4: Light alternative (high comfort / joy or comedy_light / uplifting ending)
  const lightCandidate = scoredMovies.find(
    (s) =>
      !usedIds.has(s.movie.id) &&
      !usedDirectors.has(s.movie.director) &&
      (s.movie.attributes.primaryBranch === 'comedy_light' ||
        s.movie.endingTag === 'warm_uplifting' ||
        (s.movie.attributes.emotionalNeeds.comfort || 0) >= 9)
  ) || scoredMovies.find((s) => !usedIds.has(s.movie.id) && !usedDirectors.has(s.movie.director));

  if (lightCandidate) {
    selectedList.push({
      movie: lightCandidate.movie,
      score: Math.min(topCandidate.totalScore - 6, lightCandidate.totalScore),
      category: 'light_choice',
      categoryLabel: '轻松一点的选择',
      categoryReason: '若感觉身心疲惫，这部片子能给你最无压力的抚慰与开怀欢笑。',
      matchHighlights: lightCandidate.matchHighlights
    });
    usedDirectors.add(lightCandidate.movie.director);
    usedIds.add(lightCandidate.movie.id);
  }

  // Slot 5: Deep resonance / Final bespoke pick
  const fifthCandidate = scoredMovies.find(
    (s) => !usedIds.has(s.movie.id) && !usedDirectors.has(s.movie.director)
  ) || scoredMovies.find((s) => !usedIds.has(s.movie.id)) || scoredMovies[1];

  if (fifthCandidate) {
    selectedList.push({
      movie: fifthCandidate.movie,
      score: Math.min(topCandidate.totalScore - 8, fifthCandidate.totalScore),
      category: 'deep_resonance',
      categoryLabel: '深度共鸣之选',
      categoryReason: '情感颗粒度极度细腻，无论何时回看都能触动你心底最隐秘的共鸣弦。',
      matchHighlights: fifthCandidate.matchHighlights
    });
  }

  // Build Personalized Taste Profile
  const profile = generateTasteProfile(userEmotions, userBranches, userVisuals, userPacing, selectedList);
  return profile;
}

function generateTasteProfile(
  emotions: Record<string, number>,
  branches: Record<string, number>,
  visuals: Record<string, number>,
  pacing: Record<string, number>,
  recommendations: RecommendationResult[]
): UserProfile {
  // Sort top emotions
  const sortedEmotions = Object.entries(emotions).sort((a, b) => b[1] - a[1]);
  const emotionLabels: Record<string, string> = {
    comfort: '温柔治愈',
    catharsis: '情感宣泄',
    romantic_longing: '浪漫心动',
    intellectual_stimulation: '智性思辨',
    thrill: '高能张力',
    escapism: '精神出逃',
    poetic_wonder: '诗意漫游',
    existential_reflection: '生命沉思',
    joy_laughter: '欢畅解压',
    melancholy: '美学怅惘'
  };

  const topEmotions = sortedEmotions.slice(0, 3).map(([k]) => emotionLabels[k] || k);

  // Determine Persona Title
  let title = '夜行诗意观察者';
  let subtitle = 'THE CONTEMPLATIVE FLÂNEUR';
  let desc = '你在电影中寻找的不是单纯的感官刺激，而是一场关于生命、美学与自我的深度对话。你对光影的质感与情感的克制有着与生俱来的鉴赏力。';
  let philosophy = '电影是每秒24格的真理，在银幕的明暗之间，我们看见了生活的另一种可能。';

  const topBranch = Object.entries(branches).sort((a, b) => b[1] - a[1])[0]?.[0];

  if (topBranch === 'romance') {
    title = '浪漫现实撕裂者';
    subtitle = 'THE ROMANTIC REALIST';
    desc = '你深知童话的脆弱，却依然对人与人之间真实的灵魂相遇抱有崇高敬意。你更看重眼神交汇时的克制、不可言说的遗憾，以及柴米油盐磨砺后的真挚陪伴。';
    philosophy = '即使预先知道沿途的所有悲伤，我依然会张开双臂迎接与你相遇的每一个瞬间。';
  } else if (topBranch === 'mystery_crime') {
    title = '智性迷宫漫游家';
    subtitle = 'THE INTELLECTUAL LABYRINTH';
    desc = '你拥有极度敏锐的观察力与严密的逻辑偏好，享受在错综复杂的反转与人性深渊中抽丝剥茧。平庸的剧情无法满足你，你需要的是一场旗鼓相当的头脑风暴。';
    philosophy = '真相可能比谎言更加残酷，但正是对真理的求索赋予了人类最高的尊严。';
  } else if (topBranch === 'scifi_fantasy') {
    title = '宇宙奇迹筑梦师';
    subtitle = 'THE COSMIC VISIONARY';
    desc = '你的目光始终投向浩瀚星辰与时间尽头。你崇尚宏大的世界观、颠覆常理的哲学假设，以及在那无垠虚空深处依然闪耀的人类爱意。';
    philosophy = '爱不是人类发明的东西，它跨越了维度、时间与空间，将我们引向星辰彼岸。';
  } else if (topBranch === 'comedy_light') {
    title = '通透豁达生活家';
    subtitle = 'THE PLAYFUL PHILOSOPHER';
    desc = '你看清了生活的重重不易，却依然选择用幽默与笑声作为最锋利的铠甲。你欣赏机智有内涵的幽默，渴望在温情合家欢与自我解嘲中给灵魂充饱电。';
    philosophy = '人生就像一场即兴喜剧，懂得在荒诞中放声大笑的人，永远掌握着生活的主动权。';
  } else if (topBranch === 'adventure_action') {
    title = '热血荒野逐光者';
    subtitle = 'THE WILDERNESS VOYAGER';
    desc = '你拒绝被困在日常的琐碎牢笼里，心中永远奔涌着跨越山海、直面风浪的野性冲动。你崇尚实打实的勇气、纯正的视听张力与走出舒适圈的蜕变。';
    philosophy = '去面对危险，去看世界，去贴近彼此，感受生活，这就是我们活着的全部意义。';
  } else if (topBranch === 'horror_thriller') {
    title = '深渊暗语解读人';
    subtitle = 'THE SHADOW ARCHITECT';
    desc = '你敢于直视人性的幽暗与潜意识的梦魇。你所追求的并非廉价惊吓，而是那种由顶级构图、心理压迫与艺术隐喻构筑起的窒息美感。';
    philosophy = '我们凝视深渊，是为了看清内心真正的恐惧，从而在恐惧中完成灵魂的蜕变。';
  }

  // Visual & pacing descriptions
  const topVisualKey = Object.entries(visuals).sort((a, b) => b[1] - a[1])[0]?.[0] || 'warm_golden';
  const visualDescMap: Record<string, string> = {
    warm_golden: '偏爱暖黄夕阳、复古胶片与充满体温感的光影质感',
    noir_nocturnal: '钟情雨夜霓虹、深邃阴影与冷峻神秘的黑色电影美学',
    minimalist_clean: '倾向极简留白、克制建筑线条与沉静通透的冷调画面',
    vivid_painterly: '热衷高饱和度油画感、梦幻对称构图与斑斓童话色彩',
    gritty_realistic: '青睐质朴自然光、粗粝手持纪实与未加修饰的生活肌理',
    retro_vintage: '沉醉古典大画幅黑白与老派胶片颗粒的历史沉淀'
  };

  const topPacingKey = Object.entries(pacing).sort((a, b) => b[1] - a[1])[0]?.[0] || 'balanced';
  const pacingDescMap: Record<string, string> = {
    slow: '喜欢静水流深的慢节奏长镜头，给呼吸与思考留足余地',
    balanced: '偏好起承转合行云流水的黄金节奏，张弛有度',
    fast: '追求信息密度极高、节奏紧凑如电光石火的高能推进'
  };

  return {
    profileTitle: title,
    profileSubtitle: subtitle,
    profileDescription: desc,
    topEmotions,
    preferredVisualAtmosphere: visualDescMap[topVisualKey] || '充满质感的电影光影',
    storytellingPreference: pacingDescMap[topPacingKey] || '张弛有度、剧情与情感并重的叙事',
    cinemaPhilosophy: philosophy,
    recommendedTonight: recommendations
  };
}
