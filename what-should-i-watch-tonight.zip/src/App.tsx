/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { QuizView } from './components/QuizView';
import { ResultsView } from './components/ResultsView';
import { ActivationModal } from './components/ActivationModal';
import { AdminView } from './components/AdminView';
import { DatabasePreviewModal } from './components/DatabasePreviewModal';
import { MovieDetailModal } from './components/MovieDetailModal';
import { calculateMovieRecommendations } from './utils/recommendationEngine';
import { UserProfile, Movie, QuizQuestion } from './types';
import { getOrCreateDeviceId } from './utils/device';

export default function App() {
  const [view, setView] = useState<'home' | 'quiz' | 'results'>('home');
  const [isActivated, setIsActivated] = useState<boolean>(false);
  const [activeCode, setActiveCode] = useState<string | undefined>(undefined);
  const [profileResult, setProfileResult] = useState<UserProfile | null>(null);

  // Modals
  const [isActivationOpen, setIsActivationOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isDatabaseOpen, setIsDatabaseOpen] = useState(false);
  const [selectedPreviewMovie, setSelectedPreviewMovie] = useState<Movie | null>(null);

  // Check stored activation on mount & verify with backend
  useEffect(() => {
    const storedCode = localStorage.getItem('__tonight_movie_activated_code');
    if (storedCode) {
      setActiveCode(storedCode);
      setIsActivated(true);

      // Verify with backend
      const deviceId = getOrCreateDeviceId();
      fetch('/api/activation/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: storedCode, deviceId })
      })
        .then((res) => res.json())
        .then((data) => {
          if (!data.isValid) {
            console.warn('Stored code is no longer valid on server');
          }
        })
        .catch((err) => {
          console.warn('Backend verification offline, relying on client lease', err);
        });
    }
  }, []);

  const handleStartQuiz = () => {
    if (isActivated) {
      setView('quiz');
    } else {
      setIsActivationOpen(true);
    }
  };

  const handleActivationSuccess = (code: string) => {
    setIsActivated(true);
    setActiveCode(code);
    localStorage.setItem('__tonight_movie_activated_code', code);
    // If user clicked start quiz before activating, jump straight into quiz
    setView('quiz');
  };

  const handleQuizComplete = (
    answers: Record<number, string | string[]>,
    activeQuestions: QuizQuestion[]
  ) => {
    const result = calculateMovieRecommendations(answers, activeQuestions);
    setProfileResult(result);
    setView('results');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRetakeQuiz = () => {
    localStorage.removeItem('__tonight_movie_quiz_state');
    setView('quiz');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGoHome = () => {
    setView('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#F3EFE6] text-[#242321] flex flex-col justify-between selection:bg-[#702D32] selection:text-[#F3EFE6]">
      {/* Top Navigation Bar adhering to the Top Bar contract */}
      <Navbar
        onStartQuiz={handleStartQuiz}
        onOpenActivation={() => setIsActivationOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onNavigateHome={handleGoHome}
        isActivated={isActivated}
        activeCode={activeCode}
        onViewDatabase={() => setIsDatabaseOpen(true)}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {view === 'home' && (
          <Hero
            onStartQuiz={handleStartQuiz}
            onOpenActivation={() => setIsActivationOpen(true)}
            isActivated={isActivated}
            activeCode={activeCode}
            onSelectMovie={(movie) => setSelectedPreviewMovie(movie)}
          />
        )}

        {view === 'quiz' && (
          <QuizView
            onComplete={handleQuizComplete}
            onExit={handleGoHome}
          />
        )}

        {view === 'results' && profileResult && (
          <ResultsView
            profile={profileResult}
            onRetake={handleRetakeQuiz}
            onGoHome={handleGoHome}
          />
        )}
      </main>

      {/* Editorial Magazine Footer */}
      <footer className="border-t border-[#9B8575]/25 bg-[#F3EFE6] py-10 text-xs font-serif text-[#9B8575]">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#242321]">今晚看什么？</span>
            <span aria-hidden="true">·</span>
            <span>WHAT SHOULD I WATCH TONIGHT?</span>
          </div>

          <div className="flex items-center gap-6">
            <button
              onClick={() => setIsDatabaseOpen(true)}
              className="hover:text-[#702D32] transition-colors cursor-pointer"
            >
              100+ 典藏片单库
            </button>
            <button
              onClick={() => setIsActivationOpen(true)}
              className="hover:text-[#702D32] transition-colors cursor-pointer"
            >
              兑换码激活
            </button>
            <button
              onClick={() => setIsAdminOpen(true)}
              className="hover:text-[#702D32] transition-colors cursor-pointer"
            >
              管理员控制台
            </button>
          </div>

          <p className="font-mono text-[11px] opacity-75">
            © 2026 TONIGHT CINEMA JOURNAL. ALL RIGHTS RESERVED.
          </p>
        </div>
      </footer>

      {/* Modals */}
      <ActivationModal
        isOpen={isActivationOpen}
        onClose={() => setIsActivationOpen(false)}
        onSuccess={handleActivationSuccess}
        isActivated={isActivated}
        currentCode={activeCode}
      />

      <AdminView
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
      />

      <DatabasePreviewModal
        isOpen={isDatabaseOpen}
        onClose={() => setIsDatabaseOpen(false)}
        onSelectMovie={(movie) => {
          setSelectedPreviewMovie(movie);
        }}
      />

      <MovieDetailModal
        movie={selectedPreviewMovie}
        onClose={() => setSelectedPreviewMovie(null)}
      />
    </div>
  );
}
