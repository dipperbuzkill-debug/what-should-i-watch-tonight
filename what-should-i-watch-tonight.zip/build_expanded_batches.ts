import fs from 'fs';
import { ALL_MOVIES } from './src/data/movies.ts';
import { EXPANDED_INTERNATIONAL_FILMS_BATCH_1 } from './src/data/expandedMoviesBatch1.ts';
import { EXPANDED_INTERNATIONAL_FILMS_BATCH_2 } from './src/data/expandedMoviesBatch2.ts';

const existingTitles = new Set([
  ...ALL_MOVIES.map(m => m.chineseTitle),
  ...EXPANDED_INTERNATIONAL_FILMS_BATCH_1.map(m => m.chineseTitle),
  ...EXPANDED_INTERNATIONAL_FILMS_BATCH_2.map(m => m.chineseTitle)
]);

console.log('Existing titles:', existingTitles.size);
