import fs from 'fs';
import { ALL_MOVIES } from './src/data/movies.ts';
import { EXPANDED_INTERNATIONAL_FILMS_BATCH_1 } from './src/data/expandedMoviesBatch1.ts';
import { EXPANDED_INTERNATIONAL_FILMS_BATCH_2 } from './src/data/expandedMoviesBatch2.ts';

const existingTitles = new Set([
  ...ALL_MOVIES.map(m => m.chineseTitle),
  ...EXPANDED_INTERNATIONAL_FILMS_BATCH_1.map(m => m.chineseTitle),
  ...EXPANDED_INTERNATIONAL_FILMS_BATCH_2.map(m => m.chineseTitle)
]);

interface FilmSpec {
  chineseTitle: string;
  originalTitle: string;
  releaseYear: number;
  country: string;
  director: string;
  genre: string[];
  runtime: number;
  synopsis: string;
  moodTags: string[];
  storytellingTags: string[];
  visualTags: string[];
  pacingTag: 'slow' | 'balanced' | 'fast';
  endingTag: 'warm_uplifting' | 'bitter_sweet' | 'tragic_heartbreak' | 'open_thought_provoking' | 'mind_twist';
  romanceTag?: 'sweet' | 'slow_burn' | 'heartbreak' | 'realistic' | 'complex_intense' | 'friendship_platonic' | 'none';
  contentWarnings: string[];
  primaryBranch: 'romance' | 'mystery_crime' | 'scifi_fantasy' | 'arthouse_drama' | 'comedy_light' | 'adventure_action' | 'horror_thriller' | 'general_exploration';
  secondaryBranch?: 'romance' | 'mystery_crime' | 'scifi_fantasy' | 'arthouse_drama' | 'comedy_light' | 'adventure_action' | 'horror_thriller' | 'general_exploration';
  storytellingPacing: 'slow' | 'balanced' | 'fast';
  storytellingStyle: 'character_driven' | 'plot_driven' | 'poetic_atmosphere' | 'puzzle_investigation' | 'philosophical' | 'surreal';
  visualAesthetics: 'warm_golden' | 'noir_nocturnal' | 'minimalist_clean' | 'vivid_painterly' | 'gritty_realistic' | 'retro_vintage';
  endingType: 'warm_uplifting' | 'bitter_sweet' | 'tragic_heartbreak' | 'open_thought_provoking' | 'mind_twist';
  eraType: 'classic' | 'retro_90s_00s' | 'modern_recent';
  popularityType: 'crowd_pleaser' | 'masterpiece' | 'hidden_gem' | 'cult_arthouse';
  emotionalNeeds: Record<string, number>;
  whyRecommendedDefault: string;
  bestViewingAtmosphere: string;
  editorialPalette: { bg: string; text: string; accent: string };
  coverSource: string;
}

// Generate the TypeScript file with pristine structure
export function generateBatchTS(batchVarName: string, films: FilmSpec[], startId: number): string {
  let code = `/**\n * @license\n * SPDX-License-Identifier: Apache-2.0\n */\n\nimport { Movie } from '../types';\n\nexport const ${batchVarName}: Movie[] = [\n`;

  films.forEach((f, idx) => {
    const id = `m${startId + idx}`;
    code += `  {\n`;
    code += `    id: '${id}',\n`;
    code += `    chineseTitle: '${f.chineseTitle}',\n`;
    code += `    originalTitle: '${f.originalTitle.replace(/'/g, "\\'")}',\n`;
    code += `    releaseYear: ${f.releaseYear},\n`;
    code += `    country: '${f.country}',\n`;
    code += `    director: '${f.director}',\n`;
    code += `    genre: ${JSON.stringify(f.genre)},\n`;
    code += `    runtime: ${f.runtime},\n`;
    code += `    synopsis: '${f.synopsis.replace(/'/g, "\\'")}',\n`;
    code += `    moodTags: ${JSON.stringify(f.moodTags)},\n`;
    code += `    storytellingTags: ${JSON.stringify(f.storytellingTags)},\n`;
    code += `    visualTags: ${JSON.stringify(f.visualTags)},\n`;
    code += `    pacingTag: '${f.pacingTag}',\n`;
    code += `    endingTag: '${f.endingTag}',\n`;
    code += `    romanceTag: '${f.romanceTag || 'none'}',\n`;
    code += `    contentWarnings: ${JSON.stringify(f.contentWarnings)},\n`;
    code += `    attributes: {\n`;
    code += `      emotionalNeeds: ${JSON.stringify(f.emotionalNeeds)},\n`;
    code += `      primaryBranch: '${f.primaryBranch}',\n`;
    if (f.secondaryBranch) code += `      secondaryBranch: '${f.secondaryBranch}',\n`;
    code += `      storytellingPacing: '${f.storytellingPacing}',\n`;
    code += `      storytellingStyle: '${f.storytellingStyle}',\n`;
    code += `      visualAesthetics: '${f.visualAesthetics}',\n`;
    code += `      endingType: '${f.endingType}',\n`;
    code += `      eraType: '${f.eraType}',\n`;
    code += `      popularityType: '${f.popularityType}',\n`;
    code += `    },\n`;
    code += `    coverUrl: '',\n`;
    code += `    coverSource: '${f.coverSource}',\n`;
    code += `    coverLicense: 'Official Theatrical Release',\n`;
    code += `    editorialPalette: ${JSON.stringify(f.editorialPalette)},\n`;
    code += `    whyRecommendedDefault: '${f.whyRecommendedDefault.replace(/'/g, "\\'")}',\n`;
    code += `    bestViewingAtmosphere: '${f.bestViewingAtmosphere.replace(/'/g, "\\'")}',\n`;
    code += `  },\n`;
  });

  code += `];\n`;
  return code;
}
