/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'cinema2026admin';

app.use(express.json());

// Persistent Activation Codes Store
interface CodeRecord {
  code: string;
  createdAt: string;
  activatedAt?: string;
  devicesUsed: string[];
  maxDevices: number;
  isActive: boolean;
  notes?: string;
}

const DATA_DIR = path.resolve(__dirname, 'data');
const DATA_FILE = path.resolve(DATA_DIR, 'activation_codes.json');

// Initial pre-seeded codes
const INITIAL_CODES: CodeRecord[] = [
  {
    code: 'CINEMA2026',
    createdAt: new Date().toISOString(),
    devicesUsed: [],
    maxDevices: 5,
    isActive: true,
    notes: '官方体验演示码（多设备支持）'
  },
  {
    code: 'VIP888',
    createdAt: new Date().toISOString(),
    devicesUsed: [],
    maxDevices: 3,
    isActive: true,
    notes: '小红书首批专属兑换码'
  },
  {
    code: 'REDVELVET',
    createdAt: new Date().toISOString(),
    devicesUsed: [],
    maxDevices: 3,
    isActive: true,
    notes: '影迷沙龙特惠码'
  },
  {
    code: 'ARTHOUSE',
    createdAt: new Date().toISOString(),
    devicesUsed: [],
    maxDevices: 2,
    isActive: true,
    notes: '独立电影人品鉴码'
  }
];

function loadCodes(): CodeRecord[] {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(DATA_FILE)) {
      const content = fs.readFileSync(DATA_FILE, 'utf-8');
      return JSON.parse(content);
    }
  } catch (err) {
    console.error('Failed reading activation codes data:', err);
  }
  saveCodes(INITIAL_CODES);
  return INITIAL_CODES;
}

function saveCodes(codes: CodeRecord[]) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(codes, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed writing activation codes data:', err);
  }
}

let codesStore: CodeRecord[] = loadCodes();

// ==========================================
// ACTIVATION & VERIFICATION API
// ==========================================

// 1. Activate Code
app.post('/api/activation/activate', (req: Request, res: Response): any => {
  const { code, deviceId } = req.body;

  if (!code || typeof code !== 'string') {
    return res.status(400).json({ success: false, message: '请输入有效的兑换码' });
  }

  const cleanCode = code.trim().toUpperCase();
  const cleanDeviceId = (deviceId && typeof deviceId === 'string') ? deviceId.trim() : 'default_device';

  const record = codesStore.find((c) => c.code === cleanCode);

  if (!record) {
    return res.status(404).json({
      success: false,
      message: '兑换码不存在。请核对大小写输入，或联系小红书购买渠道客服核查。'
    });
  }

  if (!record.isActive) {
    return res.status(403).json({
      success: false,
      message: '该兑换码已被停用或退款作废。如有疑问请联系售后客服。'
    });
  }

  // Already activated on this specific device
  if (record.devicesUsed.includes(cleanDeviceId)) {
    return res.json({
      success: true,
      message: '已在此设备上验证通过',
      code: record.code,
      devicesCount: record.devicesUsed.length,
      maxDevices: record.maxDevices,
      isReactivation: true
    });
  }

  // Check device limit
  if (record.devicesUsed.length >= record.maxDevices) {
    return res.status(403).json({
      success: false,
      message: `该兑换码已达到最大设备上限（最多支持 ${record.maxDevices} 台设备）。若需在新设备登录，请联系管理员重置设备记录。`
    });
  }

  // Add device
  record.devicesUsed.push(cleanDeviceId);
  if (!record.activatedAt) {
    record.activatedAt = new Date().toISOString();
  }

  saveCodes(codesStore);

  return res.json({
    success: true,
    message: '激活成功！您已获得永久无限次观影测评权限。',
    code: record.code,
    devicesCount: record.devicesUsed.length,
    maxDevices: record.maxDevices
  });
});

// 2. Verify Code
app.post('/api/activation/verify', (req: Request, res: Response): any => {
  const { code, deviceId } = req.body;

  if (!code || typeof code !== 'string') {
    return res.json({ isValid: false });
  }

  const cleanCode = code.trim().toUpperCase();
  const cleanDeviceId = (deviceId && typeof deviceId === 'string') ? deviceId.trim() : 'default_device';

  const record = codesStore.find((c) => c.code === cleanCode);

  if (!record || !record.isActive) {
    return res.json({ isValid: false, reason: 'inactive_or_not_found' });
  }

  // If already registered or has available capacity
  const isRegisteredOnDevice = record.devicesUsed.includes(cleanDeviceId);
  return res.json({
    isValid: isRegisteredOnDevice,
    code: record.code,
    devicesCount: record.devicesUsed.length,
    maxDevices: record.maxDevices
  });
});

// ==========================================
// ADMIN CODE MANAGEMENT API
// ==========================================

// Simple bearer or header check
const checkAdminAuth = (req: Request, res: Response, next: Function): any => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader === `Bearer ${ADMIN_PASSWORD}`) {
    return next();
  }
  return res.status(401).json({ error: '管理员身份验证失败' });
};

// Admin Login
app.post('/api/admin/login', (req: Request, res: Response): any => {
  const { password } = req.body;
  if (password === ADMIN_PASSWORD) {
    return res.json({ success: true, token: ADMIN_PASSWORD });
  }
  return res.status(401).json({ success: false, message: '管理员密码错误' });
});

// List All Codes
app.get('/api/admin/codes', checkAdminAuth, (_req: Request, res: Response) => {
  res.json({ codes: codesStore });
});

// Generate Codes (Single or Batch)
app.post('/api/admin/generate', checkAdminAuth, (req: Request, res: Response): any => {
  const { count = 1, maxDevices = 3, prefix = 'CINEMA', notes = '管理员后台生成' } = req.body;
  const numCount = Math.min(100, Math.max(1, Number(count)));

  const newCodes: CodeRecord[] = [];
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

  for (let i = 0; i < numCount; i++) {
    let rand = '';
    for (let j = 0; j < 8; j++) {
      rand += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    const generatedCode = `${prefix.toUpperCase()}-${rand.slice(0, 4)}-${rand.slice(4)}`;
    const record: CodeRecord = {
      code: generatedCode,
      createdAt: new Date().toISOString(),
      devicesUsed: [],
      maxDevices: Math.max(1, Number(maxDevices) || 3),
      isActive: true,
      notes
    };
    codesStore.unshift(record);
    newCodes.push(record);
  }

  saveCodes(codesStore);
  return res.json({ success: true, createdCount: newCodes.length, codes: newCodes });
});

// Toggle Status (Disable / Enable)
app.post('/api/admin/toggle', checkAdminAuth, (req: Request, res: Response): any => {
  const { code, isActive } = req.body;
  const record = codesStore.find((c) => c.code === code);
  if (!record) {
    return res.status(404).json({ success: false, message: '未找到指定兑换码' });
  }
  record.isActive = Boolean(isActive);
  saveCodes(codesStore);
  return res.json({ success: true, code: record.code, isActive: record.isActive });
});

// Update Device Limit & Reset Devices
app.post('/api/admin/update-limit', checkAdminAuth, (req: Request, res: Response): any => {
  const { code, maxDevices, resetDevices } = req.body;
  const record = codesStore.find((c) => c.code === code);
  if (!record) {
    return res.status(404).json({ success: false, message: '未找到指定兑换码' });
  }

  if (maxDevices !== undefined) {
    record.maxDevices = Math.max(1, Number(maxDevices));
  }
  if (resetDevices) {
    record.devicesUsed = [];
  }

  saveCodes(codesStore);
  return res.json({
    success: true,
    code: record.code,
    maxDevices: record.maxDevices,
    devicesUsed: record.devicesUsed
  });
});

// ==========================================
// STATIC / VITE INTEGRATION
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    // In dev: mount vite.middlewares
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // In prod: serve dist files
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer();
