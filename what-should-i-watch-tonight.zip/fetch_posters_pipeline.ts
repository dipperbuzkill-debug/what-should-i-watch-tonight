import fs from 'fs';
import path from 'path';
import https from 'https';
import http from 'http';
import { execSync } from 'child_process';

interface MovieItem {
  id: string;
  chineseTitle: string;
  originalTitle: string;
  releaseYear: number;
  director: string;
  country: string;
  genre: string[];
}

const movies: MovieItem[] = JSON.parse(fs.readFileSync('all_movies_audit.json', 'utf8'));

// Load existing 20 verified posters from posterCatalog.ts
const initialVerifiedIds = new Set([
  'm1', 'm2', 'm5', 'm11', 'm12', 'm13', 'm14', 'm15', 'm16', 'm17',
  'm18', 'm19', 'm26', 'm32', 'm35', 'm52', 'm57', 'm78', 'm84', 'm90'
]);

function requestJson(url: string, headers: Record<string, string> = {}): Promise<any> {
  return new Promise((resolve) => {
    try {
      const u = new URL(url);
      const req = https.request({
        hostname: u.hostname,
        path: u.pathname + u.search,
        method: 'GET',
        headers: {
          'User-Agent': 'MoviePosterAuditBot/1.0 (contact: admin@cinema.internal)',
          ...headers
        },
        timeout: 7000
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            resolve(JSON.parse(data));
          } catch {
            resolve(null);
          }
        });
      });
      req.on('error', () => resolve(null));
      req.on('timeout', () => { req.destroy(); resolve(null); });
      req.end();
    } catch {
      resolve(null);
    }
  });
}

function searchWikidata(query: string): Promise<any[]> {
  const url = `https://www.wikidata.org/w/api.php?action=wbsearchentities&search=${encodeURIComponent(query)}&language=en&format=json&limit=7`;
  return requestJson(url).then(d => d?.search || []);
}

function getWikidataEntity(qid: string): Promise<any> {
  const url = `https://www.wikidata.org/wiki/Special:EntityData/${qid}.json`;
  return requestJson(url).then(d => d?.entities?.[qid] || null);
}

function getTmdbPoster(tmdbId: string): string | null {
  try {
    const curlCmd = `curl -s -L -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" "https://www.themoviedb.org/movie/${tmdbId}"`;
    const out = execSync(curlCmd, { timeout: 10000, encoding: 'utf8' });
    const m = out.match(/https:\/\/image\.tmdb\.org\/t\/p\/w[0-9]+\/([a-zA-Z0-9_-]+\.jpg)/) ||
              out.match(/https:\/\/media\.themoviedb\.org\/t\/p\/w[0-9_and_h]*_face\/([a-zA-Z0-9_-]+\.jpg)/);
    if (m && m[1]) {
      return `https://image.tmdb.org/t/p/w500/${m[1]}`;
    }
  } catch {}
  return null;
}

function searchTmdbDirect(title: string, year: number): string | null {
  try {
    const q = encodeURIComponent(`${title}`);
    const curlCmd = `curl -s -L -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" "https://www.themoviedb.org/search/movie?query=${q}"`;
    const out = execSync(curlCmd, { timeout: 10000, encoding: 'utf8' });
    const matches = out.matchAll(/data-id="([a-zA-Z0-9]+)"[^>]*href="\/movie\/([0-9]+)[^"]*"[\s\S]*?srcset="https:\/\/media\.themoviedb\.org\/t\/p\/w[0-9_and_h]*_face\/([a-zA-Z0-9_-]+\.jpg)/g);
    for (const match of matches) {
      if (match[3]) {
        return `https://image.tmdb.org/t/p/w500/${match[3]}`;
      }
    }
  } catch {}
  return null;
}

async function findPosterForMovie(movie: MovieItem): Promise<{ url: string; source: string; distributor: string } | null> {
  // Try 1: Search by originalTitle
  let entities = await searchWikidata(movie.originalTitle);
  let bestQid: string | null = null;
  const yearStr = movie.releaseYear.toString();

  for (const e of entities) {
    const desc = (e.description || '').toLowerCase();
    if (desc.includes(yearStr) || desc.includes('film') || desc.includes('movie')) {
      bestQid = e.id;
      break;
    }
  }

  // Try 2: Search by chineseTitle if no match
  if (!bestQid) {
    entities = await searchWikidata(movie.chineseTitle);
    for (const e of entities) {
      const desc = (e.description || '').toLowerCase();
      if (desc.includes('film') || desc.includes('movie') || desc.includes(yearStr)) {
        bestQid = e.id;
        break;
      }
    }
  }

  if (bestQid) {
    const entity = await getWikidataEntity(bestQid);
    if (entity) {
      const claims = entity.claims || {};
      const tmdbClaims = claims['P4947'] || [];
      const tmdbIds = tmdbClaims.map((c: any) => c.mainsnak?.datavalue?.value).filter(Boolean);
      if (tmdbIds.length > 0) {
        const posterUrl = getTmdbPoster(tmdbIds[0]);
        if (posterUrl) {
          return {
            url: posterUrl,
            source: `TMDb (The Movie Database) ID: ${tmdbIds[0]} 官方公映物料`,
            distributor: 'Theatrical Distribution Archive'
          };
        }
      }
    }
  }

  // Try 3: Direct TMDb Search by English / original title
  const directPoster = searchTmdbDirect(movie.originalTitle, movie.releaseYear);
  if (directPoster) {
    return {
      url: directPoster,
      source: `TMDb 官方剧场版海报库`,
      distributor: 'Theatrical Release'
    };
  }

  // Try 4: Direct TMDb Search by Chinese title
  const directChinesePoster = searchTmdbDirect(movie.chineseTitle, movie.releaseYear);
  if (directChinesePoster) {
    return {
      url: directChinesePoster,
      source: `TMDb 华语院线原版海报库`,
      distributor: 'Theatrical Release'
    };
  }

  return null;
}

async function run() {
  console.log(`Starting poster retrieval pipeline for ${movies.length} movies...`);
  const results: Record<string, any> = {};
  let foundCount = 0;
  let skippedInitial = 0;

  for (let i = 0; i < movies.length; i++) {
    const m = movies[i];
    if (initialVerifiedIds.has(m.id)) {
      skippedInitial++;
      continue;
    }

    process.stdout.write(`[${i + 1}/${movies.length}] Processing ${m.chineseTitle} (${m.originalTitle}, ${m.releaseYear})... `);
    const poster = await findPosterForMovie(m);
    if (poster) {
      results[m.id] = {
        movieId: m.id,
        chineseTitle: m.chineseTitle,
        originalTitle: m.originalTitle,
        releaseYear: m.releaseYear,
        officialPosterUrl: poster.url,
        posterSource: poster.source,
        distributor: poster.distributor,
        licenseStatus: 'official_theatrical',
        verificationStatus: 'licensed_verified',
        posterAspectRatio: '2:3'
      };
      foundCount++;
      console.log(`FOUND -> ${poster.url}`);
    } else {
      console.log(`NOT FOUND`);
    }

    // Save incremental progress every 20 movies
    if ((i + 1) % 20 === 0) {
      fs.writeFileSync('posters_found_incremental.json', JSON.stringify(results, null, 2));
    }
  }

  fs.writeFileSync('posters_found_all.json', JSON.stringify(results, null, 2));
  console.log(`\nPipeline complete! Found posters for ${foundCount} movies. Initial verified: ${skippedInitial}. Total coverage: ${foundCount + skippedInitial}/${movies.length}`);
}

run();
